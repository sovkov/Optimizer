function phi=AndrewsRob(x,a)
% Robust estimator in a form by Andrews
% phi = 2*a^2*(1-cos(x/a)), |x|<=pi*a
% phi = 4*a^2, |x|>pi*a
%
% USAGE: phi=AndrewsRob(x,a)
%
% INPUT
% x      - argument of the function
% a      - parameter of the function;
%          the less a the stronger is the robustness;
%          default value is 6/pi = 1.90985931710274;
%          if a does not exist at the input then the default value is
%          adopted
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(a) || any(any(~isnumeric(a)))
    a=6/pi; % default value = 1.90985931710274
end
if a<=0
    phi=[];
    return
end
%
phi = abs(x);
isg = find(phi>pi*a);
isl = find(phi<=pi*a);
if ~isempty(isl)
    phi(isl) = 2.*a.^2 .* (1-cos(x(isl)./a));
end
if ~isempty(isg)
    phi(isg) = 4*a^2;
end
%
return