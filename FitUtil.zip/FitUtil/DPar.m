function [D1,D2]=DPar(S,N)
% Returns dimensions of the variable S in the block N as they are defined in the fields Dim1 and Sim2.
% Call: [D1,D2]=DPar(S,N),
% where
% N is the ordinal number of the block in the model; default--the currently chosen block in Modeler;
% S is either the ordinal number of the parameter in the block N or the string name of the parameter; default--the currently chosen parameter in Modeler
global ComVarStr
if nargin<2 || isempty(N) || ~isnumeric(N)
    [N,M]=Modeler('getNM');
end
if nargin==0 || isempty(S)
    S=M;
end
N=round(N);
if isnumeric(S)
    S=round(S);
    if S<=0 || N<=0
        D1=0;
        D2=0;
    else
        D1 = ComVarStr.Proc(N).Par(S).Dim1;
        D2 = ComVarStr.Proc(N).Par(S).Dim2;
    end
elseif ischar(S)
    M=0;
    KK=numel(ComVarStr.Proc(N).Par);
    for k=1:KK
        if iscell(ComVarStr.Proc(N).Par(k).Name)
            if0=strcmp(ComVarStr.Proc(N).Par(k).Name{1},S);
        elseif ischar(ComVarStr.Proc(N).Par(k).Name)
            if0=strcmp(ComVarStr.Proc(N).Par(k).Name,S);
        else
            if0=false;
        end
        if if0
            M=k;
            break;
        end
    end
    if M
        D1 = ComVarStr.Proc(N).Par(M).Dim1;
        D2 = ComVarStr.Proc(N).Par(M).Dim2;
    else
        D1=0;
        D2=0;
    end
else
    D1=0;
    D2=0;
end
return
end