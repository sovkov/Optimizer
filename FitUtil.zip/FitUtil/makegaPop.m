function z=makegaPop(N,z0,ifFirst,x00,ifStepShake,cShake)
% Makes the initial population z for the genetic algorithm ga
%
% USAGE: z=makegaPop(N,z0,ifFirst,x00,ifStepShake,cShake)

%
% N       - the desired population size
% z0      - the population which should be expanded or contracted to N members;
%           default z0=[];
% ifFirst - flag: if true, the current Modeler parameters are taken as
%           the first population member without shaking, otherwise the
%           population is formed from the shaked parameters totally;
%           default ifFirst=true;
% x00     - if exists, the current vector of the model parameters is
%           replaced by x00 before starting, but restores after ending;
% ifStepShake - the regime of the shaking to form the population:
%           = true - the shaking strength is proportional to the step of the
%                    parameter defined in the "Modeler" window,
%           = false - the shaking strength is proportional to the current
%                     value of the parameter itself;
% cShake  - the strength of the shaking -- standard deviation of the normal
%           distribution of random shifts of a parameter is cShake times
%           either the parameter value itself (ifStepShake=false) or its
%           step (ifStepShake=true).
% if ifStepShake and/or cShake are not defined at the input, the values
% from the global structure ComVarStr.ifStepShake and/or ComVarStr.cShake
% are used; in a case they are not defined as well, the default values are
% used -- ifStepShake=false, cShake=0.01 (ifStepShake=false) or cShake=100
% (ifStepShake=true).
global ComVarStr;
if nargin>2 && ~isempty(z0) && all(all(isnumeric(z0)))
    if size(z0,1)>=N
        z=z0(1:N,:);
        return;
    end
    z=z0;
else
    z=[];
end
if nargin>=5 && ~isempty(ifStepShake)
    try
        ifStepShake0=ComVarStr.ifStepShake(1);
    catch
        ifStepShake0=[];
    end
    ComVarStr.ifStepShake = ifStepShake;
end
if nargin>=6 && ( any(size(cShake)~=1) && all(isreal(cShake)) )
    try
        cShake0=ComVarStr.cShake;
    catch
        cShake0=[];
    end
    ComVarStr.cShake = cShake;
end
x0=[];
while size(z,1)<N
    try
        x=getpara([],[],false);
        if isempty(x0)
            x0=x;
            if nargin>=4 && all(all(isnumeric(x00))) && all(size(x00)==size(x0))
                setpara(x00,false);
                x=x00;
            end
            if nargin<3 || isempty(ifFirst) || ifFirst(1)
                z=[z;x.'];
            end
        else
            z=[z;x.'];
        end
    catch
        disp('makegaPop ERROR: parameters field of the model does not agree with your input');
        break;
    end
    try
        feval('Optimizer','pbShake_Callback',false);
    catch
        disp('makegaPop ERROR: the Optimizer pbShake_Callback routine error');
        break;
    end
end
try
    setpara(x0,false);
    if nargin>=5 && ~isempty(ifStepShake)
        ComVarStr.ifStepShake = ifStepShake0;
    end
    if nargin>=6 && ( any(size(cShake)~=1) && isreal(cShake) )
        ComVarStr.cShake = cShake0;
    end
catch
    disp('makegaPop CRITICAL ERROR');
end
return
