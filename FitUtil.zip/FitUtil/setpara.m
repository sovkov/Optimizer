function ierr = setpara(y,ifzero)
% Puts the contents of a vector y into the parameter fields of the model constructed with Modeler tool
%
% USAGE: setpara(y,ifzero)
%
% Addresses the global structure ComVarStr
% ifzero  - if false then only those parameters which have ParStep~=0 are modified;
%           this case y should only contain the values of the parameters with ParStep~=0
%           if does not exist or empty at the input, then is implied to be true
% ierr    - error flag, =0 if everything is OK, otherwise =1.
% if y is absent or empty, it clears the parameter fields
% Uses global structure ComVarStr.
global ComVarStr;
ierr = 0; % everything is OK; otherwise ierr =1
try
    if nargin<2 || isempty(ifzero) || ifzero
        ifzero = true;
    end
catch
    ifzero = true;
end
try
    ParField=ComVarStr.ParField; % the name of the ComVarStr structure field containing the main procedure varyed values
    k0=length(ComVarStr.Proc);
    k00=zeros(k0,1);
    n00 = 1; % current number of the 1-D parameter in the y vector
    n01 = 0; % current number of the 1-D parameter in the ComVarStr.ParStep vector
    for k=1:k0
        fn = getProNm(k);
        if iscell(ParField{k})
            n0=length(ParField{k});
            k00(k)=n0;
            for n=1:n0
                try
                    z = ComVarStr.(fn).(ParField{k}{n});
%                    z = getfield(ComVarStr,fn,ParField{k}{n});
                    if isempty(z)
                        continue;
                    end
                    for ii=1:size(z,2)
                        for jj=1:size(z,1)
                            if ~ifzero
                                n01 = n01+1;
                                if ComVarStr.ParStep(n01)==0
                                    continue;
                                end
                            end
                            z(jj,ii) = y(n00);
                            n00 = n00+1;
                            if n00>length(y)
                                break;
                            end
                        end
                        if n00>length(y)
                            break;
                        end
                    end
                    ComVarStr.(fn).(ParField{k}{n})=z;
%                    ComVarStr = setfield(ComVarStr,fn,ParField{k}{n},z);
                catch
                    ComVarStr.(fn).(ParField{k}{n})=[];
%                    ComVarStr = setfield(ComVarStr,fn,ParField{k}{n},[]);
                    ierr = 1; % error flag
                    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                        disp('setpara: input vector length is inconsistent with the current model');
                    end
                end
            end
        else
            if ~isempty(fn) && ~isempty(ParField{k})
                try
                    z = ComVarStr.(fn).(ParField{k});
%                    z = getfield(ComVarStr,fn,ParField{k});
                    if isempty(z)
                        continue;
                    end
                    for ii=1:size(z,2)
                        for jj=1:size(z,1)
                            if ~ifzero
                                n01 = n01+1;
                                if ComVarStr.ParStep(n01)==0
                                    continue;
                                end
                            end
                            z(jj,ii) = y(n00);
                            n00 = n00+1;
                        end
                    end
                    ComVarStr.(fn).(ParField{k})=z;
%                    ComVarStr = setfield(ComVarStr,fn,ParField{k},z);
                catch
                    try
                        ierr = 1;
                        ComVarStr.(fn).(ParField{k})=[];
%                        ComVarStr = setfield(ComVarStr,fn,ParField{k},[]);
                        if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                            disp('setpara: input vector length is inconsistent with the current model');
                        end
                    catch
                    end
                end
            end
        end
    end
catch
end
return