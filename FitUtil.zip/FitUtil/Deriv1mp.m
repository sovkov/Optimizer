function [ierr,Der,fCmin,yCmin,RCmin,iCmin] = Deriv1mp(R0,y)
% Computes the first derivatives of the multidimentional function with respect to a set of its arguments
%
% USAGE: [ierr,Der,fCmin,yCmin,RCmin,iCmin] = Deriv1mp(R0,y)
%
% All input parameters are taken from the global structure ComVarStr
% (see comments in the "initialization" section below for structure field descriptions)
% R0 - if exists then it is a residual sum of squares of the 0-th approximation; default R0=[].
% y  - if exists, the 0-th approximation results; default y=0.
% OUTPUT
% Der (j,i) is the first derivative of the j-th component of the function over the i-th argument
% ierr   - error flag
%         =0   everything is OK
%         >0   non-critical error flag of the last call of the procedure for computing
%              function values; the computations are proceeded
%         =100 no ierr flag is produced by the procedure for computing the
%              function to be diffirentiated; the computations are done
%         <0   something was wrong; the computations are seized
% fCmin  - vector with only one non-zero component, which produced
%          the minimum value of the residual sum of squares
% yCmin  - results vector corresponding to the minimum value of the residual
%          sum of squares
% RCmin  - the value of the minimum value of the residual sum of squares
%          corresponding fCmin
% iCmin  - the ordinal number of the parameter resulting in iCmin
%
% initialization
%
global ComVarStr
try
    [CN,~,~]=Optimizer('getOpVal');        % get the parameter names in the original order
    if1Step = ~isfield (ComVarStr,'if1Step') || isempty(ComVarStr.if1Step) || ComVarStr.if1Step(1); % if the current state of the program to be displayed in the Matlab command window
%    if1Step = isfield (ComVarStr,'if1Step') && ~isempty(ComVarStr.if1Step) && ComVarStr.if1Step(1); % if the current state of the program to be displayed in the Matlab command window
    if if1Step && (nargin<2 || isempty(y) || ~isnumeric(y))
        y=0;
    end
    ierr=0;
    poolobj = gcp('nocreate');
    if isempty(poolobj)
        Mmp=1;
    else
        Mmp=poolobj.NumWorkers;
    end
%    Mmp=feval('matlabpool','size');
    %
    % loop over the parameters and computing derivatives
    %
    iCmin = 0; % to be the number of the parameter resulted in the minimum residual sum of squares after doing corresponding steps
    if nargin==0 || isempty(R0) || ~isreal(R0)
        R0=[];
    end
    [x0,lp] = getpara([],[],false,true); % lp is the total number of the varied parameters
    lr = length(getresults);
    if nargout>2
        fCmin=zeros(lp,1);
        yCmin=getresults;
        if ~isempty(R0)
            RCmin=abs(R0);
        else
            if isempty(yCmin)
                [ierr,yCmin]=funval(true);
            end
            if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
                RCmin = resi(yCmin,ComVarStr.input,ComVarStr.inpCov);
            elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
                RCmin = resi(yCmin,ComVarStr.input,ComVarStr.inpCovar);
            else
                RCmin = resi(yCmin,ComVarStr.input);
            end
        end
    else
        RCmin=-1;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% parallelized part %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
        Der = zeros(lr,lp);
        ifSparse=false;
    else
        Der = sparse(lr,lp);
        ifSparse=true;
    end
    Rm1=zeros(1,lp);
    yCmin1=zeros(lr,lp);
    PS1=zeros(1,lp);
    PSm=zeros(1,lp);
    ierr1=zeros(1,lp);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    parfor j1=1:Mmp
        clearCVS; % clears ComVarStr on all labs
    end
    if ~if1Step
        parfor j1=1:lp
%        for j1=1:lp
            [Der(:,j1),Rm1(j1),yCmin1(:,j1),PSm(j1),PS1(j1),ierr1(j1)]=D1mp(j1,lp,R0,RCmin,ComVarStr,[],CN);
        end
    else
        parfor j1=1:lp
            [Der(:,j1),Rm1(j1),yCmin1(:,j1),PSm(j1),PS1(j1),ierr1(j1)]=D1mp(j1,lp,R0,RCmin,ComVarStr,y,CN);
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DEBUGGING OPTION
%      if ~if1Step
%          for j1=1:lp
%              [Der(:,j1),Rm1(j1),yCmin1(:,j1),PSm(j1),PS1(j1),ierr1(j1)]=D1mp(j1,lp,R0,RCmin,ComVarStr,[],CN);
%          end
%      else
%          for j1=1:lp
%              [Der(:,j1),Rm1(j1),yCmin1(:,j1),PSm(j1),PS1(j1),ierr1(j1)]=D1mp(j1,lp,R0,RCmin,ComVarStr,y,CN);
%          end
%      end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if all(ierr1>=0)
        if RCmin>0
            Rm=min(Rm1);
            if Rm<=RCmin
                iCmin=find(Rm1==Rm,1,'first');
                RCmin=Rm;
                fCmin=zeros(lp,1);
                fCmin(iCmin)=PSm(iCmin);
            end
        end
    end
    ComVarStr.ParStep(ComVarStr.ParStep~=0)=PS1;
    parfor j1=1:Mmp
        clearCVS; % clears ComVarStr on all labs
    end
    j=find(ierr1~=0,1,'first');
    if ~isempty(j)
        ierr=ierr1(j);
    end
    if iCmin>0
        yCmin=yCmin1(:,iCmin);
    end
    clear yCmin1 Rm1 Rp1 PS1 ierr1;
 %   CVS=[];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ifSparse && nnz(Der)~=nzmax(Der)
        Der=Der*1; % reduces allocation spase
    end
catch
    ierr=-1000;
end
return