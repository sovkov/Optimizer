function phi=TukeyRob(x,c2)
% Robust estimator in a form by Tukey
% phi = x^2*(1-x^2/(2*c2)), |x|<=sqrt(c2)
% phi = c2/2, |x|>sqrt(c2)
%
% USAGE: phi=TukeyRob(x,c2)
%
% INPUT
% x      - argument of the function
% c2     - parameter of the function;
%          the less c2 the stronger is the robustness;
%          default value is 27;
%          if c2 does not exist at the input then the default value is
%          adopted
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(c2) || any(any(~isnumeric(c2)))
    c2=27; % default value
end
if c2<=0
    phi=[];
    return
end
%
c=sqrt(c2);
phi = abs(x);
isg = find(phi>c);
isl = find(phi<=c);
if ~isempty(isl)
    phi(isl) = phi(isl).^2;
    phi(isl) = phi(isl).*(1-phi(isl)./2./c2);
end
if ~isempty(isg)
    phi(isg) = c2/2;
end
%
return