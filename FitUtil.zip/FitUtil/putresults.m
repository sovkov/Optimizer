function y=putresults(x,Prc)
% Sets the contents of all the result fields to an input one- or double- cell structure x or components of a real vector x;
%
% USAGE: y=putresults(x,Prc)
%
% if x is a scalar numeric value, all the fields are set to this value;
% if x is absent or empty, it clears the result fields.
% And (if nargout>=1) puts the contents of all the results fields into a single- or double-indexed cell y
% Uses global structure ComVarStr.
% if the input structure Prc exists, then the name of the i-th procedure is
% taken from Prc(i).Name; otherwise it is found in a more time-consuming way
global ComVarStr;
try
    if nargin==0
        x=[];
    end
    y0=[];
    k0=length(ComVarStr.Proc);
    %
    % correct ResField if needed
    try
        k = length(ComVarStr.ResField);
    catch
        k=0;
    end
    if k0>k
        ComVarStr.ResField(k+1:k0) = {[]};
    end
    %
    if ~iscell(x) || numel(x)>1
        ifNC=true;
        nx0=1;
        nx =0;
    end
    %
    k00=zeros(k0,1);
    y=cell(k0,1);
    for k=1:k0
        if isempty(ComVarStr.ResField{k})
            continue;
        end
        if nargin>1 && ~isempty(Prc)
            try
                fn = Prc(k).Name;
            catch
                fn = getProNm(k);
            end
        else
            fn = getProNm(k);
        end
        if isempty(fn)
            continue;
        end
        if iscell(ComVarStr.ResField{k})
            n0=length(ComVarStr.ResField{k});
            k00(k)=n0;
            y{k}=cell(n0,1);
            for n=1:n0
                if isempty(ComVarStr.ResField{k}{n})
                    continue;
                end
                if nargout>=1 || (all(size(x)==1) && isnumeric(x))
                    try
                        y0 = ComVarStr.(fn).(ComVarStr.ResField{k}{n});
%                        y0 = getfield(ComVarStr,fn,ComVarStr.ResField{k}{n});
                    catch
                        continue;
                    end
                    if nargout>=1
                        y{k}{n}=y0; % cell to collect initial values of the parameters
                    end
                end
                try
                    if ~isempty(x)
                        if isscalar(x) && isnumeric(x)
                            if ~isempty(y0)
                                ComVarStr.(fn).(ComVarStr.ResField{k}{n})=x*ones(size(y0));
%                                ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},x*ones(size(y0)));
                            else
                                ComVarStr.(fn).(ComVarStr.ResField{k}{n})=x;
%                                ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},x);
                            end
                        elseif ifNC
                             for M=1:length(ComVarStr.Proc(k).Par)
                                try
                                    pn1 = ComVarStr.Proc(k).Par(M).Name{1};
                                catch
                                    pn1 = ComVarStr.Proc(k).Par(M).Name(1);
                                end
                                if strcmp(ComVarStr.ResField{k}{n},pn1)
                                    break;
                                end
                             end
                             Dim1 = ComVarStr.Proc(k).Par(M).Dim1;
                             if isempty(Dim1) || ~isreal(Dim1) || Dim1<=0
                                Dim1 = 1;
                             end
                             Dim2 = ComVarStr.Proc(k).Par(M).Dim2;
                             if isempty(Dim2) || ~isreal(Dim2) || Dim2<=0
                                Dim2 = 1;
                             end
                            nx=nx+Dim1*Dim2;
                            ComVarStr.(fn).(ComVarStr.ResField{k}{n})=x(nx0:nx);
%                            ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},x(nx0:nx));
                            nx0=nx+1;
                        else
                            ComVarStr.(fn).(ComVarStr.ResField{k}{n})=x{k}{n};
%                            ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},x{k}{n});
                        end
                    else
                        ComVarStr.(fn).(ComVarStr.ResField{k}{n})=[];
%                        ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},[]);
                    end
                catch
                try % in a case ResField{k}{n} is empty
                    ComVarStr.(fn).(ComVarStr.ResField{k}{n})=[];
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},[]);
                catch
                end
                end
            end
        else
            if nargout>=1 || (all(size(x)==1) && isnumeric(x))
                try
                    y0 = ComVarStr.(fn).(ComVarStr.ResField{k});
%                    y0 = getfield(ComVarStr,fn,ComVarStr.ResField{k});
                catch
                    continue;
                end
                if nargout>=1
                    y{k}=y0; % cell to collect initial values of the parameters
                end
            end
            try
                if nargin>0 && ~isempty(x)
                    if isscalar(x) && isnumeric(x)
                        if ~isempty(y0)
                            ComVarStr.(fn).(ComVarStr.ResField{k})=x*ones(size(y0));
%                            ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k},x*ones(size(y0)));
                        else
                            ComVarStr.(fn).(ComVarStr.ResField{k})=x;
%                            ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k},x);
                        end
                    elseif ifNC
                         for M=1:length(ComVarStr.Proc(k).Par)
                            try
                                pn1 = ComVarStr.Proc(k).Par(M).Name{1};
                            catch
                                pn1 = ComVarStr.Proc(k).Par(M).Name(1);
                            end
                            if strcmp(ComVarStr.ResField{k},pn1)
%                            if strcmp(ComVarStr.ResField{k}{n},pn1)
                                break;
                            end
                         end
                         Dim1 = ComVarStr.Proc(k).Par(M).Dim1;
                         if isempty(Dim1) || ~isreal(Dim1) || Dim1<=0
                            Dim1 = 1;
                         end
                         Dim2 = ComVarStr.Proc(k).Par(M).Dim2;
                         if isempty(Dim2) || ~isreal(Dim2) || Dim2<=0
                            Dim2 = 1;
                         end
                        nx=nx+Dim1*Dim2;
                        ComVarStr.(fn).(ComVarStr.ResField{k})=x(nx0:nx);
%                        ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k}{n},x(nx0:nx));
                        nx0=nx+1;
                    else
                        ComVarStr.(fn).(ComVarStr.ResField{k})=x{k};
%                        ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k},x{k});
                    end
                else
                    ComVarStr.(fn).(ComVarStr.ResField{k})=[];
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k},[]);
                end
            catch
                try % in a case ResField{k} is empty
                    ComVarStr.(fn).(ComVarStr.ResField{k})=[];
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ResField{k},[]);
                catch
                end
            end
        end
    end
catch
    y=[];
end
return