function y=collectres
% Puts the contents of all the results fields into a single- or double-indexed cell y
%
% USAGE: y=collectres
%
% Uses global structure ComVarStr.
global ComVarStr;
try
%    y=[];
    k0=length(ComVarStr.Proc);
    k00=zeros(k0,1);
    %
    % correct ResField if needed
    try
        k = length(ComVarStr.ResField);
    catch
        k=0;
    end
    if k0>k
        ComVarStr.ResField(k+1:k0) = {[]};
    end
    %
    y=cell(k0,1);
    for k=1:k0
        if iscell(ComVarStr.ResField{k})
            n0=length(ComVarStr.ResField{k});
            k00(k)=n0;
            y{k}=cell(n0,1);
            for n=1:n0
                fn = getProNm(k);
                try
                    y0 = ComVarStr.(fn).(ComVarStr.ResField{k}{n});
%                    y0 = getfield(ComVarStr,fn,ComVarStr.ResField{k}{n});
                catch
                    continue;
                end
                y{k}{n}=y0; % cell to collect initial values of the parameters
            end
        else
            fn = getProNm(k);
            try
                y0 = ComVarStr.(fn).(ComVarStr.ResField{k});
%                y0 = getfield(ComVarStr,fn,ComVarStr.ResField{k});
            catch
                continue;
            end
            y{k}=y0; % cell to collect initial values of the parameters
        end
    end
catch
    y=[];
end
return