function putpara(y,NBl1,NBl2)
% Puts the contents of a single- or double-indexed cell y into the parameter fields
%
% USAGE: putpara(y,NBl1,NBl2)
%
% if y is absent or empty, it clears the parameter fields
% y    - single- or double-indexed cell y into the parameter fields
% NBl1 - the starting block of the model to be considered; default NBl1=1;
% NBl2 - the final block of the model to be computed; default:
%        in a case NBl1 is the last argument in the input list and is correct, NBl2=NBl1;
%        otherwise NBl2=total number of the model blocks;
% Uses global structure ComVarStr.
global ComVarStr;
try
    k0=length(ComVarStr.Proc);
    if nargin>1
        if nargin==2 && ~isempty(NBl1) && isreal(NBl1) && NBl1>=1
            NBl2=round(NBl1(1));
        elseif nargin<=2 || isempty(NBl2) || ~isreal(NBl2) || NBl2>k0
            NBl2=k0;
        else
            NBl2=round(NBl2(1));
        end
        if isempty(NBl1) || ~isreal(NBl1) || NBl1<1
            NBl1=1;
        else
            NBl1=round(NBl1(1));
        end
        k0=NBl2-NBl1+1;
    else
        NBl1=1;
    end
    %
    for k=1:k0
        kk=k+NBl1-1;
        if isempty(ComVarStr.ParField{kk})
            continue;
        end
        fn = getProNm(kk);
        if isempty(fn)
            continue;
        end
        if iscell(ComVarStr.ParField{kk})
            n0=length(ComVarStr.ParField{kk});
            for n=1:n0
                if isempty(ComVarStr.ParField{kk}{n})
                    continue;
                end
                try
                    ComVarStr.(fn).(ComVarStr.ParField{kk}{n})=y{k}{n};
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ParField{kk}{n},y{k}{n});
                catch
                    ComVarStr.(fn).(ComVarStr.ParField{kk}{n})=[];
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ParField{kk}{n},[]);
                end
            end
        else
            if ~isempty(fn)
                try
                    ComVarStr.(fn).(ComVarStr.ParField{kk})=y{k};
%                    ComVarStr = setfield(ComVarStr,fn,ComVarStr.ParField{kk},y{k});
                catch
                    try
                        ComVarStr.(fn).(ComVarStr.ParField{kk})=[];
%                        ComVarStr = setfield(ComVarStr,fn,ComVarStr.ParField{kk},[]);
                    catch
                    end
                end
            end
        end
    end
catch
end
return