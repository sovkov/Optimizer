function refrParaPlan
% Refreshes ParaPlan window if needed
global ComVarStr
global P_figPar
if isempty(P_figPar) || isempty(ComVarStr) || ~isfield(ComVarStr,'ifMuPr') || isempty(ComVarStr.ifMuPr) || ~isreal(ComVarStr.ifMuPr)
    return
end
hR   = findobj ('Style','RadioButton','Parent',P_figPar);
if ~ComVarStr.ifMuPr
    h=hR(3);
elseif ComVarStr.ifMuPr>0
    h=hR(2);
else
    h=hR(1);
    feval(@ParaPlan,'Radio_Callback',hR(3));
end
feval(@ParaPlan,'Radio_Callback',h);
return