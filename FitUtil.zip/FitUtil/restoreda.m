function restoreda(nam)
% Restores fields of the global structure ComVarStr
% with the values read from the file "nam" structured as an output file of the "Optimizer"
%
% USAGE: restoreda(nam)
%
% Addresses the global structure ComVarStr

    global ComVarStr;
    if nargin==0 || ~ischar(nam)
        [nam,pnam] = uigetfile('*.*','Input file name');
        nam=strcat(pnam,nam);
    end
    fid = fopen(nam,'r');
    if fid==-1
        disp('restoreda: the wrong file name');
        return
    end
    a = ' ';
    while true
     try
        a = fgetl(fid);
        if isequal(a,-1)
            break;
        end
        indC = strfind (a,'.');
        if isempty(indC) || isempty(a)
            continue;
        end
        indF = indC(end);
        ifinbr = false;
        while indF<length(a)
            if (a(indF+1)>='A' && a(indF+1)<='Z') || (a(indF+1)>='a' && a(indF+1)<='z') || (a(indF+1)>='0' && a(indF+1)<='9') || strcmp(a(indF+1),'(') || strcmp(a(indF+1),')') || (ifinbr && strcmp(a(indF+1),','))
                indF = indF+1;
                if strcmp(a(indF),'(') || strcmp(a(indF),')')
                    ifinbr = ~ifinbr;
                end
            else
                break;
            end
        end
        indS = indC(end);
        while indS>1
            if (a(indS-1)>='A' && a(indS-1)<='Z') || (a(indS-1)>='a' && a(indS-1)<='z') || (a(indS-1)>='0' && a(indS-1)<='9') || strcmp(a(indS-1),'.')
                indS = indS-1;
            else
                break;
            end
        end
        b = a(indS:indF);
        a(indS:end) = [];
        %
        indS = strfind(b,'(');
        ind1 = 1;
        ind2 = 1;
        if ~isempty(indS)
            indC = strfind(b,',');
            indF = strfind(b,')');
            if ~isempty(indC)
                ind1 = str2num(b((indS+1):(indC-1)));
                ind2 = str2num(b((indC+1):(indF-1)));
            else
                ind1 = str2num(b((indS+1):(indF-1)));
                ind2 = 1;
            end
            b(indS:end) = [];
        end
        %
        indC = strfind(a,'[');
        if ~isempty(indC)
            a(indC(1):end) = [];
        end
        indC = strfind(a,' ');
        if ~isempty(indC)
            a(indC) = [];
        end
        c = str2num(a);
        if isempty(c)
            continue;
        end
        c = c(1);
        %
        indC = strfind(b,'.');
        while ~isempty(indC) && indC(end) == length(b)
            indC(end) = [];
        end
        if isempty(indC)
            d = [];
        else
            d = b(indC(end)+1:end);
            b(indC(end):end) = [];
        end
        if isfield(ComVarStr,b);
            if ~isempty(d)
                ComVarStr.(b).(d)(ind1,ind2)=c;
%                ComVarStr = setfield(ComVarStr,b,d,{ind1,ind2},c);
            else
                ComVarStr.(b)(ind1,ind2)=c;
%                ComVarStr = setfield(ComVarStr,b,{ind1,ind2},c);
            end
            ComVarStr.ifChange=true; % to indicate the model has been changed
        end
     catch
     end
    end
return