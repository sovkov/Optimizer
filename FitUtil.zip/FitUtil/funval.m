function [ierr,y0]=funval(ifNames)
% Computes the value of the multidimensional function
%
% USAGE: [ierr,y0]=funval(ifNames)
%
% All input parameters are taken from the global structure ComVarStr
% (see comments in the "initialization" section below for structure field descriptions)
%  INPUT
% ifNames - "true" means that the procedure names are to be kept between calls
%           (excepting the very first one) to save the computational time;
%           "false" means that the procedure names are determined every time
%           from the global structure ComVarStr;
%           default ifNames = true;
%  OUTPUT
% y0   - a column array of the function values;
% ierr - error flag
%        =0   everything is OK
%        >0   non-critical error flag of the last call of the procedure for computing
%             function values; the computations are proceeded
%        =100 no ierr flag is produced by the procedure for computing the
%             function to be differentiated; the computations are done
%        <0   something was wrong; the computations are seized

%
% initialization
%
global ComVarStr
persistent Prc; % to keep names between calls so that to save the computational time
K1=length(ComVarStr.Proc); % total number of sequential blocks
if nargin==0 || isempty(ifNames) || ~ifNames || length(Prc)~=K1
    Prc = [];
    for i=1:K1
        %
        % find the short name of the procedure and the path
        [Prc(i).Name,Prc(i).path] = getProNm(i);
    end
end
ifDisp=~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1);
if isfield(ComVarStr,'ifError') && ~isempty(ComVarStr.ifError) && ComVarStr.ifError(1)
    ComVarStr.ifError=false; % no errors at the start
end
ierr=0;
if nargin==0 || isempty(ifNames) || ~isreal(ifNames)
    ifNames=[];
end
if isfield(ComVarStr,'ifMuPr') && ~isempty(ComVarStr.ifMuPr) && isreal(ComVarStr.ifMuPr) && ComVarStr.ifMuPr(1)<0 && isfield(ComVarStr,'MPind') && ~isempty(ComVarStr.MPind)
    try
        if isfield (ComVarStr,'MuPrN') && ~isempty(ComVarStr.MuPrN) && isreal(ComVarStr.MuPrN(1))
            [M0mp,Mmp]=MPsk(ComVarStr.MuPrN(1));
        else
            [M0mp,Mmp]=MPsk;
        end
        ifMuPr=true;
    catch
        ifMuPr=false;
        ComVarStr.ifMuPr=false;
        Mmp=0;
        M0mp=0;
        if ifDisp
            beep;
            disp('funval WARNING: your currently installed Matlab does not probably support the multiprocess version of LSF.');
            disp('The multiprocess regime is turned off!');
            beep;
        end
    end
else
    ifMuPr=false;
    M0mp=0;
    Mmp=0;
end
%
if ifMuPr
    try
        K0=length(ComVarStr.MPind); % total number of parallel blocks
        KK=0; % number of sequential blocks already performed
        for k=1:K0
            if isfield(ComVarStr.MPind(k),'sec') && ~isempty(ComVarStr.MPind(k).sec) && isreal(ComVarStr.MPind(k).sec)
                if ComVarStr.MPind(k).sec(1)-KK>1
                    KK1=min(K1,ComVarStr.MPind(k).sec(1)-1);
                    ierr1=fuval([KK+1 KK1],[],Prc);
                    if ierr1<0
                        ierr=ierr1;
                        y0=[];
                        if isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange)
                            ComVarStr.ifChange=false;
                        end
                        if isfield(ComVarStr,'ifError')
                            ComVarStr.ifError=true;
                        end
                        if M0mp~=Mmp
                            MPsk(M0mp); % turns off the multiprocess computations regime
                        end
                        return
                    end
                else
                    KK1=KK;
                    ierr1=0;
                end
                N=length(ComVarStr.MPind(k).sec)-1;
                if N>1
                    ierr2=zeros(N,1);
                    N1=find(ComVarStr.MPind(k).sec<=K1,1,'last');
                    if isempty(N1) || N1>N
                        N1=N;
                    end
                    ksec=[reshape(ComVarStr.MPind(k).sec(1:N1),N1,1) reshape(ComVarStr.MPind(k).sec(2:N1+1)-1,N1,1)];
                    x=cell(N,1);
                    if ksec(1)==1
                        putresults([],Prc); % clear all the results fields
                    end
                    parfor n=1:N
                        [ierr2(n),x{n}]=fuval(ksec(n,:),ComVarStr,Prc);
                    end
                    setCVS(x,Prc); % set all the empty (assumably RESULT) fields in the client ComVarStr to x
                    KK1=ksec(N,2);
                    if any(ierr2<0)
                        ierr=min(ierr2);
                        if isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange)
                            ComVarStr.ifChange=false;
                        end
                        y0=[];
                        if isfield(ComVarStr,'ifError')
                            ComVarStr.ifError=true;
                        end
                        if M0mp~=Mmp
                            MPsk(M0mp); % turns off the multiprocess computations regime
                        end
                        return
                    end
                else
                    ierr2=0;
                end
                if k==K0 && KK1<K1
                    ierr3=fuval([KK1+1 K1],[],Prc);
                    if ierr3<0
                        ierr=ierr3;
                        y0=[];
                        if isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange)
                            ComVarStr.ifChange=false;
                        end
                        if isfield(ComVarStr,'ifError')
                            ComVarStr.ifError=true;
                        end
                        if M0mp~=Mmp
                            MPsk(M0mp); % turns off the multiprocess computations regime
                        end
                        return
                    end
                    KK1=K1;
                else
                    ierr3=0;
                end
                ierr=max(abs([ierr ; ierr1 ; ierr2 ; ierr3]));
                KK=KK1;
            end
        end
        parfor n=1:Mmp
            clearCVS;
        end
    catch
        ComVarStr.ifMuPr=false;
        refrParaPlan; % refreshes ParaPlan window if needed
        ierr=fuval([1 K1],[],Prc);
        if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp
            beep;
            disp('funval WARNING: parallel computing is turned off!');
        end
    end
else
    ierr=fuval([1 K1],[],Prc);
end
if nargout>1 && ierr>=0
    y0=getresults;
else
    y0=[];
end
if M0mp~=Mmp
    MPsk(M0mp); % turns off the multiprocess computations regime
end
if isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange)
    ComVarStr.ifChange=false;
end
return