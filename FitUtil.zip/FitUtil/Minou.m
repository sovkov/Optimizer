function Minou(key0)
% Input and output for the Modeler procedure
%
% USAGE: Minou(key0)
%
% Addresses the global structure ComVarStr.
% key0 is a text string defining a kind of the program action:
%      = 'inPartMod' or omitted
%         input model data for one procedure
%      = 'inGenMod'
%         input model data for a global model
%      = 'inAppMod'
%         append model data for a global model to the one already loaded
%      = 'ouGenMod'
%         output model data for a global model
%      = 'ouPartMod
%         output model data for a one procedure
% All the data read from or written to files are global variables.
%

global ComVarStr;
global M_figMod
persistent pname

% warning off;
key=0;

while (key==0)

  try

    if (nargin==0 || strcmp(key0,'inPartMod'))

        [fname1,pname1] = uigetfile(strcat(pname,'*.MOP'),'Partial model input file name');
        if isequal(fname1,0)
            return
        end
        name1=strcat(pname1,fname1);
        try
            load(name1,'-mat');
        catch
            load(name1);
        end
%         try
%           feval(@load,'-MAT',name1); % for Matlab
%         catch
%           feval(@load,name1); % for Octave
%         end
        N = Modeler('getNM');
        try
            N0 = length(ComVarStr.Proc);
            if N < N0 % & isfield(ComVarStr.Proc,'Name') & any(~isempty(ComVarStr.Proc(N+1:N0).Name))
                ComVarStr.Proc(N+2:N0+1) = ComVarStr.Proc(N+1:N0);
                N0 = length(ComVarStr.ParField);
                if N < N0
                    ComVarStr.ParField(N+2:N0+1) = ComVarStr.ParField(N+1:N0);
                    ComVarStr.ParField{N+1} = [];
                end
                N0 = length(ComVarStr.ResField);
                if N < N0
                    ComVarStr.ResField(N+2:N0+1) = ComVarStr.ResField(N+1:N0);
                    ComVarStr.ResField{N+1} = [];
                end
            end
        catch
        end
        N = N+1;
        ComVarStr.Proc(N).Name = Proc.Name;
        ComVarStr.Proc(N).Descr = Proc.Descr;
        ComVarStr.Proc(N).ifExec = Proc.ifExec;
        ComVarStr.Proc(N).Par = Proc.Par;
        %
        try
            Name=Proc.Name{1};
        catch
            Name=Proc.Name;
        end
        %
        % find short name
        n1 = max(strfind(Name,'\'));
        if isempty(n1)
            n1=0;
        end
        n1=n1+1;
        n2 = max(strfind(Name,'.'));
        if isempty(n2)
            n2=length(Name)+1;
        end
        n2=n2-1;
        Name = Name(n1:n2);
        %
        try
            ComVarStr.(Name)=ParVal;
%            ComVarStr = setfield(ComVarStr,Name,ParVal);
        catch
        end
        %
        if isfield(ComVarStr,'MPind')
            for i=1:length(ComVarStr.MPind)
                if isfield(ComVarStr.MPind(i),'sec') && ~isempty(ComVarStr.MPind(i).sec) && isreal(ComVarStr.MPind(i).sec)
                    k=find(ComVarStr.MPind(i).sec>N);
                    if ~isempty(k)
                        ComVarStr.MPind(i).sec(k)=ComVarStr.MPind(i).sec(k)+1;
                    end
                end
            end
        end
        %
        pname=pname1;
        key = 1;
        ComVarStr.ifChange=true; % The model has been changed
%         ComVarStr.ModName='Modeler';
%         if ishandle(M_figMod)
%             set(M_figMod,'Name',ComVarStr.ModName);
%         end
        return


    elseif (strcmp(key0,'inGenMod'))

        [fname2,pname2] = uigetfile(strcat(pname,'*.MOT'),'Total model input file name');
        if isequal(fname2,0)
            return
        end
        name2=strcat(pname2,fname2);
        try
            load(name2,'-mat');
        catch
            load(name2);
        end
%         try
%           feval(@load,'-MAT',name2); % for Matlab
%         catch
%           feval(@load,name2); % for Octave
%         end
        pname=pname2;
        key = 1;
%        ComVarStr.ifChange=true; % The model has been changed
        ComVarStr.ModName=strcat('Modeler: ',name2);
        if ishandle(M_figMod)
            set(M_figMod,'Name',ComVarStr.ModName);
        end
        return


    elseif (strcmp(key0,'inAppMod'))

        N0 = length(ComVarStr.Proc);
        ComVarStr0=ComVarStr;
        [fname2,pname2] = uigetfile(strcat(pname,'*.MOT'),'Appending model input file name');
        if isequal(fname2,0)
            return
        end
        name2=strcat(pname2,fname2);
        try
            load(name2,'-mat');
        catch
            load(name2);
        end
%         try
%           feval(@load,'-MAT',name2); % for Matlab
%         catch
%           feval(@load,name2); % for Octave
%         end
        pname=pname2;
        
        N = length(ComVarStr.Proc);
        for k=1:N
            ComVarStr0.Proc(N0+k).Name = ComVarStr.Proc(k).Name;
            ComVarStr0.Proc(N0+k).Descr = ComVarStr.Proc(k).Descr;
            ComVarStr0.Proc(N0+k).ifExec = ComVarStr.Proc(k).ifExec;
            ComVarStr0.Proc(N0+k).Par = ComVarStr.Proc(k).Par;
            try
                ComVarStr0.ParField{N0+k} = ComVarStr.ParField{k};
            catch
                ComVarStr0.ParField{N0+k} = [];
            end
            try
                ComVarStr0.ResField{N0+k} = ComVarStr.ResField{k};
            catch
                ComVarStr0.ResField{N0+k} = [];
            end
            %
            try
                Name=ComVarStr.Proc(k).Name{1};
            catch
                Name=ComVarStr.Proc(k).Name;
            end
            %
            % find short name
            n1 = max(strfind(Name,'\'));
            if isempty(n1)
                n1=0;
            end
            n1=n1+1;
            n2 = max(strfind(Name,'.'));
            if isempty(n2)
                n2=length(Name)+1;
            end
            n2=n2-1;
            Name = Name(n1:n2);
            try
                ParVal0 = ComVarStr0.(Name);
%                ParVal0 = getfield(ComVarStr0,Name);
            catch
                ParVal0 = [];
            end
            try
                ParVal = ComVarStr.(Name);
%                ParVal = getfield(ComVarStr,Name);
            catch
                ParVal = [];
            end
            if ~isempty(ParVal0)
                if isempty(ParVal)
                    ParVal = ParVal0;
                else
                    NamPar0=fieldnames(ParVal0);
                    NP0 = length(NamPar0);
                    for k0 = 1:NP0
                        try
                            if ~isfield(ParVal,NamPar0{k0}) || isempty(ParVal.(NamPar0{k0}))
                                ParVal.(NamPar0{k0}) = ParVal0.(NamPar0{k0});
%                                ParVal = setfield(ParVal,NamPar0{k0},getfield(ParVal0,NamPar0{k0}));
                            elseif ~isempty(ParVal0.(NamPar0{k0}))
                                nmf0 = fieldnames(ParVal0.(NamPar0{k0}));
                                ParVal.(NamPar0{k0}).(nmf0{kf0}) = ParVal0.(NamPar0{k0}).(nmf0{kf0});
                            end
                        catch
                            try
                                if ~isfield(ParVal,NamPar0) || isempty(ParVal.(NamPar0))
                                    ParVal.(NamPar0) = ParVal0.(NamPar0);
%                                    ParVal = setfield(ParVal,NamPar0,getfield(ParVal0,NamPar0));
                                elseif ~isempty(ParVal0.(NamPar0))
                                    nmf0 = fieldnames(ParVal0.(NamPar0));
                                    ParVal.(NamPar0).(nmf0{kf0}) = ParVal0.(NamPar0).(nmf0{kf0});
                                end
                            catch
                            end
                        end
                    end
                end
            end
            ComVarStr0.(Name) = ParVal;
%            ComVarStr0 = setfield(ComVarStr0,Name,ParVal);
        %
        end
        if isfield(ComVarStr0,'ParStep') && isfield(ComVarStr,'ParStep')
            ComVarStr0.ParStep = [reshape(ComVarStr0.ParStep,1,numel(ComVarStr0.ParStep)) reshape(ComVarStr.ParStep,1,numel(ComVarStr.ParStep))];
        elseif isfield(ComVarStr,'ParStep')
            ComVarStr0.ParStep = reshape(ComVarStr.ParStep,1,numel(ComVarStr.ParStep));
        end
        if isfield(ComVarStr0,'ParCnstr') && isfield(ComVarStr,'ParCnstr')
            ComVarStr0.ParCnstr = [reshape(ComVarStr0.ParCnstr,1,numel(ComVarStr0.ParCnstr)) reshape(ComVarStr.ParCnstr,1,numel(ComVarStr.ParCnstr))];
        elseif isfield(ComVarStr,'ParCnstr')
            ComVarStr0.ParCnstr = reshape(ComVarStr.ParCnstr,1,numel(ComVarStr.ParCnstr));
        end
        if isfield(ComVarStr0,'input') && isfield(ComVarStr,'input')
            ComVarStr0.input = [ComVarStr0.input ; ComVarStr.input];
        elseif isfield(ComVarStr,'input')
            ComVarStr0.input = ComVarStr.input;
        end
        if isfield(ComVarStr0,'X0') && isfield(ComVarStr,'X0')
            ComVarStr0.X0 = [ComVarStr0.X0 ; ComVarStr.X0];
        elseif isfield(ComVarStr,'X0')
            ComVarStr0.X0 = ComVarStr.X0;
        end
        ComVarStr.inpCov=[];
        if isfield(ComVarStr0,'inpCovar') && isfield(ComVarStr,'inpCovar')
            [NC0,MC0] = size(ComVarStr0.inpCovar);
            [NC, MC]  = size (ComVarStr.inpCovar);
            if     MC0==1   && MC==1
                ComVarStr0.inpCovar = [ComVarStr0.inpCovar ; ComVarStr.inpCovar];
            elseif NC0==MC0 && MC==1
                ComVarStr0.inpCovar = [ComVarStr0.inpCovar zeros(NC0,MC) ; zeros(NC0,MC0) diag(ComVarStr.inpCovar.^2)];
            elseif MC0==1   && NC==MC && NC~=0
                ComVarStr0.inpCovar = [diag(ComVarStr0.inpCovar.^2) zeros(NC0,MC) ; zeros(NC0,MC0) ComVarStr.inpCovar];
            elseif NC0==MC0 && NC==MC && NC~=0 && NC0~=0
                ComVarStr0.inpCovar = [ComVarStr0.inpCovar zeros(NC0,MC) ; zeros(NC0,MC0) ComVarStr.inpCovar];
            elseif (NC0==0 || MC0==0) && (NC~=0 && MC~=0)
                ComVarStr0.inpCovar=ComVarStr.inpCovar;
            end
        elseif isfield(ComVarStr,'inpCovar')
            ComVarStr0.inpCovar = ComVarStr.inpCovar;
        end
        
        ComVarStr = ComVarStr0;
        key = 1;
        ComVarStr.ifChange=true; % The model has been changed
%         ComVarStr.ModName='Modeler';
%         if ishandle(M_figMod)
%             set(M_figMod,'Name',ComVarStr.ModName);
%         end
        return
        

    elseif (strcmp(key0,'ouGenMod'))
        
        [fname3,pname3] = uiputfile(strcat(pname,'*.MOT'),'Total model output file name');
        if isequal(fname3,0)
            return
        end
        name3=strcat(pname3,fname3);
        pname=pname3;
        if (isempty(strfind(fname3,'.')) && ~isempty(name3))
            name3=strcat(name3,'.MOT');
        end
        
%         try
%             save(name3,'-mat','-v7.3','ComVarStr');
%         catch
            save(name3,'-mat','ComVarStr');
%        end
%         try
%           feval(@save,'-MAT',name3,'ComVarStr'); % for Matlab
%         catch
%           feval(@save,name3,'ComVarStr'); % for Octave
%         end
        
        key = 1;
        ComVarStr.ModName=strcat('Modeler: ',name3);
        if ishandle(M_figMod)
            set(M_figMod,'Name',ComVarStr.ModName);
        end
        return

        
    elseif (strcmp(key0,'ouPartMod'))
        
        [fname4,pname4] = uiputfile(strcat(pname,'*.MOP'),'Partial model output file name');
        if isequal(fname4,0)
            return
        end
        name4=strcat(pname4,fname4);
        pname=pname4;
        if (isempty(strfind(fname4,'.')) && ~isempty(name4))
            name4=strcat(name4,'.MOP');
        end
        
        N = Modeler('getNM');
        Proc = ComVarStr.Proc(N);
        for i=1:length(Proc.Par)
            Proc.Par(i).From=[];
        end
        %
        try
            Name=Proc.Name{1};
        catch
            Name=Proc.Name;
        end
        %
        % find short name
        n1 = max(strfind(Name,'\'));
        if isempty(n1)
            n1=0;
        end
        n1=n1+1;
        n2 = max(strfind(Name,'.'));
        if isempty(n2)
            n2=length(Name)+1;
        end
        n2=n2-1;
        Name = Name(n1:n2);
        %
%        try
            ParVal = ComVarStr.(Name);
%            ParVal = getfield(ComVarStr,Name);
%             try
%                 save(name4,'-mat','-v7.3','Proc','ParVal');
%             catch
%                save(name4,'-mat','-v7.3','Proc');
%            end
%        catch
            try
                save(name4,'-mat','Proc','ParVal');
            catch
                save(name4,'-mat','Proc');
            end
%        end
%         try % for Matlab 
%           try
%               ParVal = getfield(ComVarStr,Name);
%               feval (@save,'-MAT',name4,'Proc','ParVal');
%           catch
%               feval (@save,'-MAT',name4,'Proc');
%           end
%         catch % for Octave
%           try
%               ParVal = getfield(ComVarStr,Name);
%               feval (@save,name4,'Proc','ParVal');
%           catch
%               feval (@save,name4,'Proc');
%           end
%         end
        return

    end

  catch me
      disp(me.message);
      try
          if isstruct(ComVarStr0) && ~isempty(ComVarStr0)
              ComVarStr=ComVarStr0;
          end
      catch
      end
  end
end
% warning on;
return
