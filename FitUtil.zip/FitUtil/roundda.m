function roundda(nam0,nam,Nround,ifplain,NN)
% Makes the file "nam" of the rounded results of the optimization from the values read from the file "nam0" structured as the output file of the "Optimizer"
%
% USAGE: roundda(nam0,nam,Nround,ifplain,NN)
%
% Nround  - the number of digits more than the leading digit of the
%           (conditional standard deviation)/2 to be kept; default Nround=0
% ifplain - flag indicating if the plain format for the standard deviation
%           is needed (i.e., corresponding only to the last digits of the
%           parameter without dots and exponential part);
%           default ifplain=false
% NN      - [N00 N01] (default =[]), where:
%  N00    - maximum permitted number of zeros after '.' in the resulting string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%  N01    - maximum permitted number of digits before '.' in the resulting string;
%           default=[] means that the number of digits depends on the
%           num2str inbuilt MatLab function
% ROUTINES required:
% rour2s - Forms a string s of the value c and its standard deviation sd in paranthesis
%          and the routines called from it.
try
    if nargin<5 || isempty(NN) || any(any(~isreal(NN)))
        NN=[];
    end
    if nargin<4 || isempty(ifplain)
        ifplain=false;
    end
    if nargin<3 || isempty(Nround) || any(any(~isreal(Nround)))
        Nround=0;
    else
        Nround=round(Nround);
    end
    if nargin==0 || ~ischar(nam0)
        [nam0,pnam0] = uigetfile('*.*','Input file name');
        nam0=strcat(pnam0,nam0);
    end
    if nargin<=1 || ~ischar(nam)
        [nam,pnam] = uiputfile('*.*','Output file name');
        nam=strcat(pnam,nam);
    end
    if strcmp(nam,nam0)
        disp('roundda ERROR: the input and output file names must differ');
        return
    end
    fid0 = fopen(nam0,'r');
    if fid0==-1
        disp('roundda ERROR: the wrong input file');
        return
    end
    fid = fopen(nam,'w');
    if fid==-1
        disp('roundda ERROR: the wrong output file');
        return
    end
    a = ' ';
    while true
     try
        a = fgetl(fid0);
        if isequal(a,-1)
            break;
        end
        indC = findstr (a,'.');
        if isempty(indC) || isempty(a)
            continue;
        end
        indF = indC(end);
        ifinbr = false;
        while indF<length(a)
            if (a(indF+1)>='A' && a(indF+1)<='Z') || (a(indF+1)>='a' && a(indF+1)<='z') || (a(indF+1)>='0' && a(indF+1)<='9') || strcmp(a(indF+1),'(') || strcmp(a(indF+1),')') || (ifinbr && strcmp(a(indF+1),','))
                indF = indF+1;
                if strcmp(a(indF),'(') || strcmp(a(indF),')')
                    ifinbr = ~ifinbr;
                end
            else
                break;
            end
        end
        indS = indC(end);
        while indS>1
            if (a(indS-1)>='A' && a(indS-1)<='Z') || (a(indS-1)>='a' && a(indS-1)<='z') || (a(indS-1)>='0' && a(indS-1)<='9') || strcmp(a(indS-1),'.')
                indS = indS-1;
            else
                break;
            end
        end
        b = a(indS:indF);
        a(indS:end) = [];
        %
        indS = findstr(b,'(');
        ind1 = 0;
        ind2 = 0;
        if ~isempty(indS)
            indC = findstr(b,',');
            indF = findstr(b,')');
            if ~isempty(indC)
                ind1 = str2num(b((indS+1):(indC-1)));
                ind2 = str2num(b((indC+1):(indF-1)));
            else
                ind1 = str2num(b((indS+1):(indF-1)));
                ind2 = 0;
            end
            b(indS:end) = [];
        end
        %
        indC = findstr(a,'[');
        indF = findstr(a,']');
        if ~isempty(indC) && ~isempty(indF)
            sd  = str2num ( a( (indC(1)+1) : (indF(1)-1) ) );
            if length(indC)>1 && length(indF)>1
                csd = str2num (a( (indC(2)+1) : (indF(2)-1) ) );
            else
                csd=0;
            end
            a(indC(1):end) = [];
        else
            continue;
        end
        indC = findstr(a,' ');
        if ~isempty(indC)
            a(indC) = [];
        end
        c = str2num(a);
        if isempty(c)
            continue;
        end
        c = c(1);
        if ~isempty(csd) && (csd>sd || imag(csd) || isnan(csd))
            beep;
            disp('WARNING: conditional standard deviations are inconsistent!');
            beep;
        end
        %
        a = rour2s(c,sd,csd,Nround,ifplain,NN); % makes a string of the rounded c and sd values
        %
        if ind1==0 && ind2==0
            sind='';
        elseif ind1~=0 && ind2~=0
            sind = strcat('(',num2str(ind1),',',num2str(ind2),')');
        elseif ind1~=0
            sind = strcat('(',num2str(ind1),')');
        else
            sind = strcat('(',num2str(ind2),')');
        end
        %
        indC = findstr(b,'.');
        while ~isempty(indC) && indC(end) == length(b)
            indC(end) = [];
        end
        if isempty(indC)
            d = [];
        else
            d = b(indC(end)+1:end);
            b(indC(end):end) = [];
        end
        if ~isempty(d)
            a = strcat(a,'\t',b,'.',d,sind,'\r\n');
            count = fprintf(fid,a);
        else
            a = strcat(a,'\t',b,sind,'\r\n');
            count = fprintf(fid,a);
        end
     catch
         disp('roundda ERROR');
     end
    end
    status=fclose('all');
catch  mectc
    disp('roundda ERROR');
    disp(mectc.message);
end
return

function s = rour2s(c,sd,csd,Nround,ifplain,NN)
%    s = rour2s(c,sd,csd,ifplain)
% Forms a string s of the value c and its standard deviation sd in paranthesis.
% The rounding is done over the leading digit of the half conditional standard deviation csd/2 plus Nround additional digits.
% ifplain - flag indicating if the plain format for the standard deviation
%           is needed (i.e., corresponding only to the last digits of the
%           parameter without dots and exponential part);
%           default ifplain=false
% ROUTINES required:
% Ndig    - determines the decimal order of magnitude
% padzero - pads the stringed real number b with ending zeros
% NN      - [N00 N01] (default =[]), where:
%  N00    - maximum permitted number of zeros after '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%  N01    - maximum permitted number of digits before '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
if nargin==0 || isempty(c) || any(any(~isreal(c)))
    s='';
    return
end
if nargin<6 || isempty(NN) || any(any(~isreal(NN)))
    NN=[];
end
if nargin<5 || isempty(ifplain)
    ifplain=false;
end
if nargin<4 || isempty(Nround) || any(any(~isreal(Nround)))
    Nround=0;
end
if nargin<3 || isempty(csd) || any(any(~isreal(csd)))
    csd=0;
end
if nargin<2 || isempty(sd) || any(any(~isreal(sd)))
    sd=0;
end
if csd~=0 && ~isinf(csd) && ~isnan(csd)
    Nc  = Ndig(c)  - Ndig(csd/2) + 1 + Nround;
    Nsd = Ndig(sd) - Ndig(csd/2) + 1 + Nround;
else
    Nc=16;
    Nsd=16;
end
frmc  = strcat('%.',num2str(Nc) ,'g');
frmsd = strcat('%.',num2str(Nsd),'g');
if c~=0 || sd~=0
    a=padzer(num2str(sd,frmsd),Nsd,NN);
    if ifplain && sd>0
        indC=findstr(a,'e');
        if ~isempty(indC)
            a(indC(1):end)=[];
        end
        indC=findstr(a,'E');
        if ~isempty(indC)
            a(indC(1):end)=[];
        end
        indC=findstr(a,'.');
        if ~isempty(indC)
            a(indC)=[];
        end
        if strcmp(a(1),'-') || strcmp(a(1),'+')
            a(1)=[];
        end
        while length(a)>1 && strcmp(a(1),'0')
            a(1)=[];
        end
    end
    s = padzer(num2str(c,frmc),Nc,NN);
    if ifplain
        indC = findstr(s,'e');
        if isempty(indC)
            indC = findstr(s,'E');
        end
        if ~isempty(indC)
            s = strcat(s(1:(indC-1)),'(',a,')',s(indC:end));
        else
            s = strcat(s,'(',a,')');
        end
    else
        s = strcat(s,'(',a,')');
    end
else
    s='0(0)';
end
return

function N = Ndig(c)
%   N = Ndig(c)
% determines the decimal order of magnitude of the c value
%
    N=0;
    while true
        if abs(c)<1
            N=N-1;
            c=c*10;
        elseif abs(c)>=10
            N=N+1;
            c=c/10;
        else
            break;
        end
    end
return

function c = padzer(b,N,NN)
%   c = padzer(b,N)
% pads the stringed real number b with ending zeros so that to be presented
% with N signicant digits
% NN      - [N00 N01] (default =[]), where:
%  N00    - maximum permitted number of zeros after '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%  N01    - maximum permitted number of digits before '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%
if nargin<3 || isempty(NN) || any(any(~isreal(NN)))
    N00=[];
    N01=[];
elseif all(size(NN)==1)
    N00=NN;
    N01=[];
else
    N00=NN(1);
    N01=NN(2);
end
c = b;
indC = findstr(c,'.');
indF = findstr(c,'e');
if isempty(indF)
    indF = findstr(c,'E');
    if isempty(indF)
        indF=length(c)+1;
    end
end
if isempty(indC)
    K = N - (indF-1);
else
    K = N - (indF-2);
end
n0=[]; % counts the number of zeros after the dot
for k=1:length(c)
    if strcmp(c(k),'-') || strcmp(c(k),'+') || strcmp(c(k),'0')
        K=K+1;
        if ~isempty(n0) && strcmp(c(k),'0')
            n0=n0+1;
        end
    elseif ~strcmp(c(k),'.')
        break;
    else
        n0=0; % start to count the number of zeros after the dot
    end
end
if K>0
    if isempty(indC)
        K=K+1;
    end
    if indF<=length(c)
        c((indF+K):(end+K)) = c(indF:end);
    end
    if isempty(indC)
        c(indF)='.';
        indF=indF+1;
        K=K-1;
    end
    for k=0:(K-1)
        c(indF+k)='0';
    end
end
%
if ~isempty(n0) && ~isempty(N00) && n0>N00
    c(indC:(indC+n0))=[];
    n=length(c);
    if indC<n
        c((indC+2):(n+1)) = c((indC+1):n);
        c(indC+1)='.';
    end
    if indC>1
        k = findstr(c(1:(indC-1)),'0');
        c(k)=[];
    end
    n0=n0+1;
    if ~isempty(N01) && N01<=0
        indC=findstr(c,'.');
        if ~(isempty(indC) || indC<=1 || strcmp(c(indC-1),'0') || strcmp(c(indC-1),'-') || strcmp(c(indC-1),'+'))
            c((indC+2):(length(c)+1)) = c((indC+1):length(c));
            c(indC+1)=c(indC-1);
            c(indC-1)='0';
            n0=n0-1;
        end
    end
elseif ~isempty(N01)
    if ~isempty(indC)
        kk=indC;
    else
        kk=indF;
    end
    k0=0;
    kp=[];
    for k=1:kk
        if k==kk
            break;
        end
        if strcmp(c(k),'-') || strcmp(c(k),'+')
            continue;
        else
            if isempty(kp)
                kp=k+1;
            end
            k0=k0+1;
            if k0>N01
                break;
            end
        end
    end
    if k<kk
        if isempty(indC)
            kk0=length(c)+1;
        else
            kk0=kk;
        end
        if N01>0
            c((kp+1):kk0) = c(kp:(kk0-1));
            c(kp)='.';
            n0=kp-kk;
        elseif  ~(strcmp(c(k),'0') || strcmp(c(k),'-') || strcmp(c(k),'+'))
            c(indC)=[];
            c((k+2):(length(c)+2)) = c(k:length(c));
            c(k)='0';
            c(k+1)='.';
            n0=k-kk;
        else
            n0=0;
        end
    else
        n0=0;
    end
else
    n0=0;
end
if isempty(n0)
    n0=0;
end
%
%
n=length(c);
indF = findstr(c,'e');
if isempty(indF)
    indF = findstr(c,'E');
end
if ~isempty(indF) && indF<n
    k=str2num(c((indF+1):n))-n0;
    if k~=0
        a=num2str(k);
        c((indF+1):n)=[];
        c = strcat(c,a);
    else
        c(indC:n)=[];
    end
else
    k=-n0;
    if k~=0
        c = strcat(c,'e',num2str(k));
    end
end
return