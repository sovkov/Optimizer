function makeCov
% Step-by-step formation of the ComVarStr.inpCov covariance matrix.
% Addresses the global structure ComVarStr.
% Adds a covariance submatrix from ComVarStr.locCov to the new dimensions
% of ComVarStr.inpCov if the size of ComVarStr.inpCov is less than the size
% of ComVarStr.inpCovar or adds ComVarStr.inpCovar to ComVarStr.inpCov if
% their sizes are equal.
global ComVarStr
    if isfield (ComVarStr,'inpCovar')
        m = size(ComVarStr.inpCovar,1);
        if m==0
            m=-1;
        end
    else
        m = -1;
    end
    if isfield (ComVarStr,'inpCov')
        n = size(ComVarStr.inpCov,1);
    else
        n = 0;
    end
    if isfield(ComVarStr,'locCov')
        k = size(ComVarStr.locCov,1);
    else
        k = 0;
    end
    if m~=n && k~=0
        if n>0
            if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
                ComVarStr.inpCov(n+1:n+k,1:n) = zeros(k,n);
            else
                ComVarStr.inpCov(n+1:n+k,1:n) = sparse(k,n);
            end
        end
        if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
            ComVarStr.inpCov(1:n+k,n+1:n+k) = zeros(n+k,k);
        else
            ComVarStr.inpCov(1:n+k,n+1:n+k) = sparse(n+k,k);
        end
        ComVarStr.inpCov(n+1:n+k,n+1:n+k) = ComVarStr.locCov;
    elseif m==n
        ComVarStr.inpCov = ComVarStr.inpCov+ComVarStr.inpCovar;
    end
    if isfield (ComVarStr,'locCov')
        ComVarStr = rmfield(ComVarStr,'locCov');
    end
    if isfield(ComVarStr,'ifSparse') && ~isempty(ComVarStr.ifSparse) && ComVarStr.ifSparse(1) && isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && nnz(ComVarStr.inpCov)~=nzmax(ComVarStr.inpCov)
        ComVarStr.inpCov=ComVarStr.inpCov*1; % reduces allocation spase
    end
return