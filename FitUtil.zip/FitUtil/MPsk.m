function [M0,M]=MPsk(M)
% Starts/kills the multiprocess computations (parpool)
%     INPUT
% M    - if M does not exist or not a real number, then parpool is started
%        using the local configuration, implying using all the locally
%        available processor cores as labs by default;
%        if M<1, then parpool is killed;
%        otherwise parpool is started with M labs.
%     OUTPUT
% M    - number of labs activated at the output; =0 if parpool has been killed.
% M0   - number of labs activated at the input; =0 if parpool has been killed.
%
    poolobj = gcp('nocreate');
    if isempty(poolobj)
        M0=0;
    else
        M0=poolobj.NumWorkers;
    end
    if nargin>=1 && ~isempty(M) && isnumeric(M)
        M=round(M);
        if M~=M0;
            if M<1 && M0>0
                M=0;
                delete(gcp);
            elseif M0==0
                feval('parpool','local',M);
            else
                delete(gcp);
                feval('parpool','local',M);
            end
        end
    else
        if M0==0
            parpool;
            poolobj = gcp('nocreate');
            M=poolobj.NumWorkers;
        else
            M=M0;
        end
    end
%%%%%%%%
%     M0=feval('matlabpool','size');
%     if nargin>=1 && ~isempty(M) && isnumeric(M)
%         M=round(M);
%         if M~=M0;
%             if M<1 && M0>0
%                 M=0;
%                 matlabpool close;
%             elseif M0==0
%                 feval('matlabpool','local',M);
%             else
%                 matlabpool close;
%                 feval('matlabpool','local',M);
%             end
%         end
%     else
%         if M0==0
%             matlabpool open;
%             M=feval('matlabpool','size');
%         else
%             M=M0;
%         end
%     end
return
