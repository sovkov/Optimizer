function delModBl(N)
% Deletes blocks, whose ordinal numbers are listed in the 1-D array N, from the current model; deletes the currently chosen block in a case N is not input or invalid.
%
% USAGE: delModBl(N); delModBl
%
% REMARK:
%     the number of the block is output in the command window in a regime
%     ComVarStr.ifDisp=true          as soon as this block is chosen
%     from the corresponding list of the Modeler window.
if nargin>0
    feval('Modeler','pbPronDel_Callback',N)
else
    feval('Modeler','pbPronDel_Callback')
end
return