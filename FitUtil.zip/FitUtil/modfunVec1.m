function y=modfunVec1(x)
% Computes a vector y of the model output at a point predefined by the vector x of the values of the parameters listed in the EDITABLE FRAGMENT of the program code for a model constructed with a Modeler program and "experimental" data defined in the Viewer program.
%
% USAGE: y = modfunVec1(x)
%
% So, to adapt this routine to the
% current model, the user should provide all the necessary information in the EDITABLE FRAGMENT in the
% upper part of the modFunVec1 code below.
% The output y of this function is calculated from the model results after performing NIter1 fitting steps
% over the variable parameters of the model following the Optimizer rules.
% Implied uses of the program:
% At the exit the parameters are NOT restored to their initial values.
%
% 1. Separation of the (almost) linear and (substantially) non-linear parameters. The user is recommended
%    to exclude (put corresponding steps to zero) the "non-linear" parameters from the variable parameters
%    of the model and keep the "linear" parameters as the variable ones (i.e., keep their steps non-zero).
%    Then, list the names of those "non-linear" parameters along with their indices in the EDITABLE FRAGMENT
%    below and provide the initial guess for their values in the vector x, which length is implied to be the
%    same as the total number of all 1-D components of the "non-linear" parameters. If the parameters of the
%    model, which are kept as the variable ones, are actually linear, it is enough to put NIter1=1, otherwise
%    a reasonable number NIter1 of iterations over them at every fixed set of the "non-linear" parameters x
%    should be chosen. After that the value R can be minimized over the "non-linear" parameters x with the
%    "linear" parameters adapted at every step by using any optimization Matlab function.
% 2. Improving the zero-th approximation. All the parameters remain the variable parameters of the model
%    (i.e., with the non-zero steps), and the values x are considered as the zero-th approximation for them,
%    starting with which NIter1 fit steps are performed. The search of the best zero-th approximation can be
%    done via a minimization of the resulting R value over x using any appropriate optimization Matlab function,
%    not excluding the genetic algorithms.
% 3. Switch from the residual sum of squires to another value to be minimized. This goal requires the fragment
%    ALTERNATIVE OUTPUT of the code to be corrected correspondingly. Put NIter1=0 to exclude the Opitmizer
%    iterations and just compute the R value at the chosen point.
%
global ComVarStr
try
    %
    %%%%%%%%%%%EDITABLE FRAGMENT START%%%%%%%%%%%%
    %
    NIter1=10; % number of iterations over the model variable parameters (with non-zero steps) at the given set x of the modFunVec1 parameters
    parNames1={'ndD.cn' 'ndD.gammaD'}; % names of the model parameters to be set to the input x values; are not needed in cases parInd1={[]} and parInd1={0} (see below)
    parInd1={1 1}; % indices of the parameters listed above to be set to the input x values;
    %                                                                              make any entry of it zero to set the entire corresponding parameter to the sequential components of x;
    %                                                                              make it {-1} if all the variable parameters (with non-zero steps) of the model are to be set to x;
    %                                                                              make it {-2} if all the parameters (including the ones with the zero steps) of the model are to be set to x
    % % % possible alternative way to input the data; the corresponding fields of ComVarStr should have the same structure as the items above % % %
    % NIter1=ComVarStr.NIter1;
    % parNames1=ComVarStr.parNames1;
    % parInd1=ComVarStr.parInd1;
    %
    setpara(zeros(size(getpara([],[],0))),0); % put all the parameter fields to zero
    %%%%%%%%%%%EDITABLE FRAGMENT FINISH%%%%%%%%%%%
    %
    NP=length(parNames1);
    if NP>0
        if length(parInd1)==1 && parInd1{1}==-1 % the case to set all the variable parameters (with non-zero steps) of the model to x
            setpara(x,false);
        elseif  length(parInd1)==1 && parInd1{1}==-2 % the case to set all the parameters (including the ones with the zero steps) of the model to x
            setpara(x,true);
        else % the case to set the parameters listed in the EDITABLE FRAGMENT alone to x
            for n=1:NP
                if ~isempty(parInd1{n}) && isreal(parInd1{n})
                    parInd1{n}=round(parInd1{n});
                    NI=size(parInd1{n},1);
                    nx=numel(x);
                    if nx<NI
                        x(nx+1:NI)=0;
                    end
                    k=find(parNames1{n}=='.');
                    if ~isempty(k)
                        if k==1
                            parNames1{n}(1)=[];
                            k=[];
                        elseif k==length(parNames1{n})
                            parNames1{n}(end)=[];
                            k=[];
                        end
                    end
                    if ~isempty(k)
                        C=ComVarStr.(parNames1{n}(1:k-1)).(parNames1{n}(k+1:end));
%                        C=getfield(ComVarStr,parNames1{n}(1:k-1),parNames1{n}(k+1:end));
                    else
                        C=ComVarStr.(parNames1{n});
                    end
                    if size(parInd1{n},2)==1 && all(parInd1{n}>0)
                        for i=1:NI
                            C(parInd1{n}(i))=x(i);
                        end
                        x(1:NI)=[];
                    elseif any(any(parInd1{n}<1))
                        C=reshape(x(1:numel(C)),size(C));
                        x(1:numel(C))=[];
                    else
                        for i=1:NI
                            C(parInd1{n}(i,1),parInd1{n}(i,2))=x(i);
                        end
                        x(1:NI)=[];
                    end
                    if ~isempty(k)
                        ComVarStr.(parNames1{n}(1:k-1)).(parNames1{n}(k+1:end))= C;
%                        ComVarStr = setfield(ComVarStr,parNames1{n}(1:k-1),parNames1{n}(k+1:end),C);
                    else
                        ComVarStr.(parNames1{n})=C;
                    end
                end
            end
        end
    end
    NIter=ComVarStr.StopIter;
    ComVarStr.StopIter=round(NIter1);
    ComVarStr.ifChange=true;
    % EpsIter=ComVarStr.EpsIter;
    % ComVarStr.EpsIter=0;
    if NIter1>0.5
        Optimizer('pbComp_Callback');
    else
        funval;
    end
    ComVarStr.StopIter=NIter;
    y=getresults;
catch
    y=[];
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('modFunVec1 ERROR: check the consistence of all the data including the EDITABLE FRAGMENT of the program code!');
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError=true;
    end
end
return
