function [k,i,j,l]=paracount(n)
% Counts the variables of the (sub)model
%
% USAGE: [k,i]=paracount(n)
%
% Addresses the global structure ComVarStr
%   INPUT
% n - the ordinal number of the (1-D component of the) variable with
%     non-zero step to be numbered
%   OUTPUT
% k - the ordinal number of the procedure the n-th 1-D variable belongs to;
%     if n is not real positive, k is the total number of the 1-D variables
%     with non-zero step
% i - the ordinal number of a (multimentional) variable within the k-th
%     procedure the n-th 1-D variable belongs to;
%     if n is not real positive, i is empty
% j - the ordinal number of the n-th 1-D variable within all varialbles
%     including those with zero step;
%     if n is not real positive, j is empty.
% l - the ordinal number of the n-th 1-D variable within all components
%     of i-th multidimensional variable of k-th procedure
global ComVarStr
%%%%%%%%%%%%%%%%%%% The commented line in this block can be uncommented for
%%%%%%%%%%%%%%%%%%% a better performance if no alteration to the varied
%%%%%%%%%%%%%%%%%%% variables set is done; in part, if the batch
%%%%%%%%%%%%%%%%%%% regime is turned off
% persistent kks
try
%     if isempty(kks) || nargin==0
        npr=length(ComVarStr.Proc);
        kks=zeros(npr,1);
        for k1=1:npr
            [y,kks(k1)]=getpara (k1,[],false,true);
        end
%     end
%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%
    if nargin==0 || isempty(n) || ~isreal(n) || n<=0
        k=kks(end);
        i=[];
        j=[];
        l=[];
%         disp('paracount ERROR 1');
%         return
    end
    k=find(kks>=n,1,'first');
    if nargout<=1
        return
    end
    if isempty(k)
        i=[];
        j=[];
        l=[];
%         disp(num2str(n));
%         disp(num2str(kks));
%         disp('paracount ERROR 2');
        return
    end
    if k==1
        k3=0;
    else
        [y,k2,k3]=getpara (k-1,[],false,true);
    end
    for k1=1:length(ComVarStr.ParField{k})
        j=k3;
        [y,k2,k3]=getpara (k,k1,false,true);
        if k2<n
            continue;
        else
            i=k1;
            if nargout>2
                k3=j;
                k0=find(ComVarStr.ParStep~=0);
                j=k0(n);
                l=j-k3;
            end
            return
        end
    end
    i=[];
catch mectc
    ierr=-i0; % something is wrong with the i0-th parameter
    if isfield(ComVarStr,'ifDisp') && ComVarStr.ifDisp
        beep;
        disp('paracount ERROR');
        disp(mectc.message);
%         mectc.stack
%         disp('file:');
%         mectc.stack.file
%         disp('line:');
%         mectc.stack.line
% %        mectc.cause
        beep;
    end
end
return