function ifC = Fitinou(key0)
% Input and output of the Optimizer contents from (into) text files
%
% USAGE: ifC = Fitinou(key0)
%
% Addresses the global structure ComVarStr.
% key0 is a text string defining a kind of the program action:
%      = 'in' or omitted
%         input values to be modeled from a file
%      = 'out'
%         output result of the modeling to the file
% All the data read from or written to files are global variables.
%

global V_style  % style of the input columns if available
global V_Inp    % the input column if available
global V_Cov  % covariance matrix if available
global ComVarStr;
persistent pname

ifC=false; % ifC = true if the action was cancelled

% warning off;
key=0;

while (key==0)

  try
    if (nargin==0 || strcmp(key0,'in'))
%
        ifStyle=false;
        V_style=[];
        V_Inp=[];
        ifCov=false;
        V_Cov=[];
        [fname1,pname1] = uigetfile(strcat(pname,'*.*'),'Input file');
        if isequal(fname1,0)
            ifC=true;
            return
        end
        name1=strcat(pname1,fname1);
        pname=pname1;
        fid = fopen(name1,'r');
        k=0;  % for the dimension counting
        m=0;  % for the dimension counting
        n0=0; % for the dimension counting
        iC=1; % first  index of the covariance matrix
        jC=0; % second index of the covariance matrix
        while feof(fid) == 0
            a = fgetl(fid);
                if n0==0 && k==0 && ~isempty(a)
                    if ~ifStyle || m==0 % starting input and getting the structure of the file
                        %
                        while k>=0 % endless loop
                            k0=k;
                            a = deblank(strjust(a,'left'));
                            if isempty(a)
                                break;
                            end
                            try
                                if strncmpi('None',a,4) || strncmpi('NONE',a,4) || strncmpi('none',a,4)
                                    k=k+1;
                                    V_style{k}='None';
                                    a(1:4)=[];
                                    n  = find(isletter(a)); % find the next letter going after a non-letter
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(isletter(a));
                                    end
                                    n =  find(~isletter(a));
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(~isletter(a));
                                    end
                                end
                            catch
                            end
                            try
                                if strncmpi('YErr',a,4) || strncmpi('Yerr',a,4) || strncmpi('YERR',a,4) || strncmpi('yerr',a,4)
                                    k=k+1;
                                    V_style{k}='YErr';
                                    a(1:4)=[];
                                    n  = find(isletter(a)); % find the next letter going after a non-letter
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(isletter(a));
                                    end
                                    n =  find(~isletter(a));
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(~isletter(a));
                                    end
                                end
                            catch
                            end
                            try
                                if (strncmpi('X',a,1) || strncmpi('x',a,1)) && (length(a)==1 || ~isletter(a(2)))
                                    k=k+1;
                                    V_style{k}='X';
                                    a(1)=[];
                                    n  = find(isletter(a)); % find the next letter going after a non-letter
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(isletter(a));
                                    end
                                    n =  find(~isletter(a));
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(~isletter(a));
                                    end
                                end
                            catch
                            end
                            try
                                if (strncmpi('Y',a,1) || strncmpi('y',a,1)) && (length(a)==1 || ~isletter(a(2)))
                                    k=k+1;
                                    V_style{k}='Y';
                                    a(1)=[];
                                    n  = find(isletter(a)); % find the next letter going after a non-letter
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(isletter(a));
                                    end
                                    n =  find(~isletter(a));
                                    while ~isempty(n) && n(1)==1
                                        a(1)=[];
                                        n  = find(~isletter(a));
                                    end
                                end
                            catch
                            end
                            if k~=k0 % both k and k0 are the length of the style varialble at the output of the loop
                                ifStyle=true;
                            else
                                break;
                            end
                        end
                        if ifStyle
                            a = fgetl(fid);
                        end
                        while m>=0 % endless loop
                            n=find( (a<'0' | a>'9') & a~='.' & a~='-' & a~='+' & ~isletter(a));
                            while ~isempty(n) && n(1)==1
                                a(1) = [];
                                n=find( (a<'0' | a>'9') & a~='.' & a~='-' & a~='+' & ~isletter(a));
                            end
                            if isempty(n)
                                n=length(a);
                            else
                                n=n(1)-1;
                            end
                            if n==0
                                break;
                            end
                            b=str2num(a(1:n));
                            a(1:n)=[];
                            if ~isempty(b);
                                m=m+1;
                                n0=1;
                                V_Inp(n0,m)=b;
                            else
                                break;
                            end
                        end
                    end
                    %
                    if m>0
                        if k>0
                            k=min(k,m);
                        else
                            k=m;
                        end
                    end
                elseif ~ifCov % general input
                    b=str2num(a);
                    if ~isempty(b)
                        try
                            V_Inp(n0+1,1:k)=b(1:k);
                            n0=n0+1;
                        catch
                        end
                    else
                        try
                            n = ~isletter(a);
                            while ~isempty(n) && n(1)==1
                                a(1)=[];
                                n = ~isletter(a);
                            end
                            if strncmpi('Covariance',a,10)
                                ifCov=true;
                                if n0>0
                                    V_Cov = diag(ones(n0,1));
                                end
                            end
                        catch
                        end
                    end
                else % input of the covariance matrix
                    try
                        b=str2num(a);
                        if ~isempty(b)
                            for i=1:length(b)
                                if jC<n0
                                    jC=jC+1;
                                elseif iC<=n0
                                    iC=iC+1;
                                    jC=1;
                                else
                                    return
                                end
                                V_Cov(iC,jC) = b(i);
                            end
                        end
                    catch
                        ifCov=false;
                        V_Cov=[];
                        return
                    end
                end
        end
        status = fclose(fid);
        if isfield(ComVarStr,'ifSparse') && ComVarStr.ifSparse && all(size(V_Cov)>1)
            V_Cov=sparse(V_Cov);
        end
        return

    elseif strcmp(key0,'out')
%
        [fname2,pname2] = uiputfile(strcat(pname,'*.*'),'Output file');
        if isequal(fname2,0)
            ifC=true;
            return
        end
        kpnt = findstr(fname2,'.');
        if isempty(kpnt) 
            fname2 = strcat(fname2,'.DAT');
        elseif length(fname2) == kpnt || ~isempty(findstr(fname2(kpnt+1:end),'*'))
            fname2(kpnt:end)=[];
            fname2 = strcat(fname2,'.DAT');
        end
        name2=strcat(pname2,fname2);
        pname=pname2;
        fid = fopen(name2,'w');
        %
        % get lengths and find the shortest one
        try
            kX    = length(ComVarStr.X0);
        catch
            kX    = realmax; % largest real number
        end
        if kX==0
            kX    = realmax; % largest real number
        end
        try
            kY    = length(ComVarStr.input);
        catch
            kY    = realmax; % largest real number
        end
        if kY==0
            kY    = realmax; % largest real number
        end
        try
            if any(size(ComVarStr.inpCovar)==1)
                kYerr = max(size(ComVarStr.inpCovar));
            else
                kYerr = realmax; % largest real number
            end
        catch
            kYerr = realmax; % largest real number
        end
        if kYerr==0
            kYerr = realmax; % largest real number
        end
        Z = getresults;
        kZ = length(Z);
        if kZ==0
            kZ    = realmax; % largest real number
        end
        k0 = min([kX kY kYerr kZ]);
        %
        % collect data for the output
        C = ''; % heading string
        s = ''; % output format
        C0 =[]; % output data
        if isfield(ComVarStr,'X0') && ~isempty(ComVarStr.X0)
            C  = strcat(C,'  X');
            s = strcat(s,' %-26.16g ');
            C0 = reshape(ComVarStr.X0(1:k0),k0,1);
        end
        if isfield(ComVarStr,'input') && ~isempty(ComVarStr.input)
            C = strcat(C,'                          Y');
            s = strcat(s,' %-26.16g ');
            try
                C0 = [C0 reshape(ComVarStr.input(1:k0),k0,1)];
            catch
                C0 = reshape(ComVarStr.input(1:k0),k0,1);
            end
        end
        if isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
            C = strcat(C,'                          Yerr');
            s = strcat(s,' %-26.16g ');
            try
                C0 = [C0 reshape(ComVarStr.inpCovar(1:k0),k0,1)];
            catch
                C0 = reshape(ComVarStr.inpCovar(1:k0),k0,1);
            end
        end
        if ~isempty(Z)
            C = strcat(C,'                          Ysim');
            s = strcat(s,' %-26.16g ');
            try
                C0 = [C0 reshape(Z(1:k0),k0,1)];
            catch
                C0 = reshape(Z(1:k0),k0,1);
            end
            if isfield(ComVarStr,'input') && ~isempty(ComVarStr.input)
                C = strcat(C,'                          Y-Ysim');
                s = strcat(s,' %-26.16g ');
                try
                    C0 = [C0 reshape(ComVarStr.input(1:k0)-Z(1:k0),k0,1)];
                catch
                    C0 = reshape(ComVarStr.input(1:k0)-Z(1:k0),k0,1);
                end
            end
        end
        fprintf (fid,strcat(C,' \r\n'));
        for i=1:k0
            fprintf (fid,strcat(s,' \r\n'),C0(i,:));
        end
        try
            if all(size(ComVarStr.inpCovar)>1)
                k0 = size(ComVarStr.inpCovar,1);
                fprintf(fid,'Covariance\r\n');
                s = '%-26.16g ';
                for i=2:k0
                    s = strcat(s,' %-26.16g ');
                end
                for i=1:k0
                    fprintf (fid,strcat(s,' \r\n'),full(ComVarStr.inpCovar(i,:)));
                end
            end
        catch
        end
        status = fclose(fid);
        key=1;
        return
        
    end

  catch
      try
        status = fclose(fid);
      catch
      end
  end
end
% warning on;
return
