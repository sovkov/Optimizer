function CVS = altnm (CVS,str0,str1)
% In a structure CVS (implied ComVarStr), substitutes all entries of the substring str0 by the substring str1
%
% USAGE: CVS = altnm (CVS,str0,str1)
%

if isstruct(CVS)
    nm0 = fieldnames(CVS);
    if isempty(nm0)
        return;
    end

    nm=chknm(nm0,str0,str1);
    CVS = fldsbs(CVS,nm0,nm);
    nm0 = nm;

    if iscell(nm0)
        for k=1:numel(nm0)
            if ischar(CVS.(nm0{k}))
                CVS.(nm0{k}) = altnm (CVS.(nm0{k}),str0,str1);
            elseif isstruct(CVS.(nm0{k})) || iscell(CVS.(nm0{k}))
                for n=1:numel(CVS.(nm0{k}))
                    CVS.(nm0{k})(n) = altnm (CVS.(nm0{k})(n),str0,str1);
                end
            end
        end
    else
        CVS.(nm0) = altnm (CVS.(nm0),str0,str1);
    end
else
    CVS=chknm(CVS,str0,str1);
end

return
end

function str=chknm(str,str0,str1)
if ~ischar(str0) || ~ischar(str1)
    return;
end
N0 = length(str0);
if iscell(str)
    for k=1:numel(str)
        if ~ischar(str{k})
            continue;
        end
        IND = strfind(str{k},str0);
        for n=1:numel(IND)
            str{k} = strcat(str{k}(1:IND(n)-1),str1,str{k}(IND(n)+N0:end));
        end
    end
elseif ischar(str)
    IND = strfind(str,str0);
    for n=1:numel(IND)
        str = strcat(str(1:IND(n)-1),str1,str(IND(n)+N0:end));
    end
end
return
end

function CVS = fldsbs(CVS0,nm1,nm2)
if ischar(nm1) && ischar(nm2)
    CVS.(nm2) = CVS0.(nm1);
elseif iscell(nm1) && iscell(nm2) && numel(nm1)==numel(nm2)
    for k=1:numel(nm1)
        if ~ischar(nm1{k}) || ~ischar(nm2{k})
            continue;
        else
            CVS.(nm2{k}) = CVS0.(nm1{k});
        end
    end
end
return
end