function [ierr,R,y,iCmin]=LSF(ifDf,ifDer,y0,R0)
% One step of the general nonlinear Least-Square Fit procedure performed via a local linearization
%
% USAGE: [ierr,R,y,iCmin]=LSF(ifDf,ifDer,y0,R0)
%
% Addresses the global structure ComVarStr.
% INPUT
% ifDf  - logical variable: if does not exist it is treated as false
%      = true  - contents of the output fields of the global structure
%                ComVarStr (see the OUTPUT description below) are to be computed;
%      = false - no need of the above computations; the contents of the
%                corresponding global structure fields are emptied;
%                the last regime does not support any constraints analysis.
% ifDer - logical variable: if does not exist it is treated as false
%      = true means that the local construction matrix (1-st derivatives)
%             can be attempted to be read from the field Der1 of the global
%             structure ComVarStr (meant to be computed and placed there by
%             the model-computing procedure with the name contained in
%             ComVarStr.Proc(i).Name);
%      = false, empty, or does not exist means that the derivatives are to
%             be computed using the finite-difference equation
% y0 - if exists, column vector containing an approximation of the data to
%      be fitted at the point of the 0-th approximation; if does not exist
%      then this value will be computed within the procedure
% R0 - if exists, evaluation function at the point of the 0-th
%      approximation; if does not exist then this value will be computed
%      within the procedure
% a further INPUT -  see "initialization" section below for a description
% of the parameters read from the global structure ComVarStr;
% the parameters which are not described there:
% StopIterLM- maximum allowed number of iterations performed to adapt the
%           step length
% kkk     - if exists and is scalar value >0, a parameter of a "rough" regularization, namely
%                           if 1<=kkk<m - number of first singular 1-D
%                                         subspaces to contribute into the
%                                         solution vector (higher subspaces
%                                         to be ignored);
%                           if 0<=kkk<1 - level of reliability, so that the
%                                         number of first singular 1-D
%                                         subspaces contributing into the
%                                         solution vector is found as a
%                                         lower boundary at which the relation
%                                         of the current singular value to
%                                         the first one becomes less or
%                                         equal than kkk
%           if exists and is a matrix than it is treated as a matrix of linear
%           constraints kkk*f=lambda playing the role of the null hypothesis
%           to be checked according the Fisher criterium.
%           NOTE: the matrix kkk should not be singular. Some singularities
%           (presence of zero rows or of equal rows) are checked and
%           corrected, and, if the rank of the corrected kkk matrix becomes zero,
%           it is treated as if kkk=size(A,1), lambda=0 at the input;
%           if some inconsistences in the matrix kkk and vector lambda are
%           found, then it is treated as if kkk=size(A,1), lambda=0 at the
%           input and the output k0(2)=0.
% lambda  - (1) if exists and ~=0 when kkk is a scalar value
%               (or kkk does not exist) and ifplot does not exist:
%               parameter of the Tikhonov regularization
%               (implied to be chosen so that to minimize the solution norm
%               without effecting the residual sum of squares significantly);
%           (2) if exists when kkk is a matrix and ifplot does not exist:
%               lambda plays a role of the right-hand vector
%               of linear constraints to be checked (see the kkk description above);
%           (3) if exists when ifplot exists and length(lambda)==3, its
%               elements are treated as lower boundary, upper boundary and
%               number of point of a grid at which the L-curve method is
%               applied to find the optimal regularization parameter
%           (4) if does not exist than is treated as lambda=0 for any regime;
% ifplot  - logical variable; if exists and length(lambda)=3 it means that
%           the L-curve method is to be applied to find the optimal
%           regularization parameter; in a case ifplot=true the graphic
%           representation of the L-curve method is produced, otherwise is
%           not.
% VPALim  - if exists and not equal 16, than a regime of computations with
%           a high precision is used. This case VPALim significant digits
%           are traced.
%           REMARKS: (1) this regime slows down the computations.
%                    (2) this value only effects intermediate computations;
%                        all the results are returned as usual double
%                        precision MATLAB variables
% ifDisp  - if exists and ==true, some intermediate messages are output
%           into he MATLAB command window with the aim of computations
%           tracking
% LMinist - if exists and nonzero, its absolute value is treated as the
%           initial value of the Levenberg-Marquardt parameter (where 0
%           corresponds to the 0-th approximation; =infinity corresponds
%           to the full LSF step); >0---the initial LSF parameter is adapted
%           (altered) at every next step of the LSF process, <0---the initial
%           LSF parameter is restored to LMinist to at every next step of the
%           LSF process default LMinist = 10^(VPALim/2).
% OUTPUT
% the field with the parameter values are re-newed at the output;
% if the function is called without output and/or input arguments,
% it just empties its own persistent parameters (LMstep0)
% ierr    - error flag
%           =0 everuthing is OK
%           =1 the step was adapted during the computations
%           =2 no convergence was found in the iterative step adaptation;
%              the output parameters are re-newed according to the final
%              result found at the exit from the iteration
%           =3 no parameters were varied in an accordance to the input step
%              values
%           =4 coordinate-wise step was performed due to it resulted in an
%              actual current minimum (when ComVarStr.ifStAd is true or
%              non-logical)
%           <0 critical error; the computation is seized
% R       - final residual sum of squares
% y       - column vector containing the final approximation of the right-hand
%           data vector (implied to be fitted)
% iCmin   - the ordinal number of the varied parameter producing the
%           minimum in a case the coordinate-wise minimum is adopted;
%           otherwise iCmin=0
% further OUTPUT is written to the global structure ComVarStr into the
% fields with the same names as the OUTPUT parameters
% sigma2  - estimate of the variance (sigma^2) of the right-hand values g
%           so, the estimate of the f covariance matrix can be
%           computed as sigma2*Df; standard deviations of the solution can
%           be computed as sqrt(sigma2*diag(Df)); the residual sum of squares
%           R0 = sigma2*(n-k0(1)) (see k0 below);
% Df      - covariance matrix of the solution f implying that the g values
%           standard deviation is indeed 1; otherwise the actual covariance
%           matrix can be computed by multiplying this one by the actual
%           standard deviation of g;
% kkk0    - vector:
%           kkk0(1) is always actual number of 1-D singular subspaces contributed into the solution
%                   (higher subspaces were ignored due to an input truncation condition
%                    or due to zero singular values);
%           kkk0(2) is recommended number of 1-D singular subspaces to be used 
%                   for the reason the unstability crashes numerical
%                   precision
%           kkk0(3) is only outputted if input kkk is a matrix; this case
%                   it contains the p-level of the null hypothesis checked based on
%                   the Fisher criterium
%           kkk0(4) is only outputted if input kkk is a matrix; this case
%                   it contains actual number of the constraints which were considered
% lambda0 - actual value of regularization parameter lambda if it was found
%           via the L-curve method;
%           otherwise it remains undefined
%
% NOTICE: in a regime with the Fisher test (when input k is a matrix),
%         the LSF solution without constrains is only computed.
%
%
global ComVarStr
persistent LMstep0 % to keep and adapt the initial step for the Levenberg-Marquardt process
[CN,~,~]=Optimizer('getOpVal');        % get the parameter names in the original order
if nargout==0 || nargin==0
    LMstep0=[];
    return;
end
try
ierr  = 0;
y=[]; % for a case of an unexpected exit, so that all the output parameters to be defined.
iCm   = -1; % used below to indicate the "return to the current minimum" regime;
%           % 1 will mean that the current minimum is step-wise, 2 will
%           % mean it is detected in the Levenberg-Marquardt procedure
iCmin = 0;
ifDisp = ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1);
%
% initialization
%
%
% zero-th approximation
%
% find intital values of the function if needed
%
if ifDisp
    disp('          LSF: Initialization');
end
ifD=1; % to be used when attempting to extract the "analytical" design matrix
if  isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange) && ComVarStr.ifChange(1)
    [ierr,y0]=funval;
    if ierr~=0
        ifD=2; % to avoid extra recomputing the model for the "analitical" design matrix
        ComVarStr.ifChange=false;
    end
end
if nargin<=2 || ~isnumeric(y0) || isempty(y0) || (ifDer && (~isfield(ComVarStr,'Der1') || isempty(ComVarStr.Der1) || ~isnumeric(ComVarStr.Der1)))
    if ~isnumeric(y0) || isempty(y0)
        y0 = getresults;
    end
    if isempty(y0) || (ifDer && (~isfield(ComVarStr,'Der1') || isempty(ComVarStr.Der1) || ~isnumeric(ComVarStr.Der1)))
        if ~isnumeric(y0) || isempty(y0)
            [ierr,y0]=funval;
            if ierr~=0
                ifD=2; % to avoid extra recomputing the model for the "analytical" design matrix
            end
        end
        R0=[];
        if ierr~=0
            y=[];
            R=[];
            return;
        end
    end
end
%
if nargin<=0 || isempty(ifDer)
    ifDer=false;
end
%
ParField=ComVarStr.ParField; % the name of the ComVarStr structure field containing the cell array of the names of the main procedure parameters to be varied
ParStep =ComVarStr.ParStep;  % variational steps of the varied parameters in the same order as they are listed in ParField
input=ComVarStr.input; % input is a vector containig actual "measured" values
if size(input,1)==1
    input=input';
end
try
    if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isnumeric(ComVarStr.inpCov))) && ( size(ComVarStr.inpCov,1)==length(input) && (size(ComVarStr.inpCov,2)==length(input) || size(ComVarStr.inpCov,2)==1) ) && ~all(all(ComVarStr.inpCov==0))
        D=ComVarStr.inpCov; % attempt to get a "refreshed" covariance matrix
    elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar) && all(all(isnumeric(ComVarStr.inpCovar)))  && ~all(all(ComVarStr.inpCovar==0))
        D=ComVarStr.inpCovar; % D is either a vector of errors of the statistically independent "input" data or their covariance matrix
    else
        D = ones(length(input),1); % default covariance matrix
    end
    if isempty(D) || ~isreal(D) || ( (size(D,1)~=length(input) && (size(D,2)~=length(input) || size(D,2)~=1)) && (size(D,2)~=length(input) && size(D,1)~=1) )
        D=ones(length(input),1); % default covariance matrix
    elseif size(D,1)==1
        D = D';
    end
catch
    D=[];
end
%
% initial residual sum of squares
if nargin<3 || any(size(R0)~=1) || ~isnumeric(R0)
    R0 = resi(input,y0,D); % initial residual sum of squares
end
% find M0 - actual number of the parameters to be varied
kkk1 = find(ParStep==0);
M0 = length(ParStep) - length(kkk1);
if M0==0
    ierr=3;
    y=[];
    R=[];
    return;
end
%
try
    StopIterLM=ComVarStr.StopIterLM;
    if any(size(StopIterLM)~=1) || ~isreal(StopIterLM)
        StopIterLM=32;
    end
catch
    StopIterLM=32;
end
try
    VPALim=ComVarStr.VPALim;
    if any(size(VPALim)~=1) || ~isreal(VPALim)
        VPALim=16;
    end
catch
    VPALim=16;
end
%
try
    kkk=ComVarStr.kkk;
    if ~isnumeric(kkk)
        kkk=[];
    end
catch
    kkk=[];
end
try
    lambda=ComVarStr.lambda;
    if ~isnumeric(lambda)
        lambda=0;
    end
catch
    lambda=0;
end
ifplot=false;
try
    if length(lambda)==3 && (size(kkk,1)~=3 || size(kkk,2)~=M0)
        ifplot=ComVarStr.ifplot;
    end
catch
end
ifAdopConstr=false;
if ~isempty(kkk) && ~isempty(lambda) && size(kkk,2)==M0 && size(kkk,1)==length(lambda) % ~isempty(..) are needed as sometimes the size can be 0xM0, etc.
    try
        ifAdopConstr=ComVarStr.ifAdopConstr;
    catch
    end
elseif all(size(kkk)==1)
    try
        if ~ComVarStr.ifAdopConstr % if there is no need to adopt the SVD truncation
            kkk = 0;
        end
    catch
    end
end
%
% collect initial values of the parameters in a double-indexed cell x
%
x=collectparam;
%
% number of labs available in the multiprocess regime
%
if isfield (ComVarStr,'ifMuPr') && ~isempty(ComVarStr.ifMuPr) && ComVarStr.ifMuPr(1)>0
    ifMuPr=true;
    try
        poolobj = gcp('nocreate');
        if isempty(poolobj)
            Mmp=0;
        else
            Mmp=poolobj.NumWorkers;
        end
%        Mmp=feval('matlabpool','size');
    catch
        Mmp=1;
    end
else
    ifMuPr=false;
    Mmp=1;
end
%
% find Der - a matrix of 1-st derivatives which plays a role of a local design matrix
%
if ifDer
    while ifD>0
        try
            Der=ComVarStr.Der1;  % try to get the matrix of 1-st derivatives if it was computed in the model procedure and placed to the field ComVarStr.Der1
%            Der=getfield(ComVarStr,'Der1');  % try to get the matrix of 1-st derivatives if it was computed in the model procedure and placed to the field ComVarStr.Der1
            if isempty(Der) || size(Der,1)~=length(input) || size(Der,2)~=M0 || ~isnumeric(Der) % <M0 if attempt to exclude the non-varied variables is to be done
                if ifD==1
                    ifD=2;
                    [ierr,y0]=funval;
                    Der=ComVarStr.Der1;
                else
                    ifD=0;
                end
            else
                ifD=-1;
            end
        catch
            if ifD==1
                ifD=2;
                [ierr,y0]=funval;
            else
                ifD=0;
            end
        end
    end
    if ~ifD
        ifDer=false;
        if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer)
            ComVarStr.ifDer.ifDer=false;
            ComVarStr.Der1=[];
            ComVarStr.locDer=[];
        end
    end
end
fCmin=[]; % for indication purposes
RCmin=R0; % current minimum
if ifDisp
    disp(strcat('              R0=',num2str(R0)));
end
if ~ifDer % otherwise compute it with the finite-difference equation using the procedure Deriv1
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ifMuPr
        if ifDisp
            disp(strcat('LSF: multiprocess computation of the local derivatives, nlabs=',num2str(Mmp)));
        end
%        if ~isfield(ComVarStr,'ifStAd') || isempty(ComVarStr.ifStAd) || ComVarStr.ifStAd(1)
            if (~isfield(ComVarStr,'ifCoAd') || isempty(ComVarStr.ifCoAd) || ComVarStr.ifCoAd(1)) && (isfield(ComVarStr,'ifLM') && ~isempty(ComVarStr.ifLM) && ComVarStr.ifLM(1))
                [ierr,Der,fCmin,yCmin,RCmin,iCmin]=Deriv1mp(R0,y0); % adapt steps for a differentiation and adopt the coordinate-wise minimum RCmin in fCmin correction vector
            else
                [ierr,Der]=Deriv1mp(R0,y0); % adapt steps for a differentiation
            end
%         else
%             if (~isfield(ComVarStr,'ifCoAd') || isempty(ComVarStr.ifCoAd) || ComVarStr.ifCoAd(1)) && (isfield(ComVarStr,'ifLM') && ~isempty(ComVarStr.ifLM) && ComVarStr.ifLM(1))
%                 [ierr,Der,fCmin,yCmin,RCmin,iCmin]=Deriv1mp(-R0,y0); % adopt the coordinate-wise minimum RCmin in fCmin correction vector
%             else
%                 [ierr,Der]=Deriv1mp(-R0,y0);
%             end
%         end
%        global ComVarStr;
        if ierr==-1000
            ifMuPr=false;
            if ifDisp
                disp('LSF: multiprocess computation of the local derivatives failed, turned to the one-process routine');
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~ifMuPr
        if ifDisp
            disp('LSF: computation of the local derivatives');
        end
%        if ~isfield(ComVarStr,'ifStAd') || isempty(ComVarStr.ifStAd) || ComVarStr.ifStAd(1)
            if (~isfield(ComVarStr,'ifCoAd') || isempty(ComVarStr.ifCoAd) || ComVarStr.ifCoAd(1)) && (isfield(ComVarStr,'ifLM') && ~isempty(ComVarStr.ifLM) && ComVarStr.ifLM(1))
                [ierr,Der,fCmin,yCmin,RCmin,iCmin]=Deriv1(R0,y0); % adapt steps for a differentiation and adopt the coordinate-wise minimum RCmin in fCmin correction vector
            else
                [ierr,Der]=Deriv1(R0,y0); % adapt steps for a differentiation
            end
%         else
%             if (~isfield(ComVarStr,'ifCoAd') || isempty(ComVarStr.ifCoAd) || ComVarStr.ifCoAd(1)) && (isfield(ComVarStr,'ifLM') && ~isempty(ComVarStr.ifLM) && ComVarStr.ifLM(1))
%                 if ifDisp
%                     disp(strcat('initial R0=',num2str(R0)));
%                 end
%                 [ierr,Der,fCmin,yCmin,RCmin,iCmin]=Deriv1(-R0,y0); % adopt the coordinate-wise minimum RCmin in fCmin correction vector
%             else
%                 [ierr,Der]=Deriv1(-R0,y0);
%             end
%         end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ierr<0
        y=[];
        R=[];
        return;
    end
    if isfield(ComVarStr,'ifDerkeep') && ~isempty(ComVarStr.ifDerkeep) && ComVarStr.ifDerkeep(1)
        ComVarStr.Parkeep = x;   % keep the current zero approximation
        ComVarStr.Derkeep = Der; % keep the current derivatives
    end
    if ifDisp
        if iCmin
            disp(strcat(' Current minimum is R=',num2str(RCmin),' (R-R0=',num2str(RCmin-R0),') [parameter No.',num2str(iCmin),'--',CN{iCmin},']'));
        else
            disp(' No current minimum better than R0 has been found or adopted yet');
        end
    end
end
%
% find the local solution
%
g = input-y0; % local right-hand vector
rel=lambda; % so that not to spoil the initial lambda
% if (~isscalar(rel) || ~isnueric(rel) || isnan(rel) || isninf(rel)) && (~isfield(ComVarStr,'ifGrad') || isempty(ComVarStr.ifGrad) || ComVarStr.ifGrad(1))
%     rel=10^VPALim;
% end
if any (size(kkk)>1) && any(size(kkk)==size(lambda))
    try
        x0 = getpara; % column vector of the 0-th order parameters
        if ~isempty(kkk1)
            x0(kkk1) = []; % kkk1 are the indexes of the ParStep zero values computed above
        end
        rel = rel - kkk*x0; % local form of the right-hand constraints vector;
    catch
    end
end
if ifDisp
    disp('          LSF: Finds local solution');
end
if ifDf
    [f,sigma2,Df,ComVarStr.Dfi,kkk0,S,V,U,lambda0] = MNKlin (Der,g,D,kkk,rel,ifplot,VPALim); % general case
    if isempty(f)
%        setpara(x0);
        [ierr0,y]=funval;
        R=R0;
        if ifDisp
            disp('      LSF warning: Empty solution. Design matrix can be incorrect');
        end
        return;
    end
    if ifAdopConstr % adopt the constraint
        [f,Df] = AdopConstr(f,Df,kkk,rel); % adopt constraints if needed
        RCmin=Inf;
    end
    try % find the p-value for the truncation regime
        if ~(size(kkk,2)==M0 && size(kkk,1)==length(lambda)) && ~isempty(ComVarStr.kkk)
            if isempty(kkk) || kkk==0
                if ComVarStr.kkk<1
                    [f1,sigma21,Df1,Dfi,kkk01] = MNKlin (Der,g,D,ComVarStr.kkk,rel,ifplot,VPALim); % to find the limiting singular value number
                    kkk1 = kkk01(1);
                else
                    kkk1 = ComVarStr.kkk;
                end
            else
                kkk1 = kkk0(1);
            end
            if kkk1<length(S)
                try
                    [f1,sigma21,Df1,Dfi,kkk01] = MNKlin ([],g,D,(V(:,kkk1+1:length(S)))',zeros(length(S)-kkk1,1),ifplot,VPALim); % to find the p-value
                catch
                    [f1,sigma21,Df1,Dfi,kkk01] = MNKlin (Der,g,D,(V(:,kkk1+1:length(S)))',zeros(length(S)-kkk1,1),ifplot,VPALim); % to find the p-value
                end
                kkk0(3) = kkk01(3);
                clear f1;
                clear sigma21;
                clear Df1;
                clear kkk01;
            else
                kkk0(3) = 1;
            end
            clear kkk1;
        end
    catch
    end
else
    f = MNKlin (Der,g,D,Dfi,kkk,lambda,ifplot,VPALim); % general case
    if isempty(f)
%        setpara(x0);
        R=R0;
        [ierr0,y]=funval;
        return;
    end
end
%
% correction of parameters
%
try
    if isfield(ComVarStr,'LMinist') && ~isempty(ComVarStr.LMinist) && isreal(ComVarStr.LMinist(1)) && (ComVarStr.LMinist(1)<0 || isempty(LMstep0) || LMstep0<=0 || isinf(LMstep0) || isnan(LMstep0) || ~isreal(LMstep0))
        LMstep0 = abs(ComVarStr.LMinist(1)); % initial Levenberg-Marquardt step length measured in values of the maximum singular value
    elseif isempty(LMstep0) || LMstep0<=0 || isinf(LMstep0) || isnan(LMstep0) || ~isreal(LMstep0)
        LMstep0 = 10^ceil(VPALim/2);
    end
catch
    LMstep0 = 10^ceil(VPALim/2);
end
step=Inf;
stepRight=Inf; % to keep maximum available step
RRight=[];
stepLeft=0;   % to keep minimum available step; reserve - currently keeps the initial value all the way
RLeft=R0;
R1=[]; % will be the next iteration for the residual sum of squares
if (isempty(fCmin) || isempty(RCmin)) && ~ifAdopConstr
    fCmin  = zeros(size(f)); % will be the set of the parameters corresponding to the current minimum
    yCmin=y0;
    RCmin = R0;             % will be the residual sum of squres at the current minimum
end
R = Inf;                % will be a current value of the evaluation function
ierr0=-1;
iter=0;
stepCmin=0;
st=[];
%
% IF THERE IS NO NEED IN THE LEVENBERG-MARQUARDT ALGORITHM
if ~isfield(ComVarStr,'ifLM') || isempty(ComVarStr.ifLM) || ~ComVarStr.ifLM || isempty(fCmin) % no need in Levenberg-Marquardt step adaptation
    if ifDisp
        disp('LSF: Corrects parameters and results');
    end
    [R,y,ierr0]=runMoS(x,f,[],iter,R0); % computes the evaluation function at the point shifted by f from x0
    % fCmin is empty if we returned to the previously found local minimum and intend to stop the computing 
else % LEVENBERG-MARQUARDT ALGORITHM
    if ifDisp
        disp('-');
        if ~isfield(ComVarStr,'ifGrad') || isempty(ComVarStr.ifGrad) || ~ComVarStr.ifGrad(1)
            disp('LSF: Levenberg-Marquardt process');
            disp('In further output the ''LM parameter'' is the inverse Levenberg-Marquardt step in the units of the 1st singular value');
            disp('so that the Inf step corresponds to the full Gauss prediction and the 0 step corresponds to the initial zero-th approximation');
        else
            disp('LSF: Gradient Descent process');
            disp('In further output the ''LM parameter'' is the gradient descent step in the units of the 1st singular value');
        end
        disp('-');
    end
    if Mmp>=2
        RMmp=zeros(Mmp,1);
        ierr0Mmp=zeros(Mmp,1);
        stepMmp=zeros(Mmp,1);
        fMmp=zeros(length(f),Mmp);
        yMmp=zeros(length(y0),Mmp);
    end
    k=Mmp;
    ifDone=false; % to indicate if the required computation has been already done in a multiprocess case
    RCLM=R0; % to keep a current minimum in the LM iterations (independently of the coordinat-wise current minimum)
    stepCLM=0;
    while true % (ierr0==-1 && (iter<=StopIterLM || isempty(R) || isnan(R) || isinf(R) || R<0)) && R~=0 % R=-1 can indicate an error, and we do not want to exit with an erroneous solution
        try
            if ierr0~=-2
                ierr0 = 0; % initialization at every step except the "return to the current minimum" phase
            end
            if Mmp<2 && ~ifDone
                iter = iter+1; % current number of direct model computations
                [R,y,ierr0]=runMoS(x,f,[],iter,R0,step); % computes the evaluation function at the point shifted by step from x0
                k=1;
    %             if R>RCmin && isinf(step)
    %                 step=10^VPALim;
    %             end
            elseif ~ifDone
                iter = iter+1; % current number of direct model computations
                stepMmp(1)=step;
                if ~isinf(step)
                    k0=2;
                else
                    k0=3;
                    stepMmp(2)=LMstep0;
                end
                for k=k0:Mmp
                    stepMmp(k) = stepLeft + (stepMmp(k-1)-stepLeft)/2;
                end
                fMmp(:,1)=f;
                for k=1:Mmp-1
                    try
                        fMmp(:,k+1)=MNKlin([],g,D,kkk,1/stepMmp(k+1),false,VPALim);
                    catch
                        fMmp(:,k+1)=MNKlin(Der,g,D,kkk,1/stepMmp(k+1),false,VPALim);
                    end
                end
%                ComVarStr.ifDer.ifDer=0; % to economize and avoid incorrect Der
                ComVarStr.Der1=[];
                parfor k=1:Mmp
                    [RMmp(k),yMmp(:,k),ierr0Mmp(k)]=runMoS(x,fMmp(:,k),ComVarStr,iter,R0,stepMmp(k),true,Inf(size(y0))); % computes the evaluation function at the point shifted by f from x0
                end
                k = find (ierr0Mmp>=0 & ~isinf(RMmp) & RMmp>=0 & ~isnan(RMmp), 1, 'first');
                if k>1
                    k=k-1;
                    if stepRight>stepMmp(k)
                        stepRight = stepMmp(k);
                        RRight = Inf;
                    end
                end
                k=find(RMmp==min(RMmp),1,'first');
                step=stepMmp(k);
                R=RMmp(k);
                if isinf(step) && R>RCmin
                    ktmp=k;
                    try
                        k=find(RMmp==min(RMmp(~isinf(stepMmp))),1,'first');
                    catch
                        k=[];
                    end
                    if isempty(k)
                        k=ktmp;
                        step=10^VPALim;
                    else
                        R=RMmp(k);
                        step=stepMmp(k);
                    end
                end
                y=yMmp(:,k);
                ierr0=ierr0Mmp(k);
                f=fMmp(:,k);
            end
    %        stepAD; % SCRIPT for the LSF step adaptation and local values correction; breaks a loop or corrects f when needed
     %++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    % LSF step adaptation
    %
    %%%%%%% exit if the minimum is found or the maximum of iterations is achieved
    %
            if ~isempty(R) && ~isnan(R) && R>=0
                if (R==0 || ((iter==1 && k==1 || iter>=StopIterLM || ~isempty(st)) && R<=RCmin && ierr0>=0)) % the Gauss prediction worked fine or the LM "optimal step" prediction worked fine!
                    break;
                elseif abs((R-R0)/R0)<10^(-VPALim/2) && (~isempty(R1) && R1>=0) && abs((R1-R0)/R0)<10^(-VPALim/2) % the step is so short that no significant variation of R is observed when decreasing the step
                    if RCmin<R0
                        iCm=-iCm; % there is a local minimum!
                    end
                    step=step*10;
                    break;
    %                continue;
                elseif isinf(step) && R<R0
                    if RCmin<R0
                        iCm=-iCm; % there is a local minimum!
                    else
                        ierr=0;
                    end
                    break;
                end
            end
            %
            if ~isempty(st) || iter>=StopIterLM % we have attempted to find the "optimal" step, check if it was good or not
    %            if (~isempty(R) && ~isnan(R) && R>=0 && (R<R0 || (R<RLeft && R<RRight)) || iter>=StopIterLM) && RCmin<R % return to the current minimum if only we have found the LM "optimal step" prediction is good, but is worse than the "current minimum", or at the last LM step
                if ~isempty(R) && ~isnan(R) && RCmin<R && RCmin<R0 % return to the current minimum if only we have found the LM "optimal step" prediction is good, but is worse than the "current minimum", or at the last LM step
                    iCm=-iCm;
                    break;
                elseif ~isempty(R) && ~isnan(R) && R>=0 && R<R0 % the local minimum is good enough
                    break;
                elseif iter>=StopIterLM % allowed maximum number of the LM steps is achieved without a solution - break with an error flag
                    if ifDisp
                        disp('LSF: no convergence');
                    end
                    break;
                else % otherwise continue...
                    st=[];
                end
            end
            %
            if step==0 || abs(stepRight-stepLeft)<10^(-VPALim/2)
                if RCmin<R0
                    iCm=-iCm; % there is a local minimum!
                end
                break;
            end
    %
    %%%%%%% correct LM parameters otherwise
    %
            ifDone=false; % flag to indicate if the half-step computation has been already done in a multiprocess case
            stepLeft0=stepLeft; % to check if stepLeft is corrected or not
            if isempty(R1) || R1<0
                if k>1 && ierr0Mmp(k-1)>=0
                    R1=RMmp(k-1);
                    step1=stepMmp(k-1);
                elseif k<Mmp && ierr0Mmp(k+1)>=0
                    R1=RMmp(k+1);
                    step1=stepMmp(k+1);
                end
            end
            %
            % adapt the step if needed - bad situations,
            %
            %
            if (ierr0<0 || isempty(R) || ~isreal(R) || isinf(R) || isnan(R) || R<0) % decrease step and repeat the computation if something is wrong
                if RCLM<R0 && step<stepCLM
                    iCm=-iCm;
                    break;
                end
                ierr0=-1;
                R1=-1; % to indicate that the step was reduced
                step1=step;
                if stepRight>step
                    stepRight = step; % maximum allowed step further
                    RRight=Inf;
                end
                if isinf(step)
                    step=LMstep0;
                else
                    step=step/10.5; % non-integer factor so that not to reproduce previous computations
                end
            %
                try
                    f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                catch
                    f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                end
                continue;
            end
            %
            if R/R0>10 % decrease step and repeat the computation if the result is highly unreliable
                ierr0=-1;
                R1=-1; % to indicate that the step was reduced
                step1=step;
                if stepRight>step
                    stepRight = step; % maximum allowed step further
                    RRight=R;
                end
                if isinf(step)
                    step=LMstep0;
                else
                    step=step/10.5; % non-integer factor so that not to reproduce previous comutations
                end
                try
                    f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                catch
                    f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                end
                continue;
            end
            %
            if R<RCLM && R>=0
                RCLM = R;
                stepCLM=step;
                if R<RCmin
                    if ifDisp
                        disp(strcat('LSF: current minimum is changed from R=',num2str(RCmin),' to R=',num2str(R),' (R-R0=',num2str(R-R0),')'));
                    end
                    RCmin = R;
                    fCmin = f;
                    yCmin = y;
                    stepCmin=step;
                    iCm=-2;
                end
                if k>1 && stepMmp(k-1)>stepCLM && stepRight>stepMmp(k-1)
                    stepRight=stepMmp(k-1);
                    RRight=RMmp(k-1);
                end
                if k<Mmp && stepLeft<stepMmp(k+1) && stepMmp(k+1)<=stepRight && RCLM<R0 && stepMmp(k+1)<stepCLM
                    stepLeft=stepMmp(k+1);
                    RLeft=RMmp(k+1);
                end
                if ~isempty(R1) && R1>0
                    if step1>step && step1>stepCLM && stepRight>step1
                        stepRight=step1;
                        RRight=R1;
                    elseif step1<step && stepLeft<step1 && step1<=stepRight && RCLM<R0 && step1<stepCLM
                        stepLeft=step1;
                        RLeft=R1;
                    end
                end
                if step<stepLeft
                    stepLeft=0;
                end
                if step>stepRight
                    stepRight=[];
                end
            else
                if step<stepCLM && step>stepLeft && step<=stepRight && RCLM<R0
                    stepLeft=step;
                    RLeft=R;
                elseif step<stepRight && step>stepCLM
                    stepRight=step;
                    RRight=R;
                end
            end
            %
            if isempty(R1) || R1<0 || isinf(step1) % assumably we do not have an additional point to make a parabola
                ierr0=-1;
                if R>=R0
                    if stepRight>step
                        stepRight = step; % maximum allowed step further
                        RRight=R;
                    end
                end
                step1=step;
                R1 = R;
                if ~isinf(step)
                    step=stepLeft + (step-stepLeft)/2;
                else
                    step=LMstep0;
                end
                if k<Mmp && (stepLeft==stepLeft0 || iter==1)
                    ifDone=true;
                    k=k+1;
                    R=RMmp(k);
                    y=yMmp(:,k);
                    f=fMmp(:,k);
                    step=stepMmp(k); % in a case previous step=Inf
                else
                    try
                        f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                    catch
                        f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                    end
                end
                continue;
            else % we can make a parabola (if we need it)
                sM=zeros(Mmp+5,1);
                RM=zeros(Mmp+5,1);
                RM(1)=R0;
                ks=2;
                if Mmp>1
                    sM(ks:ks+Mmp-1)=stepMmp;
                    RM(ks:ks+Mmp-1)=RMmp;
                    ks=ks+Mmp;
                else
                    sM(ks)=step;
                    RM(ks)=R;
                    ks=ks+1;
                end
                if ~isempty(R1) && isempty(find(sM==step1, 1))
                    sM(ks)=step1;
                    RM(ks)=R1;
                    ks=ks+1;
                end
                if ~isempty(RRight) && isempty(find(sM==stepRight, 1))
                    sM(ks)=stepRight;
                    RM(ks)=RRight;
                    ks=ks+1;
                end
                if isempty(find(sM==stepLeft, 1))
                    sM(ks)=stepLeft;
                    RM(ks)=RLeft;
                    ks=ks+1;
                end
                if isempty(find(sM==stepCLM, 1))
                    sM(ks)=stepCLM;
                    RM(ks)=RCLM;
                    ks=ks+1;
                end
                I=find(isinf(sM) | isnan(sM) | isinf(RM) | isnan(RM) | RM<0);
                if ~isempty(I)
                    sM(I)=[];
                    RM(I)=[];
                    ks=ks-length(I);
                end
                if ks>3
                    sM(ks:end)=[];
                    RM(ks:end)=[];
                    ks=ks-1;
                    [sM,I]=sort(sM);
                    RM=RM(I);
                    kk=find(RM==min(RM),1);
                    if kk>1 && kk<ks
                        sL=sM(kk-1);
                        RL=RM(kk-1);
                        sR=sM(kk+1);
                        RR=RM(kk+1);
                        sM=sM(kk);
                        RM=RM(kk);
                    elseif kk==1
                        sL=sM(1);
                        RL=RM(1);
                        sR=sM(3);
                        RR=RM(3);
                        sM=sM(2);
                        RM=RM(2);
                    else
                        sL=sM(ks-2);
                        RL=RM(ks-2);
                        sR=sM(ks);
                        RR=RM(ks);
                        sM=sM(ks-1);
                        RM=RM(ks-1);
                    end
                    [ifmin,st]=locParExtr(sL,sM,sR,RL,RM,RR);
                else
                    ifmin=0;
                    st=-1;
                end
                %
                sM=step; % just to keep
                if ifmin && st>0
                    if Mmp>1 && (stepCLM==0 || st<=stepCLM)
                        ks=Mmp-1;
                        st=st-stepLeft;
                        ks=find(stepLeft+st*2.^(1:ks)<stepRight,1,'last');
                        if ~isempty(ks)
                            step = stepLeft+st*2^ks;
                        else
                            step = stepLeft+st;
                        end
                    else
                        step = st;
                    end
                elseif R<R0 % we have probably underestimated the LM step
                    if ~isempty(R1) && R1>0 && ~isinf(step1) && step1>step
                        step=step1*3.5; % non-integer factor so that not to reproduce previous computations
                    else
                        step=step*3.5; % non-integer factor so that not to reproduce previous computations
                    end
                    st=[];
                else % we have probably overestimated the LM step
                    if ~isempty(R1) && abs((R1-R)/(R0-R))>=.01
                        step=stepLeft + (step-stepLeft)/2;
                        if k<Mmp && stepLeft==stepLeft0
                            ifDone=true;
                            k=k+1;
                            R=RMmp(k);
                            y=yMmp(:,k);
                            f=fMmp(:,k);
                        end
                    else % it looks we got stuck
                        if0=true;
                        if ~isinf(step) && ~isnan(step)
                            st=stepLeft + (step-stepLeft)/10.5; % non-integer factor so that not to reproduce previous comutations
                            if0=false;
                        elseif Mmp>1 && any(~isinf(stepMmp))
                            I = find(stepMmp==min(stepMmp) & stepMmp>stepLeft,1,'last');
                            if ~isempty(I)
                                st=stepLeft + (stepMmp(I)-stepLeft)/10.5;
                                if0=false;
                            end
                        end
                        if if0
    %                        st=stepLeft + (LMstep0-stepLeft)/10.5;
                            if isfield(ComVarStr,'LMinist') && ~isempty(ComVarStr.LMinist) && isreal(ComVarStr.LMinist) && ~isinf(ComVarStr.LMinist) && ~isnan(ComVarStr.LMinist) && ComVarStr.LMinist>0
                                st=stepLeft + (ComVarStr.LMinist-stepLeft)/10.5;
                            elseif isfield(ComVarStr,'VPALim') && ~isempty(ComVarStr.VPALim) && isreal(ComVarStr.VPALim) && ~isinf(ComVarStr.VPALim) && ~isnan(ComVarStr.VPALim)
                                st=stepLeft + (10^(ComVarStr.VPALim)/2-stepLeft)/10.5;
                            else
                                st=stepLeft + (1e8-stepLeft)/10.5;
                            end
                        end
                        if ~isnan(st) && ~isinf(st) && st>stepLeft && st<stepRight
                            if st<step
                                step=st;
                            else
                                while st>=step || step<=stepLeft || step<=stepRight
                                    step=rand*st;
                                end
                            end
                        else
                            st=1e16;
                            while st>=step || step<=stepLeft || step<=stepRight
                                st=rand*1e16;
                            end
                            step=st;
                        end
                    end
                    st=[];
                end
                R1=R;
                step1=sM;
                if step>=stepRight
                    rr = abs(stepRight-sM);
                    if rr<10^(-VPALim/2)
                        step=0;
                        R=R0;
                    else
                        step = stepRight - rr*0.5;
                    end
                    st=[];
                elseif step<=stepLeft
                    rr = abs(sM-stepLeft);
                    if rr<10^(-VPALim/2)
                        step=0;
                        R=R0;
                    else
                        step=stepLeft + rr*0.5;
                    end
                    st=[];
                end
                while step==stepRight || step==stepLeft
                    step = stepLeft + (stepRight-stepLeft)*rand;
                    st=[];
                end
                ierr0 = -1;
                if ~ifDone
                    try
                        f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                    catch
                        f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                    end
                end
                if R>=R0
                    if stepRight>sM
                        stepRight = sM; % maximum allowed step further
                        RRight=R;
                    end
                end
                continue;
            end
        catch
            break; % get out of the loop in a case of an unclear error
%             if isempty(stepRight) || stepRight>step
%                 stepRight=step;
%             end
%             step = step/5;
%             ifDone=false;
        end
% end of the LM step adaptation block
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    end
    if Mmp>=2
        clear yMmp fMmp RMmp ierr0Mmp stepMmp
%        if iCm<=0
            parfor j1=1:Mmp
                CVS(j1)=clearCVS; % clears ComVarStr on the current lab
            end
            ComVarStr=CVS(k);
            ComVarStr.ifDer.ifDer=ifDer;
            clear CVS
%         else
%             parfor j1=1:Mmp
%                 clearCVS; % clears ComVarStr on the current lab
%             end
%         end
    end
end
% if step~=LMstep0
if iCm>0 || (~isempty(fCmin) && any(fCmin) && (isempty(R) && RCmin<R0 || RCmin<R)) % return to the current minimum
    runMoS(x,fCmin,[],[],[],[],false); % to put the correct parameters into ComVarStr
    putresults(yCmin);
    R=RCmin;
    y=yCmin;
    if iCm==2
	    step=stepCmin;
    end
    if ifDisp
        disp(strcat('LSF: return to the minimum R=',num2str(RCmin),' (R-R0=',num2str(RCmin-R0),')'));
        if RCmin==R0
            disp('LSF: no convergence');
        end
    end
%    if R>=R0 && isfield(ComVarStr,'EpsIter') && ~isempty(ComVarStr.EpsIter) && isreal(ComVarStr.EpsIter) && ComVarStr.EpsIter>0
%        ierr=2;
%    elseif iCm==1
    if iCm==1
        ierr=4; % coordinate-wise step was performed
    else
        ierr=1; % the step was adapted
    end
    if ifDer
        ComVarStr.ifChange=true; % to recomute the design matrix
    end
elseif iter>1 || ~isinf(step) || ierr0<0
    if isempty(R) || isnan(R) || R<0 || R>R0 || ierr0<0 % (R>=R0 && isfield(ComVarStr,'EpsIter') && ~isempty(ComVarStr.EpsIter) && isreal(ComVarStr.EpsIter) && ComVarStr.EpsIter>=0)
%        if isempty(R) || isnan(R) || R>R0
            runMoS(x,[],[],[],[],[],false); % to put the correct parameters into ComVarStr
%            putpara(x); % restore the initial parameters
            putresults(y0); % restore the initial results
%        end
        R=R0;
        y=y0;
        if isfield(ComVarStr,'EpsIter') && ~isempty(ComVarStr.EpsIter) && isreal(ComVarStr.EpsIter) && ComVarStr.EpsIter>=0 % EpsIter<0 should not produce an error so that the computation to proceed
            ierr=2; % no decrease of the residual sum of squares is achieved
        else
            ierr=1;
        end
        if ifDer
            ComVarStr.ifChange=true; % to recomute the design matrix
        end
    else
%         R=R0;
%         y=y0;
        ierr=1; % the step was adapted
    end
end
if ~ifDf
    ComVarStr.sigma2=[];
    ComVarStr.Df=[];
    ComVarStr.kkk0=[];
    ComVarStr.lambda0=[];
else
    if ifAdopConstr
        ComVarStr.sigma2=R/(length(g)-(kkk0(1)+kkk0(4)));
    else
        ComVarStr.sigma2=R/(length(g)-kkk0(1));
    end
    ComVarStr.Df=Df;
    ComVarStr.kkk0=kkk0;
    ComVarStr.lambda0=lambda0;
end
%
catch
    R = [];
    y = [];
    ierr=-1000000; % something was wrong
end
if exist('step','var') && ~isinf(step)
    LMstep0=step*2;
else
    try
        if isfield(ComVarStr,'LMinist') && all(size(ComVarStr.LMinist)>=1) && isreal(ComVarStr.LMinist(1)) && ComVarStr.LMinist(1)>0
            step = ComVarStr.LMinist(1); % initial Levenberg-Marquardt step length measured in values of the maximum singular value - to be adapted later
        else
            step = 10^ceil(VPALim/2);
        end
    catch
        step = 10^ceil(VPALim/2);
    end
    if step>LMstep0
        LMstep0=step;
    else
        LMstep0=LMstep0*2;
    end
end
if LMstep0<=1e-8
    LMstep0=LMstep0*3;
end
return
