function [lambda0,lnR0,lnN,lambda,lcur] = lcurve(A,g,lamin,lamax,Nlam,ifplot,VPAlim)
% L-curve method for finding the optimal regularization parameter in Tikhonov regularization of a linear least-square problem
%
% USAGE
% [lambda0,lnR0,lnN,lambda,lcur] = lcurve(A,g,lamin,lamax,Nlam,ifplot)
%       in simplest cases
% lambda0 = lcurve(A,g,lamin,lamax,Nlam)
%       OR
% lcurve(A,g,lamin,lamax,Nlam,true)
%
% INPUT     (either 5 or 6)
% A       - matrix of the equation whose solution is to be regularized A*f=g
% g       - right-hand side of the equation whose solution is to be regularized A*f=g
% lamin   - lower bound of the lambda range to construct the L-curve
% lamax   - upper bound of the lambda range to construct the L-curve
% Nlam    - total nimber of equidistant point within the lambda range to construct the L-curve
% ifplot  - flag: if ifplot==true than a graphical representation of the
%           L-curve and the recommended regularization parameter is produced
%           during the computations
%
% OUTPUT    (any number between 0 and 5)
% lambda0 - recommended regularization parameter (or vector of parameters)
%           estimated as a point(s) where the third derivative of the
%           L-curve dependance have a negative slope and turns to zero
% lnR0    - vector of logarithms of a reidual sum or squares at every
%           lambda in the grid
% lnN     - vector of logarithms of a squared norm of a solution at every
%           lambda in the grid
% lambda  - vector of lambda values at a grid
% lcur    - depends on the version of the "maxcurve" subroutine - see
%           comments in the code; there is very rare need in this output,
%           so commonly it is just omitted
%
%
dlam=(lamax-lamin)/(Nlam-1);
lambda=lamin:dlam:lamax;
lnR0=zeros(Nlam,1);
lnN=zeros(Nlam,1);
if(nargin>=6 && ~isempty(ifplot) && ifplot)
    figure;
    title('L-CURVE');
    dg=subplot(1,1,1);
end
for i=1:Nlam
    if i==1
        if nargin>=7 && ~isempty(VPAlim) && isnumeric(VPAlim) && VPAlim~=16
            f = MNK(A,g,[],lambda(i),VPAlim); % R0 is the residual sum of squares divided by (n-m) in the LSF procedure; f is the LSF solution
        else
            f = MNK(A,g,[],lambda(i)); % R0 is the residual sum of squares divided by (n-m) in the LSF procedure; f is the LSF solution
        end
    else % so that not to recompute the SVD of A every time
        if nargin>=7 && ~isempty(VPAlim) && isnumeric(VPAlim) && VPAlim~=16
            f = MNK([],g,[],lambda(i),VPAlim); % R0 is the residual sum of squares divided by (n-m) in the LSF procedure; f is the LSF solution
        else
            f = MNK([],g,[],lambda(i)); % R0 is the residual sum of squares divided by (n-m) in the LSF procedure; f is the LSF solution
        end
    end
    R0 = sum((A*f-g).^2); % residual sum of squares
    lnR0(i)=log(R0);
    lnN(i)=log(f'*f);
    if(nargin>=6 && ifplot)
        plot(dg,lnR0(1:i),lnN(1:i),'.k');
        title(['L-CURVE: ' 'current lambda = ' num2str(lambda(i))]);
        xlabel('ln(R)');
        ylabel('ln(|f|)');
        drawnow;
    end
end
%
if (Nlam>2)
    [lambda0, lcur] = maxcurve0(lnR0,lnN,lambda); % in a version of "maxcurve0" lcur is a square of the local radius of the curvature of lnN dependance on lnR0 at points lambda(2:length(lambda)-1))
%   [lambda0, lcur] = maxcurve(lnR0,lnN,lambda);  % in a version of "maxcurve"  lcur is a local curvature of lnN dependance on lnR0, i.e., the inverse local radius at points lambda(2:length(lambda)-1))
else
    lambda0=-mean(lambda);
end
if(nargin>=6 && ifplot)
    for i=1:length(lambda0)
        if nargin>=7 && ~isempty(VPAlim) && isnumeric(VPAlim) && VPAlim~=16
            f = MNK([],g,[],lambda0(i),VPAlim);
        else
            f = MNK([],g,[],lambda0(i));
        end
        R0 = sum((A*f-g).^2); % residual sum of squares
        hold on;
        plot(log(R0),log(f'*f),'ro');
        hold off;
    end
    title (['L-CURVE: ' 'recommended regularization parameter lambda = ' num2str(lambda0')])
    ar=get(dg,'DataAspectRatio');
    ar=ar/ar(1);
    if ar(2)>3
        ar(2)=ar(2)/3;
    elseif ar(2)<1/3;
        ar(2)=ar(2)*3;
    else
        ar(2)=1;
    end
    set(dg,'DataAspectRatio',ar);
%    set(dg,'DataAspectRatio',[1 1 1]);
end
return