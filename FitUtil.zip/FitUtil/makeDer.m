function IERR = makeDer(n)
% Creates the total design matrix from the local ones produced by the  currently executed block of the model
%
% USAGE: IERR = makeDer(n)
%
% Addresses the global structure ComVarStr
%    INPUT
% n    - the ordinal number of the current block
% global ComVarStr.locDer      - the derivatives matrix produced by the n-th block
% global ComVarStr.locDerNames - the cell array with the names of the n-th block
%                                parameters (including the matrix ones),
%                                over which the derivatives have been computed,
%                                in the order of ComVarStr.locDer columns
%    OUTPUT
% IERR - error flag:
%        = 0 - everything is OK
%        = 1 - erroneous or empty fields ComVarStr.locDer and ComVarStr.locDerNames
%        =-1 - an unclassified error has occured
%        =-2 - locDer is inconsistent with the "input" array
%        =-3 - locDer is inconsistent with the computed results
% global ComVarStr.Der1 - the design matrix of the model expanded with the
%                         local one
%

global ComVarStr
IERR=0;
if ~isfield(ComVarStr,'ifDer') || ~isfield(ComVarStr.ifDer,'ifDer') || isempty(ComVarStr.ifDer.ifDer) || ~isnumeric(ComVarStr.ifDer.ifDer) && ~islogical(ComVarStr.ifDer.ifDer) || ~ComVarStr.ifDer.ifDer(1) || ComVarStr.ifDer.ifDer(1)<-100000
    return
else
    ifDer=ComVarStr.ifDer.ifDer(1);
end
if ~isfield(ComVarStr,'locDer') || ~isfield(ComVarStr,'locDerNames') || isempty(ComVarStr.locDer) || isempty(ComVarStr.locDerNames) || ~isnumeric(ComVarStr.locDer) || ~iscell(ComVarStr.locDerNames)
    ComVarStr.locDer=[];
    ComVarStr.locDerNames=[];
    IERR=1;
    return
end
try
    LP0=length(ComVarStr.Proc); % total number of blocks of the current model
    NBl=0; % total length of the results fields
    for k=1:LP0
        NBl=NBl+NResField(k);
    end
    fn = getProNm(n);
    IERR=0;
    if ~isfield(ComVarStr,'Der1') && ~isreal(ComVarStr.Der1)
        if ~isfield(ComVarStr,'ifSparse') || ~ComVarStr.ifSparse
            ComVarStr.Der1=[];
        else
            ComVarStr.Der1=sparse(0,0);
        end
    end
     if ~isfield(ComVarStr,'input') || size(ComVarStr.locDer,1)>length(ComVarStr.input)
         ComVarStr.locDer=[];
         ComVarStr.locDerNames=[];
         IERR=-2;
         return
     end
    lpar = length(ComVarStr.locDerNames);
    if lpar>0
        if isfield(ComVarStr,'Der1') && ~isempty(ComVarStr.Der1)
            ND1=size(ComVarStr.Der1,1);
        else
            ND1=0;
        end
        N = zeros(lpar,1); % to be an array containing numbers of the scalar parameters in the current matrix
        for k=lpar:-1:1 %  loop over the local names of the current block
            if isempty(ComVarStr.locDerNames{k}) || ~ischar(ComVarStr.locDerNames{k})
                ComVarStr.locDerNames(k)=[];
            else
                try
                    N(k) = numel(ComVarStr.(fn).(ComVarStr.locDerNames{k})); % the number of the scalar parameters in the current one
                catch
%                    ComVarStr.locDerNames(k)=[];
                end
            end
        end
        lpar = length(ComVarStr.locDerNames);
        try
            NR=NResField(n); % the length of the results field of the current block
            if NR==0 % attempt to find the results field in the later block via the GET FROM mechanism
                for k=n+1:length(ComVarStr.Proc)
                    fnn=getProNm(k);
                    if strcmp(fnn,fn)
                        break;
                    end
                    NRR=NResField(k); % the length of the results field of the current block
                    if NRR == size(ComVarStr.locDer,1)
                        for l=1:length(ComVarStr.Proc(k).Par)
                            fnn=ShrtName(ComVarStr.Proc(k).Par(l).From);
                            if strcmp(fnn,fn)
                                NR=NRR;
                                break;
                            end
                        end
                    end
                end
            end
        catch
            NR=0;
        end
        if NR~=0 && NR~=size(ComVarStr.locDer,1)
            ComVarStr.ifDer.ifDer=0;
            ComVarStr.locDer=[];
            ComVarStr.locDerNames=[];
            ComVarStr.Der1=[];
            IERR=-3;
            if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                beep;
                disp('makeDer WARNING: an attempt to construct the design matrix inconsistent with the block results');
                disp('switch to the finite-difference scheme');
                beep;
            end
            return
        end
        kpar=zeros(lpar,1);
        try
            LP = length(ComVarStr.ParField{n}); % number of the fitted parameters of the modeling block
        catch
            LP=0;
        end
        [y,M0]=getpara(n,0,0,1);
        [y,M1]=getpara(n,LP,0,1);
        if M1>M0
            for k=1:lpar % loop over local names of the current block
                for l=1:LP % loop over matrix parameters of the current block
                    if strcmp(ComVarStr.ParField{n}(l),ComVarStr.locDerNames{k}) % check if it is actually the parameter with the required name
                        if k>1
                            N0 = sum(N(1:k-1));
                        else
                            N0=0;
                        end
                        [y,M0,M00]=getpara(n,l-1,0,1);
                        [y,M1]=getpara(n,l,0,1);
                        if M1>M0
                            kpar(k)=1;
                            if ND1==0 || (size(ComVarStr.Der1,2)<M1 && NR==0)
                                for m=1:N(k)
                                    M00 = M00+1;
                                    if ComVarStr.ParStep(M00)~=0
                                        M0=M0+1;
                                        ComVarStr.Der1(:,M0) = ComVarStr.locDer(:,N0+m);
                                    end
                                end
                            elseif NR~=0 && NR~=NBl
                                for m=1:N(k)
                                    M00 = M00+1;
                                    if ComVarStr.ParStep(M00)~=0
                                        M0=M0+1;
                                        ComVarStr.Der1(ND1+1:ND1+NR,M0) = ComVarStr.locDer(:,N0+m);
                                    end
                                end
                            else
                                for m=1:N(k)
                                    M00 = M00+1;
                                    if ComVarStr.ParStep(M00)~=0
                                        M0=M0+1;
                                        if M0<=size(ComVarStr.Der1,2)
                                            ComVarStr.Der1(:,M0) = ComVarStr.Der1(:,M0)+ComVarStr.locDer(:,N0+m);
                                        else
                                            ComVarStr.Der1(:,M0) = ComVarStr.locDer(:,N0+m);
                                        end
                                    end
                                end
                            end
                        end
                        break;
                    end
                end
            end
        end
        k0=find(kpar==0);
        if ~isempty(k0)
%            LP0=length(ComVarStr.Proc);
            LP=length(ComVarStr.Proc(n).Par);
            for k=1:length(k0)
                for l=1:LP
                    if iscell(ComVarStr.Proc(n).Par(l).Name)
                        fpn=ComVarStr.Proc(n).Par(l).Name{1};
                    else
                        fpn=ComVarStr.Proc(n).Par(l).Name;
                    end
                    if strcmp(fpn,ComVarStr.locDerNames{k0(k)}) % check if it is actually the parameter with the required name
                        [fn,pn]=ShrtName(ComVarStr.Proc(n).Par(l).From);
                        if ~isempty(pn)
                            for kf=1:LP0
                                if strcmp(getProNm(kf),fn)
                                    LP1=length(ComVarStr.ParField{kf});
                                    [y,M0]=getpara(kf,0,0,1);
                                    [y,M1]=getpara(kf,LP1,0,1);
                                    if M1>M0
                                        for k1=1:LP1
                                            try
                                                fpn=ComVarStr.ParField{kf}{k1};
                                            catch
                                                fpn=ComVarStr.ParField{kf};
                                            end
                                            if strcmp(fpn,pn)
                                                [y,M0,M00]=getpara(kf,k1-1,0,1);
                                                [y,M1]=getpara(kf,k1,0,1);
                                                if M1>M0
                                                    if k0(k)>1
                                                        N0 = sum(N(1:k0(k)-1));
                                                    else
                                                        N0=0;
                                                    end
%                                                        kpar(k)=1;
                                                    if ND1==0 || (size(ComVarStr.Der1,2)<M1 && NR==0)
                                                        for m=1:N(k0(k))
                                                            M00 = M00+1;
                                                            if ComVarStr.ParStep(M00)~=0
                                                                M0=M0+1;
                                                                ComVarStr.Der1(:,M0) = ComVarStr.locDer(:,N0+m);
                                                            end
                                                        end
                                                    elseif NR~=0 && NR~=NBl
                                                        for m=1:N(k0(k))
                                                            M00 = M00+1;
                                                            if ComVarStr.ParStep(M00)~=0
                                                                M0=M0+1;
                                                                ComVarStr.Der1(ND1+1:ND1+NR,M0) = ComVarStr.locDer(:,N0+m);
                                                            end
                                                        end
                                                    else
                                                        for m=1:N(k0(k))
                                                            M00 = M00+1;
                                                            if ComVarStr.ParStep(M00)~=0
                                                                M0=M0+1;
                                                                ComVarStr.Der1(:,M0) = ComVarStr.Der1(:,M0)+ComVarStr.locDer(:,N0+m);
                                                            end
                                                        end
                                                    end
                                                end
                                                break;
                                            end
                                        end
                                    end
                                    break;
                                end
                            end
                        end
                        break;
                    end
                end
            end
        end
    end
catch mectc
    IERR=-1; % unclassified error
    ComVarStr.ifDer.ifDer=0;
    ComVarStr.locDer=[];
    ComVarStr.locDerNames=[];
    ComVarStr.Der1=[];
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('makeDer WARNING: unable to construct the design matrix due to an unclassified error');
        disp('switch to the finite-difference scheme');
        beep;
    end
end
[y,M0]=getpara([],[],0,1);
if isfield(ComVarStr,'Der1') && ~isempty(ComVarStr.Der1) && (size(ComVarStr.Der1,1)>length(ComVarStr.input) || n==length(ComVarStr.Proc) && (size(ComVarStr.Der1,1)<length(ComVarStr.input) || size(ComVarStr.Der1,2)<M0))
    ComVarStr.ifDer.ifDer=0;
    ComVarStr.locDer=[];
    ComVarStr.locDerNames=[];
    ComVarStr.Der1=[];
    IERR=-2;
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('makeDer WARNING: an attempt to construct the design matrix inconsistent with the ''input'' array');
        disp('switch to the finite-difference scheme');
        beep;
    end
end
if isfield(ComVarStr,'ifSparse') && ~isempty(ComVarStr.ifSparse) && ComVarStr.ifSparse(1) && isfield(ComVarStr,'Der1') && ~isempty(ComVarStr.Der1)
    if ~issparse(ComVarStr.Der1)
        ComVarStr.Der1=sparse(ComVarStr.Der1);
    elseif nnz(ComVarStr.Der1)~=nzmax(ComVarStr.Der1)
        ComVarStr.Der1=ComVarStr.Der1*1; % reduces allocation spase
    end
end
if ifDer>=-10000
    ComVarStr.locDer=[];
    ComVarStr.locDerNames=[];
end
%
return