function [f,sigma2,Df,Dfi,k0,S,V,U,lambda0] = MNKlin (A,g,D,k,lambda,ifplot,VPAlim)
% Least-square fit and (optionally) Tikhonov regularization of a linear equation
%
% USAGE
% [f,sigma2,Df,k0,S,V,U] = MNKlin (A,g,D,k,lambda,ifplot)
%       in a simplest case:
% f = MNKlin(A,g)
%       or any other combination of more input and output parameters
%
% PURPOSE
% Least-square fit and (optionally) Tikhonov regularization of a linear equation Af=g
%
% INPUT     (any number of input variables between 2 and 6)
% A       - matrix of the equation to be solved
% g       - right-hand vector of the equation to be solved
% D       - if vector - absolute errors of g values considered to be statistically independent
%           if matrix - covariance matrix of g values
%           if do not exist at the input or have wrong dimensions -
%           considered as a case of a vector with unit elements
% k       - if exists and is scalar value >0, a parameter of a "rough" regularization, namely
%                             if 1<=k<m - number of first singular 1-D
%                                         subspaces to contribute into the
%                                         solution vector (higher subspaces
%                                         to be ignored);
%                             if 0<=k<1 - level of reliability, so that the
%                                         number of first singular 1-D
%                                         subspaces contributing into the
%                                         solution vector is found as a
%                                         lower boundary at which the relation
%                                         of the current singular value to
%                                         the first one becomes less or equal than k
%           if exists and is a matrix than it is treated as a matrix of linear
%           constraints k*f=lambda playing the role of the null hypothesis
%           to be checked according the Fisher criterium.
%           NOTE: the matrix k should not be singular. Some singularities
%           (presence of zero rows or of equal rows) are checked and
%           corrected, and, if the rank of the corrected k matrix becomes zero,
%           it is treated as if k=size(A,1), lambda=0 at the input;
%           if some inconsistences in the matrix k and vector lambda are
%           found, then it is treated as if k=size(A,1), lambda=0 at the
%           input and the output k0(2)=0.
% lambda  - (1) if exists and ~=0 when k is a scalar value and ifplot does not exist:
%               parameter of the Tikhonov regularization
%               (implied to be chosen so that to minimize the solution norm
%               without effecting the residual sum of squares significantly);
%           (2) if exists when k is a matrix and ifplot does not exist:
%               lambda plays a role of the right-hand vector
%               of linear constraints to be checked (see the k description above);
%           (3) if exists when ifplot exists and length(lambda)==3, its
%               elements are treated as lower boundary, upper boundary and
%               number of point of a grid at which the L-curve method is
%               applied to find the optimal regularization parameter
%           (4) if does not exist than is treated as lambda=0 for any regime;
% ifplot  - logical variable; if exists and length(lambda)=3 it means that
%           the L-curve method is to be applied to find the optimal
%           regularization parameter; in a case ifplot=true the grpahic
%           representation of the L-curve method is produced, otherwise is
%           not.
% VPAlim  - if exists and not equal 16, than a regime of computations with
%           a high precision is used. This case VPAlim significant digits
%           are traced.
%           REMARKS: (1) this regime slows down the computations.
%                    (2) this value only effects intermediate computations;
%                        all the results are returned as usual double
%                        precision MATLAB variables
% if this routine is used for preparing the robust estimate, th need to do
% it should be indicated by a global logical variable ComVarStr.ifRob;
% if this variable does not exist in the workspace, it is implied to be =
% false
%
% OUTPUT    (any number of output variables between 1 and 8 is allowed)
% f       - the least-square solution of the equation;
%           the length of f is determined by the second dimension of the
%           matrix A or (in a case when input k is a matrix) by the minimum
%           of the second dimensions of A and k if they differ;
%           in a case of an error f=[];
% sigma2  - estimate of the variance (sigma^2) of the right-hand values g
%           so, the estimate of the f covariance matrix can be
%           computed as sigma2*Df; standard deviations of the solution can
%           be computed as sqrt(sigma2*diag(Df)); the residual sum of squares
%           R0 = sigma2*(n-k0(1)) (see k0 below);
% Df      - covariance matrix of the solution f implying that the g values
%           standard deviation is indeed 1; otherwise the actual covariance
%           matrix can be computed by multiplying this one by the actual
%           standard deviation of g;
% k0      - vector:
%           k0(1) is always actual number of 1-D singular subspaces contributed into the solution
%                 (higher subspaces were ignored due to an input truncation condition
%                  or due to zero singular values);
%           k0(2) is recommended number of 1-D singular subspaces to be used 
%                 for the reason the unstability crashes numerical
%                 precision
%           k0(3) is only outputted if input k is a matrix; this case
%                 it contains the p-level of the null hypothesis checked based on
%                 the Fisher criterium
% S, V, U - elements of the singular value decomposition
%               A(1:n,1:m) = U(1:n,1:m) * [diag(S(1:m))] * V'(1:m,1:m)
%            so, S is a vector containing singular values
% lambda0 - actual value of regularization parameter lambda if it was found
%           via the L-curve method; otherwise it remains undefined
% Dfi     - diagonal part of the inverse of Df intended to compute the conditional standard deviations
%
% NOTICE: in a regime with the Fisher test (when input k is a matrix),
%         the LSF solution without constrains is only computed.
%

global ComVarStr
Dfi=[];
if nargin>2 && size(D,1)==size(g,1) && (size(D,2)==size(g,1) || size(D,2)==size(g,2))
    [A,g,ier] = preMNK(A,g,D);
    if (ier~=0)
        f=[];
        return;
    end
elseif (nargin<2)
    return;
else % in a case the robust estimate is needed
    if isfield(ComVarStr,'ifRob') && ComVarStr.ifRob
        D = ones(size(g));
        [A,g,ier] = preMNK(A,g,D);
    end
end
%
if nargin>5 && length(lambda)==3 && any(size(k) <= 1)
    lamin = lambda(1);
    lamax = lambda(2);
    Nlam  = round(lambda(3));
    if nargin>=7 && ~isempty(VPAlim) && all(isnumeric(VPAlim))
        lambda0 = lcurve(A,g,lamin,lamax,Nlam,ifplot,VPAlim);
    else
        lambda0 = lcurve(A,g,lamin,lamax,Nlam,ifplot);
    end
    lambda = lambda0;
elseif(nargout>=9)
    if nargin>=5 && length(lambda)==1 && any(size(k) <= 1)
        lambda0=lambda;
    else
        lambda0=0;
    end
end
%
switch nargin
    case 2
        nargin0=2; % number of input arguments for the MNK routine
    case 3
        nargin0=2; % number of input arguments for the MNK routine
    case 4
        nargin0=3; % number of input arguments for the MNK routine
    case 5
        nargin0=4; % number of input arguments for the MNK routine
    case 6
        nargin0=4;
    otherwise
        nargin0=5; % number of input arguments for the MNK routine
end
if nargin0 == 5 && (isempty(VPAlim) || abs(round(VPAlim))==16)
    nargin0=4;
end
if nargin0 == 4 && (isempty(lambda) || any(any(~isnumeric(lambda))) || (all(size(k)==1) && all(size(lambda)==1) && lambda==0))
    nargin0 = 3;
end
if nargin0 == 3 && (isempty(k) || any(any(~isnumeric(k))) || k==0)
    nargin0 = 2;
end
%
if ~isfield(ComVarStr,'ifGrad') || isempty(ComVarStr.ifGrad) || ~ComVarStr.ifGrad(1)
    switch nargout
        case 1
            switch nargin0
                case 2
                    f = MNK (A,g);
                case 3
                    f = MNK (A,g,k);
                case 4
                    f = MNK (A,g,k,lambda);
                otherwise
                    f = MNK (A,g,k,lambda,VPAlim);
            end
        case 2
            switch nargin0
                case 2
                    [f,sigma2] = MNK (A,g);
                case 3
                    [f,sigma2] = MNK (A,g,k);
                case 4
                    [f,sigma2] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2] = MNK (A,g,k,lambda,VPAlim);
            end
        case 3
            switch nargin0
                case 2
                    [f,sigma2,Df] = MNK (A,g);
                case 3
                    [f,sigma2,Df] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df] = MNK (A,g,k,lambda,VPAlim);
            end
        case 4
            switch nargin0
                case 2
                    [f,sigma2,Df,Dfi] = MNK (A,g);
                case 3
                    [f,sigma2,Df,Dfi] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df,Dfi] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,Dfi] = MNK (A,g,k,lambda,VPAlim);
            end
        case 5
            switch nargin0
                case 2
                    [f,sigma2,Df,Dfi,k0] = MNK (A,g);
                case 3
                    [f,sigma2,Df,Dfi,k0] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df,Dfi,k0] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,Dfi,k0] = MNK (A,g,k,lambda,VPAlim);
            end
        case 6
            switch nargin0
                case 2
                    [f,sigma2,Df,Dfi,k0,S] = MNK (A,g);
                case 3
                    [f,sigma2,Df,Dfi,k0,S] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df,Dfi,k0,S] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,Dfi,k0,S] = MNK (A,g,k,lambda,VPAlim);
            end
        case 7
            switch nargin0
                case 2
                    [f,sigma2,Df,Dfi,k0,S,V] = MNK (A,g);
                case 3
                    [f,sigma2,Df,Dfi,k0,S,V] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df,Dfi,k0,S,V] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,Dfi,k0,S,V] = MNK (A,g,k,lambda,VPAlim);
            end
        otherwise
            switch nargin0
                case 2
                    [f,sigma2,Df,Dfi,k0,S,V,U] = MNK (A,g);
                case 3
                    [f,sigma2,Df,Dfi,k0,S,V,U] = MNK (A,g,k);
                case 4
                    [f,sigma2,Df,Dfi,k0,S,V,U] = MNK (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,Dfi,k0,S,V,U] = MNK (A,g,k,lambda,VPAlim);
            end
    end
else
    if ~isempty(A) && (~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1))
        disp('MNKlin WARNING: the gradient descent algorithm is run');
        beep;
    end
    switch nargout
        case 1
            switch nargin0
                case 2
                    f = GraDes (A,g);
                case 3
                    f = GraDes (A,g,k);
                case 4
                    f = GraDes (A,g,k,lambda);
                otherwise
                    f = GraDes (A,g,k,lambda,VPAlim);
            end
        case 2
            switch nargin0
                case 2
                    [f,sigma2] = GraDes (A,g);
                case 3
                    [f,sigma2] = GraDes (A,g,k);
                case 4
                    [f,sigma2] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2] = GraDes (A,g,k,lambda,VPAlim);
            end
        case 3
            switch nargin0
                case 2
                    [f,sigma2,Df] = GraDes (A,g);
                case 3
                    [f,sigma2,Df] = GraDes (A,g,k);
                case 4
                    [f,sigma2,Df] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df] = GraDes (A,g,k,lambda,VPAlim);
            end
        case 4
            switch nargin0
                case 2
                    [f,sigma2,Df,k0] = GraDes (A,g);
                case 3
                    [f,sigma2,Df,k0] = GraDes (A,g,k);
                case 4
                    [f,sigma2,Df,k0] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,k0] = GraDes (A,g,k,lambda,VPAlim);
            end
        case 5
            switch nargin0
                case 2
                    [f,sigma2,Df,k0,S] = GraDes (A,g);
                case 3
                    [f,sigma2,Df,k0,S] = GraDes (A,g,k);
                case 4
                    [f,sigma2,Df,k0,S] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,k0,S] = GraDes (A,g,k,lambda,VPAlim);
            end
        case 6
            switch nargin0
                case 2
                    [f,sigma2,Df,k0,S,V] = GraDes (A,g);
                case 3
                    [f,sigma2,Df,k0,S,V] = GraDes (A,g,k);
                case 4
                    [f,sigma2,Df,k0,S,V] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,k0,S,V] = GraDes (A,g,k,lambda,VPAlim);
            end
        otherwise
            switch nargin0
                case 2
                    [f,sigma2,Df,k0,S,V,U] = GraDes (A,g);
                case 3
                    [f,sigma2,Df,k0,S,V,U] = GraDes (A,g,k);
                case 4
                    [f,sigma2,Df,k0,S,V,U] = GraDes (A,g,k,lambda);
                otherwise
                    [f,sigma2,Df,k0,S,V,U] = GraDes (A,g,k,lambda,VPAlim);
            end
    end
end
return;
end
