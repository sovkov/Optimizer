function [lambda0,R2]=maxcurve(lnR0,lnN,lambda)
% finds coordinate lambda0 of the minimum squared radius of curvature R2 of a curve
%
% USAGE
% [lambda0,R2]=maxcurve(lnR0,lnN,lambda)
%   or
% lambda0=maxcurve(lnR0,lnN,lambda)
%
% PURPOSE
% finds coordinate lambda0 of the minimum squared radius of curvature R2
% of a curve lnN depending on lnR0 if both values lnN and lnR0 are known
% as functions of an (arbitrary vector of) parameter lambda
%
    Nlam    = max(size(lambda));
    dlam    = (lambda(Nlam)-lambda(1))/(Nlam-1);
%
    x2 = -diff(lnR0);
    y2 = -diff(lnN);
    x3 = -x2(2:Nlam-1);
    y3 = -y2(2:Nlam-1);
    x2(Nlam-1)=[];
    y2(Nlam-1)=[];
    R2 = (-2.*y3.^2.*x2.^3.*x3-2.*y3.*y2.^3.*x3.^2+x3.^4.*y2.^2+2.*y3.^2.*y2.^2.*x2.^2+y3.^4.*x2.^2-2.*y3.*x2.^2.*x3.^2.*y2+x3.^2.*x2.^4-2.*x3.^3.*x2.^3+y2.^4.*x3.^2-2.*y3.^3.*x2.^2.*y2-2.*y3.^2.*x2.*y2.^2.*x3-2.*y3.^3.*y2.^3+y3.^2.*x2.^4+y3.^4.*y2.^2-2.*y2.^2.*x3.^3.*x2+x3.^4.*x2.^2+2.*x3.^2.*x2.^2.*y2.^2+2.*y3.^2.*x2.^2.*x3.^2+y3.^2.*y2.^4+2.*x3.^2.*y2.^2.*y3.^2)./(-x3.*y2+x2.*y3).^2/4;
%   R2 is a square of the local radius of curvature
%
    i0    = find(R2==min(R2));
    i00   = length(i0);
    lambda0 = zeros(i00,1);
    for i = 1:i00
        if (i0(i) == 1)
            lambda0(i) = lambda(1);
        elseif (i0(i) == Nlam-2)
            lambda0(i) = lambda(Nlam);
        else
            f0   = R2(i0(i));
            fmin = R2(i0(i)-1);
            fmax = R2(i0(i)+1);
            lambda0(i) = lambda(i0(i)+1) + (fmax-fmin)/((f0-fmax)+(f0-fmin)).*dlam/2;
        end
    end
    return