function varargout = Optimizer(varargin)
% The main tool for the model optimization;
% for a help info launch the command FitHelp.

global O_figFit  % main figure handle
global ComVarStr

if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp)
    ComVarStr.ifDisp=true; % can be turned off in the command window
elseif ~isscalar(ComVarStr.ifDisp)
    ComVarStr.ifDisp=ComVarStr.ifDisp(1);
end

if (nargin==0)
    if ~isempty(O_figFit)
        figure (O_figFit);
        return
    end
    %
    C=what;
    C=C.path;
    ComVarStr.IniPath = C;
    clear C;
    %
    OptimStart;
	set(O_figFit,'Color',get(0,'defaultUicontrolBackgroundColor'));
    set ( findobj('Tag','RBno','Parent',O_figFit),'Value',get(findobj('Tag','RBno','Parent',O_figFit),'Max') );
    refrOptimizer;
    %elseif ischar(varargin(1))
else
    try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
    catch mectc
        beep;
		disp(lasterr);
        disp('Optimizer ERROR!!!');
        disp(strcat(mectc.message,' Line_',num2str(mectc.stack(1).line)));
        beep;
        EnaButtons;
        refrOptimizer;
    end
end
return

function varargout = GenFit_CloseRequestFcn(h,varargin)
 clearglFit;
 delete (gcbf);
return

function varargout = GenFit_DeleteFcn(h,varargin)
 clearglFit;
return

function varargout = pbExFit_Callback(h, varargin)
  button = questdlg('Do not forget to CLEAR ALL the MatLab workspace if there is no further need in global variables.         Are you sure to exit?','Exit Confirm','Yes','No','Yes');
  if (isequal(button,'Yes'))
   delete (gcbf); % this will run RKR_DeleteFcn
  end
return

function varargout = pbViewSim_Callback(h, varargin)
    Viewer;
return

function varargout = pbModSim_Callback(h, varargin)
    Modeler;
return

function varargout = pbHelp_Callback(h, varargin)
 FitHelp;
return

function varargout = pbComp_Callback(h, varargin)
global O_figFit  % main figure handle
global ComVarStr;
ifDisp=~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1);
if ifDisp
                    disp('=======================================================================');
    disp ('          OPTIMIZATION START');
end
s = warning;
s0 = 'on';
for i=1:length(s)
    if strcmp(s(i).identifier,'all')
        s0 = s(i).state;
        break;
    end
end
clear s;
warning off;
%
try
    if ~isempty(O_figFit)
        uic = findobj('Tag','pbComp','Parent',O_figFit);
        uic1 = findobj('Tag','pbFminunc','Parent',O_figFit);
        uic2 = findobj('Tag','pbFminsearch','Parent',O_figFit);
        set(uic,'String','WAIT','Enable','off');
        set(uic1,'String','WAIT','Enable','off');
        set(uic2,'String','WAIT','Enable','off');
        try
            drawnow; % to refresh controls
        catch
            pause(0.01); % to refresh controls
        end
    end
catch
end
if isfield(ComVarStr,'input') && ~isempty(ComVarStr.input) && all(isnumeric(ComVarStr.input))
    if isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar) && all(all(isnumeric(ComVarStr.inpCovar))) && ( all(size(ComVarStr.inpCovar) == length(ComVarStr.input)) || (any(size(ComVarStr.inpCovar) == length(ComVarStr.input)) && any(size(ComVarStr.inpCovar) == 1)) ) && ~all(all(ComVarStr.inpCovar==0))
        Cov = ComVarStr.inpCovar; % get the input data covariance matrix
    else
        Cov = ones(length(ComVarStr.input),1); % default covariance matrix
    end
    if isfield(ComVarStr,'ifChange') && ~isempty(ComVarStr.ifChange) && ComVarStr.ifChange(1)
        y0=[];
    else
        y0 = getresults;
    end
    if length(y0)~=length(ComVarStr.input);
        ierr = funval;
        try
            if ~isempty(O_figFit)
                if ierr==0
                     set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No problem has been detected','ForegroundColor','black');
                else
                    if ierr~=-1000000
                     ierr = abs(ierr);
                     set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat('Procedure No.',num2str(ierr),' was not found'),'ForegroundColor','red');
                     EnaButtons;
                     beep;
                    else
                     set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Critical error','ForegroundColor','red');
                     EnaButtons;
                     beep;
                    end
                    set(uic,'String','Iterations','Enable','on');
                    if strcmp(s0,'on')
                        warning on;
                    end
                    set(uic,'String','Iterations','Enable','on');
                    set(uic1,'String','fminunc','Enable','on');
                    set(uic2,'String','fminsearch','Enable','on');
                    set (findobj('Tag','edMaxIt','Parent',O_figFit),'String',num2str(ComVarStr.StopIter));
                    return
                end
            end
        catch
        end
        y0 = getresults;
    end
    if length(y0)==length(ComVarStr.input)
        if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isnumeric(ComVarStr.inpCov))) && ( all(size(ComVarStr.inpCov) == length(ComVarStr.input)) || (any(size(ComVarStr.inpCov) == length(ComVarStr.input)) && any(size(ComVarStr.inpCov) == 1)) ) && ~all(all(ComVarStr.inpCov==0))
            Cov = ComVarStr.inpCov; % get the input data corrected covariance matrix if available
        end
        try
            R0 = resi(y0,ComVarStr.input,Cov);
        catch
            R0=[];
        end
        %
        if ~isempty(O_figFit)
            refrOptimRes;
        end
        if isempty(R0) || ~isreal(R0) || isinf(R0) || isnan(R0) || R0<0
            beep;
            try
                if ~isempty(O_figFit)
                    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','The model is incorrect','ForegroundColor','red');
                    set(uic,'String','Iterations','Enable','on');
                    if strcmp(s0,'on')
                        warning on;
                    end
                end
            catch
            end
            return
%         else
%             try
%                 if ~isempty(O_figFit)
%                     set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No problem has been detected','ForegroundColor','black');
%                 end
%             catch
%             end
        end
        %
        % save ComVarStr to the TMP.MOT file if needed
        if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM(1)
            try
%                try
%                    save('TMP.MOT','-mat','-v7.3','ComVarStr');
%                catch
                    save('TMP.MOT','-mat','ComVarStr');
%                end
%                 try
%                   save -MAT TMP.MOT ComVarStr;
%                 catch
%                   save TMP.MOT ComVarStr; % for Octave
%                 end
                if ifDisp
                    disp('=======================================================================');
                    disp('Initial state is saved as ''TMP.MOT''');
                end
            catch
                if ifDisp
                    disp('=======================================================================');
                    beep;
                    disp('Unable to save the initial state as ''TMP.MOT''');
                end
                ComVarStr.ifTM = false;
                uic1 = findobj('Tag','ckbIfTM','Parent',O_figFit);
                set (uic1,'Value',get(uic1,'Min'));
            end
        end
        %
        % main computation
        MaxIter=ComVarStr.StopIter;
        %
        % turn on the multiprocess computations regime if needed
        %
        if isfield (ComVarStr,'ifMuPr') && ~isempty(ComVarStr.ifMuPr) && isreal(ComVarStr.ifMuPr) && ComVarStr.ifMuPr(1)
            try
                if isfield (ComVarStr,'MuPrN') && ~isempty(ComVarStr.MuPrN) && isreal(ComVarStr.MuPrN(1))
                    [M0mp,Mmp]=MPsk(ComVarStr.MuPrN(1));
                else
                    [M0mp,Mmp]=MPsk;
                end
%                ifMuPr=true;
            catch
%                ifMuPr=false;
                ComVarStr.ifMuPr=false;
                Mmp=0;
                M0mp=0;
                if ifDisp
                    beep;
                    disp('Optimizer WARNING: your currently installed Matlab does not probably support the multiprocess version of Optimizer.');
                    disp('The multiprocess regime is turned off!');
                    beep;
                end
            end
            if isfield (ComVarStr,'ifMuPrR') && ~isempty(ComVarStr.ifMuPrR) && isreal(ComVarStr.ifMuPrR)
                ifMuPrR = ComVarStr.ifMuPrR(1); % if the multiprocess regime to be restarted every next batch iteration
            else
                ifMuPrR = false;
            end
        else
%            ifMuPr=false;
            ifMuPrR = false;
            M0mp=0;
            Mmp=0;
        end
        LSF; % clears persistent variables of LSF (LMstep0)
        if isfield(ComVarStr,'nBatchOp') && ~isempty(ComVarStr.nBatchOp) && isnumeric(ComVarStr.nBatchOp) && isreal(ComVarStr.nBatchOp) && round(ComVarStr.nBatchOp(1))
            nBatchOp = abs(round(ComVarStr.nBatchOp(1)));
            kPar = find (ComVarStr.ParStep);
            NBs = ceil(numel(kPar)/nBatchOp);
            if ComVarStr.nBatchOp(1)>0
                ifBrand = false;
            else
                ifBrand = true;
            end
            if NBs>1
                ComVarStr.Df=[]; % in the batch regime the covariance matrix does not make sense
            end
        else
            nBatchOp = 0;
            NBs = 1;
        end
        ComVarStr.NIter = 0;
        if ~isempty(O_figFit)
            refrOptimRes; % refresh the results of the optimization
            set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Starting optimization','ForegroundColor','black');
        end
        for i=1:MaxIter
            if NBs>1 && i>1
                if ~isempty(O_figFit)
                    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat('All (=',num2str(NBs),') batches have been performed'),'ForegroundColor','black');
                end
            end
            R00=R0; % for the batch regime
            try
                if ~isempty(O_figFit)
                    set (findobj('Tag','edMaxIt','Parent',O_figFit),'String',strcat(num2str(i),'/',num2str(MaxIter)));
                    try
                        drawnow; % to refresh controls
                    catch
                        pause(0.01); % to refresh controls
                    end
                end
            catch
            end
            if ifDisp
                disp('-----------------------------------------------------------------------');
                disp(strcat('          Iteration No.',num2str(i),'/',num2str(MaxIter),'; R0=',num2str(R0)));
                if i==1
                    T0 = clock;
                    disp('the current time is:');
                    disp(datestr(T0));
                    CN=getOpVal;        % get the parameter names in the original order
                    if length(ComVarStr.ParStep)>length(CN)
                        ComVarStr.ParStep(length(CN)+1:end)=[];
                    end
                    CN(ComVarStr.ParStep==0)=[];     % exclude parameters not being fitted currently 
                    Nvar=length(CN);                 % total number of the parameters being fitted currently
                    disp(strcat('total number of parameters =',num2str(Nvar)));
                else
                    T1 = clock;
                    disp('the starting and the current time are:');
                    try
                        disp(datestr(T0));
                    catch
                    end
                    disp(datestr(T1));
                    try % etime function can break at month boundaries
                        et = etime(T1,T0);
                        er = (et/(i-1)) * (MaxIter - i + 1);
                        disp(strcat('elapsed time Tel=',num2str(et/60),' m.; estimated remaining time Trem=',num2str(er/60),' m.'));
                    catch
                    end
                end
            end
            if NBs>1
                if ifDisp
                    disp(strcat('Batch optimization in NBs=',num2str(NBs),' substeps'));
                end
                if ifBrand
                    kParN = (1:numel(kPar))';
                end
            end
            if ~isempty(R0) && ~isinf(R0) && ~isnan(R0) && isreal(R0) && R0>=0
                if isfield(ComVarStr,'ifDer') && ~isempty(ComVarStr.ifDer)
                    if isnumeric(ComVarStr.ifDer) || islogical(ComVarStr.ifDer)
                        ifDer = ComVarStr.ifDer(1);
                    elseif isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && (isnumeric(ComVarStr.ifDer.ifDer) || islogical(ComVarStr.ifDer.ifDer))
                        ifDer = ComVarStr.ifDer.ifDer(1);
                    else
                        ifDer=0;
                    end
                else
                    ifDer=0;
                end
                if NBs>1
                    ParStep0=ComVarStr.ParStep;
                end
                if ~isfield(ComVarStr,'dRbat') || isempty(ComVarStr.dRbat) || ~isnumeric(ComVarStr.dRbat)
                    dRbat=0.9999999999;
                else
                    dRbat=ComVarStr.dRbat; % criterion for a repetition of the current batch in the batch mode
                end
                if isfield(ComVarStr,'LMinist') && ~isempty(ComVarStr.LMinist) && isnumeric(ComVarStr.LMinist)
                    LMinist=ComVarStr.LMinist(1);
                else
                    LMinist=0;
                end
                for kB = 1:NBs
                    if ifMuPrR && NBs>1 && (kB>1 || i>1)
                        if isfield (ComVarStr,'MuPrN') && ~isempty(ComVarStr.MuPrN) && isreal(ComVarStr.MuPrN(1))
                            [M0mp,Mmp]=MPsk(ComVarStr.MuPrN(1));
                        else
                            [M0mp,Mmp]=MPsk;
                        end
                    end
                    if NBs>1
                        if ifDisp
                            disp('--------------');
                            disp(strcat('Batch iteration No. ',num2str(kB),'/',num2str(NBs)));
                        end
                        if ~ifBrand
                            kB1 = ((kB-1)*nBatchOp+1) : min(kB*nBatchOp,numel(kPar));
                        else
                            kB2 = randperm(numel(kParN),min(numel(kParN),nBatchOp));
                            kB1 = kParN(kB2);
                            kParN(kB2) = [];
                        end
                        ComVarStr.ParStep = zeros(size(ComVarStr.ParStep));
                        ComVarStr.ParStep(kPar(kB1)) = ParStep0(kPar(kB1));
                        if ~isempty(O_figFit)
                            refrOptimRes; % refresh the results of the optimization
                        end
                    end
                    try
                        R=0;
                        ifbreak = false;
                        R000=R0;
                        if LMinist<0
                            ComVarStr.LMinist=abs(LMinist);
                        end
                        while true
                            [ierr,R,y0,iR01] = LSF(true,ifDer,y0,R0);
                            if NBs>1 && R<R0 && (R0-R)/R0>dRbat
                                R0=R;
                                if ifDisp
                                    disp('Optimizer: the next step will be done in the same batch according to the dRbat parameter');
                                end
                            else
                                break;
                            end
                        end
                        R0=R000;
                        if LMinist<0
                            ComVarStr.LMinist=LMinist;
                            LSF; % to clear the axiliary parameters in the LSF
                        end
                    catch
                        ierr = -1e6;
                        R = Inf;
                        ifbreak = true;
                        if ifDisp
                            beep;
                            disp('Optimizer error in calling LSF');
                        end
                        break;
                    end
                    if NBs>1
                        ParStep0(kPar(kB1))=ComVarStr.ParStep(kPar(kB1));
                    end
                    if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM % output current result if needed
                        try
                            if NBs==1
                                naou = strcat(num2str(i),'.out');
                            else
                                naou = strcat(strcat(num2str(i),'_',num2str(kB),'.out'));
                            end
                            pbOuSim_Callback(naou);
                            if ifDisp
                                disp(strcat('/''',naou,' '' contains the current solution/'));
                            end
                        catch
                            ComVarStr.ifTM = false;
                            try
                                if ~isempty(O_figFit)
                                    uic1 = findobj('Tag','ckbIfTM','Parent',O_figFit);
                                    set (uic1,'Value',get(uic,'Min'));
                                end
                            catch
                            end 
                        end
                    end
                    if isfield(ComVarStr,'ifVref') && ~isempty(ComVarStr.ifVref) && ComVarStr.ifVref(1)
                        try
                            Viewer;
                            feval('Viewer','pbInRefr_Callback');
                        catch
                        end
                    end
                    try
                        ComVarStr.EpsIterFin = abs((R-R0)/R0);
                    catch
                        ComVarStr.EpsIterFin = Inf;
                    end
                    R0 = R;
                    try
                        if ~isempty(O_figFit)
                            if NBs>1
                                str1 = strcat('Batch No.',num2str(kB),'/',num2str(NBs),':');
                                try
                                    if kB==NBs
                                        ComVarStr.EpsIterFin = abs((R-R00)/R00);
                                    end
                                catch
                                    ComVarStr.EpsIterFin = Inf;
                                end
                            else
                                str1='';
                            end
                            if ierr==0
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' No problem has been detected'),'ForegroundColor','black');
                             elseif ierr==1
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' The step was adapted during the computations'),'ForegroundColor','black');
                             elseif ierr==2
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' No convergence was found in the iterative step adaptation'),'ForegroundColor','black');
                             elseif ierr==3
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' No parameters were varied in an accordance to the input steps'),'ForegroundColor','black');
                                 break;
                             elseif ierr==4
                                 [CN,CV,CN0,CV0] = getOpVal('%+26.16e');
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' Coordinate-wise step was performed, parameter No.',num2str(iR01),' (',CN(iR01),')'),'ForegroundColor','black');
                             elseif ierr~=-1000000
                                 ierr = abs(ierr);
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' Procedure No.',num2str(ierr),' was not found'),'ForegroundColor','red');
                                 EnaButtons;
                                 beep;
                            else
                                 set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat(str1,' Critical error'),'ForegroundColor','red');
                                 EnaButtons;
                                 beep;
                            end
                            refrOptimRes; % refresh the results of the optimization
                        end
                    catch
                    end
                    if NBs>1
                        ComVarStr.Df=[]; % in the batch regime the covariance matrix does not make much sense
                    end
                    if kB==NBs
                        try
%                            if ierr==2 || ierr==3 || ierr>4 || ierr<0 || isempty(R) || R==0 || isempty(ComVarStr.EpsIterFin) || isnan(ComVarStr.EpsIterFin) || any(any(~isreal(ComVarStr.EpsIterFin))) || isinf(ComVarStr.EpsIterFin) || ComVarStr.EpsIterFin<=ComVarStr.EpsIter
                            if ierr==3 || ierr>4 || ierr<0 || isempty(R) || R==0 || isempty(ComVarStr.EpsIterFin) || isnan(ComVarStr.EpsIterFin) || any(any(~isreal(ComVarStr.EpsIterFin))) || isinf(ComVarStr.EpsIterFin) || ComVarStr.EpsIterFin<=ComVarStr.EpsIter
                                ifbreak=true; % to break from the outer loop
                                break;
                            else
                                ifbreak=false;
                            end
                        catch
                            ifbreak=true;
                            break;
                        end
                        if NBs>1 && i<MaxIter && ifMuPrR && M0mp~=Mmp
                            MPsk(M0mp); % turns off the multiprocess computations regime
                        end
                    elseif ifMuPrR && M0mp~=Mmp
                        MPsk(M0mp); % turns off the multiprocess computations regime
                    end
                end
                ComVarStr.NIter = i;
                if NBs>1
                    ComVarStr.ParStep=ParStep0;
                    ComVarStr.Df=[];
                end
                if ifbreak
                    break;
                end
%             else
%                 R = R0;
%                 ComVarStr.sigma2 = R0;
%                 ComVarStr.NIter = i-1;
                if ~isempty(O_figFit)
                    refrOptimRes; % refresh the results of the optimization
                end
            end
        end
        if M0mp~=Mmp
            MPsk(M0mp); % turns off the multiprocess computations regime
        end
        ComVarStr.StopIter = MaxIter; % to avoid unpredictable reading of a wrong value from edMaxIt when it dispalys current number of iterations
        try
            if ~isempty(O_figFit)
                refrOptimRes; % refresh the results of the optimization
                set(uic,'String','Iterations','Enable','on');
                set(uic1,'String','fminunc','Enable','on');
                set(uic2,'String','fminsearch','Enable','on');
                set (findobj('Tag','edMaxIt','Parent',O_figFit),'String',num2str(ComVarStr.StopIter));
                if NBs>1
                   set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',strcat('All (=',num2str(NBs),') batches have been performed'),'ForegroundColor','black');
                end
            end
        catch
        end
    else
        try
            if ~isempty(O_figFit)
                set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Critical error: The model and modeled data are inconsistent','ForegroundColor','red');
                EnaButtons;
            end
        catch
        end
        beep;
    end
else
    try
        if ~isempty(O_figFit)
            set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Input is erroneous','ForegroundColor','red');
            EnaButtons;
        end
    catch
    end
    beep;
end
%
if ifDisp
    beep;
    disp('=======================================================================');
    T1 = clock;
    disp('the starting and the current time are:');
    try
        disp(datestr(T0));
    catch
    end
    disp(datestr(T1));
    try % etime function can break at month boundaries
        et = etime(T1,T0);
        disp(strcat('elapsed time Tel=',num2str(et/60),' m.'));
    end
    disp('          THE END');
    disp('!!!   the current results can be inspected using the ''Viewer'' window   !!!');
    disp('!!!   the current state can be saved using the ''Modeler'' window   !!!');
    beep;
end
if strcmp(s0,'on')
    warning on;
end
try
    drawnow; % to refresh controls
catch
    pause(0.01); % to refresh controls
end
%
% refresh the Modeler window if it is open
global M_figMod;
if ~isempty(M_figMod) && ishandle(M_figMod) && ishandle(figure(M_figMod))
    ComVarStr.ifDisp=0; % to avoid a message of the chosen block
    Modeler('popPron_Callback');
    try
        if ~isempty(O_figFit)
            figure(O_figFit);
        end
    catch
    end
    ComVarStr.ifDisp=ifDisp;
else
    clear global M_figMod;
end
%
return

function varargout = Radio_Callback(h, varargin)
 global O_figFit  % main figure handle
 hR   = findobj ('Style','RadioButton','Parent',O_figFit);
 for i=1:length(hR)
     if hR(i) ~= h
         set (hR(i),'Value',get(hR(i),'Min'));
     else
         set (hR(i),'Value',get(hR(i),'Max'));
     end
 end
 ChkReg_arr;
return

function ChkReg_arr
 global O_figFit  % main figure handle
 global ComVarStr;
 global O_Truncation; % for keeping the current truncation condition
 global O_lambda1; % for keeping the current refularization parameter
 global O_lambda3; % for keeping boundaries for the L-curve method
 ComVarStr.ifRob=false;
 hR   = findobj ('Style','RadioButton','Parent',O_figFit);
 pofigFit = get(gcf,'Position');
 for i=1:length(hR)
     if get(hR(i),'Value')==get(hR(i),'Max')
         Tag0=get(hR(i),'Tag');
     end
 end
 uic  = findobj('Tag','txtNo','Parent',O_figFit);
 if strcmp(Tag0,'RBno')
  set (uic, 'Position',[pofigFit(3)*.1667 pofigFit(4)*.0667 pofigFit(3)*.25 pofigFit(4)*.0883]);
  set (uic, 'Visible','on');
  set(findobj('Tag','ckbIfLM','Parent',O_figFit),'Enable','on','String','Levenberg-Marquardt');
  set(findobj('Tag','pbFminunc','Parent',O_figFit),'Enable','on');
  set(findobj('Tag','pbFminsearch','Parent',O_figFit),'Enable','on');
 else
  set (uic, 'Visible','off');
 end
 uic  = findobj('Tag','txtFishSVD','Parent',O_figFit);
 uic1 = findobj('Tag','edFishSVD','Parent',O_figFit);
 if strcmp(Tag0,'RBFishSVD')
  set (uic, 'Position',[pofigFit(3)*.2 pofigFit(4)*.17 pofigFit(3)*.2 pofigFit(4)*.025]);
  set (uic1,'Position',[pofigFit(3)*.19 pofigFit(4)*.1 pofigFit(3)*.25 pofigFit(4)*.035]);
  set (uic, 'Visible','on');
  set (uic1,'Visible','on');
  if ~isfield(ComVarStr,'kkk') || isempty(ComVarStr.kkk) || any(size(ComVarStr.kkk)~=1) || ~isnumeric(ComVarStr.kkk) || ComVarStr.kkk<0
      if isempty(O_Truncation)
          O_Truncation = 0;
      end
      ComVarStr.kkk = O_Truncation;
      myGenWrite('edFishSVD',ComVarStr.kkk,'-');
  end
  myGenWrite('edFishSVD',ComVarStr.kkk,'0');
 else
  set (uic, 'Visible','off');
  set (uic1,'Visible','off');
 end
 uic1 = findobj('Tag','ckbFishParad','Parent',O_figFit);
 uic7 = findobj('Tag','txtpRes','Parent',O_figFit);
 uic8 = findobj('Tag','edpRes','Parent',O_figFit);
 if strcmp(Tag0,'RBFishSVD') || strcmp(Tag0,'RBFishPar')
  set(findobj('Tag','pbFminunc','Parent',O_figFit),'Enable','off');
  set(findobj('Tag','pbFminsearch','Parent',O_figFit),'Enable','off');
  set (uic7, 'Position',[pofigFit(3)*0.573 pofigFit(4)*.17 pofigFit(3)*.16 pofigFit(4)*.025]);
  set (uic8, 'Position',[pofigFit(3)*0.573 pofigFit(4)*.1 pofigFit(3)*.16 pofigFit(4)*.035]);
  set (uic7, 'Visible','on');
  set (uic8, 'Visible','on');
  set (uic1, 'Position',[pofigFit(3)*.19 pofigFit(4)*.03 pofigFit(3)*.1 pofigFit(4)*.025]);
  set (uic1, 'Visible','on');
  if get(uic1,'Value') == get(uic1,'Max')
      ComVarStr.ifAdopConstr=true;
  else
      ComVarStr.ifAdopConstr=false;
  end
  if strcmp(Tag0,'RBFishPar')
      set(findobj('Tag','ckbIfLM','Parent',O_figFit),'Enable','off','String','L-M is not supported'); % turn off the Levenberg-Marquardt adatation
  else
      set(findobj('Tag','ckbIfLM','Parent',O_figFit),'Enable','on','String','Levenberg-Marquardt'); % turn on the Levenberg-Marquardt adatation
  end
 else
  ComVarStr.ifAdopConstr = [];
  ComVarStr.kkk = [];
  set (uic7, 'Visible','off');
  set (uic8, 'Visible','off');
  set (uic1, 'Visible','off');
 end
 
 uic = findobj('Tag','txtFishPar','Parent',O_figFit);
 if strcmp(Tag0,'RBFishPar')
 try
    if isfield(ComVarStr,'kkkc') && ~isempty(ComVarStr.kkkc) && all(all(isnumeric(ComVarStr.kkkc))) &&  isfield(ComVarStr,'lambdac') && ~isempty(ComVarStr.lambdac) && all(isnumeric(ComVarStr.lambdac)) && size(ComVarStr.kkkc,1)==length(ComVarStr.lambdac) && length(getpara([],[],false))==size(ComVarStr.kkkc,2)
        ComVarStr.kkk=ComVarStr.kkkc;
        ComVarStr.lambda=ComVarStr.lambdac;
        set (uic,'String','The matrix ComVarStr.kkkc and the right-hand vector ComVarStr.lambdac of the constraint exist and are used. Modify or remove them in the ''NONE'' regime using the MatLab Command window','ForegroundColor','red');
    else
        findConstr; % a procedure to construct the constraint equations (creates a matrix ComVarStr.kkk and a right-hand vector ComVarStr.lambda)
        set (uic,'String','Set the disired hypothetic values in the Modeler window.','ForegroundColor','black');
    end
 catch
     findConstr; % a procedure to construct the constraint equations (creates a matrix ComVarStr.kkk and a right-hand vector ComVarStr.lambda)
     set (uic,'String','Set the disired hypothetic values in the Modeler window.','ForegroundColor','black');
 end
  set (uic,'Position',[pofigFit(3)*.15 pofigFit(4)*.1 pofigFit(3)*.29 pofigFit(4)*.08]);
  set (uic,'Visible','on');
 else
  ComVarStr.lambda=[];
  set (uic,'Visible','off');
 end
 
 uic  = findobj('Tag','txtTikh','Parent',O_figFit);
 uic1 = findobj('Tag','ckbTikh','Parent',O_figFit);
 uic2 = findobj('Tag','ckbTikhLplot','Parent',O_figFit);
 uic3 = findobj('Tag','edLambda0','Parent',O_figFit);
 uic4 = findobj('Tag','edLambda1','Parent',O_figFit);
 uic5 = findobj('Tag','edLambdaN','Parent',O_figFit);
 uic7 = findobj('Tag','txtTikhRes','Parent',O_figFit);
 uic8 = findobj('Tag','edLambda0Res','Parent',O_figFit);
 if strcmp(Tag0,'RBTikh')
  set(findobj('Tag','pbFminunc','Parent',O_figFit),'Enable','off');
  set(findobj('Tag','pbFminsearch','Parent',O_figFit),'Enable','off');
  set(findobj('Tag','ckbIfLM','Parent',O_figFit),'Enable','off','String','L-M is not supported');
  if isempty(O_lambda1)
      O_lambda1 = 1E-10;
  end
  if isempty(O_lambda3)
      O_lambda3(1:3) = O_lambda1;
      O_lambda3(2)   = 1E-6;
      O_lambda3(3)   = 101;
  end
  if ~isfield(ComVarStr,'ifplot') || isempty(ComVarStr.ifplot) % in a case it is an initialization with already existing ComVarSpace structure
      if get(uic1,'Value')==get(uic1,'Max')
        ComVarStr.ifplot=true;
      else
        ComVarStr.ifplot=false;
      end
   end
   if ComVarStr.ifplot
       ComVarStr.lambda = O_lambda3;
       myGenWrite('edLambda0',ComVarStr.lambda(1),'-');
       myGenWrite('edLambda1',ComVarStr.lambda(2),'-');
       myGenWrite('edLambdaN',ComVarStr.lambda(3),'-');
   else
       ComVarStr.lambda = []; % to exclude higher components
       ComVarStr.lambda = O_lambda1;
       myGenWrite('edLambda0',ComVarStr.lambda,'-');
   end
   set (uic, 'Position',[pofigFit(3)*.2 pofigFit(4)*.17 pofigFit(3)*.2 pofigFit(4)*.025]);
   set (uic1,'Position',[pofigFit(3)*.19 pofigFit(4)*.03 pofigFit(3)*.125 pofigFit(4)*.025]);
   set (uic2,'Position',[pofigFit(3)*.3   pofigFit(4)*.03 pofigFit(3)*.125 pofigFit(4)*.025]);
   set (uic, 'Visible','on');
   set (uic1,'Visible','on');
   set (uic2,'Visible','on');
   set (uic7, 'Position',[pofigFit(3)*0.573 pofigFit(4)*.17 pofigFit(3)*.16 pofigFit(4)*.025]);
   set (uic8, 'Position',[pofigFit(3)*0.573 pofigFit(4)*.1 pofigFit(3)*.16 pofigFit(4)*.035]);
   set (uic7, 'Visible','on');
   set (uic8, 'Visible','on');
   if get(uic1,'Value')==get(uic1,'Max')
      set (uic2,'Enable','on');
      set (uic3,'Position',[pofigFit(3)*.19 pofigFit(4)*.1 pofigFit(3)*.07 pofigFit(4)*.035]);
      set (uic3,'TooltipString','Initial value of the regularization parameter for the L-curve grid');
      set (uic3,'Visible','on');
      set (uic4,'Position',[pofigFit(3)*.28 pofigFit(4)*.1 pofigFit(3)*.07 pofigFit(4)*.035]);
      set (uic4,'TooltipString','Final value of the regularization parameter for the L-curve grid');
      set (uic4,'Visible','on');
      set (uic5,'Position',[pofigFit(3)*.37 pofigFit(4)*.1 pofigFit(3)*.07 pofigFit(4)*.035]);
      set (uic5,'TooltipString','Total number of grid nodes in the L-curve method');
      set (uic5,'Visible','on');
   else
      set (uic2,'Enable','off');
      set (uic3,'Position',[pofigFit(3)*.19 pofigFit(4)*.1 pofigFit(3)*.25 pofigFit(4)*.035]);
      set (uic3,'TooltipString','Enter value of the regularization parameter');
      set (uic3,'Visible','on');
      set (uic4,'Visible','off');
      set (uic5,'Visible','off');
  end
 else
  if ~strcmp(Tag0,'RBFishPar')
    ComVarStr.lambda=[];
  end
  ComVarStr.ifplot=[];
  set (uic, 'Visible','off');
  set (uic1,'Visible','off');
  set (uic2,'Visible','off');
  set (uic3,'Visible','off');
  set (uic4,'Visible','off');
  set (uic5,'Visible','off');
  set (uic7, 'Visible','off');
  set (uic8, 'Visible','off');
 end
 
 uic  = findobj('Tag','popRob','Parent',O_figFit);
 uic1 = findobj('Tag','txtRob','Parent',O_figFit);
 uic4 = findobj('Tag','edRobPar','Parent',O_figFit);
 uic7 = findobj('Tag','txtRobPar','Parent',O_figFit);
 uic10= findobj('Tag','txtRobParameters','Parent',O_figFit);
 if strcmp(Tag0,'RBRob')
     set(findobj('Tag','pbFminunc','Parent',O_figFit),'Enable','on');
     set(findobj('Tag','pbFminsearch','Parent',O_figFit),'Enable','on');
     set(findobj('Tag','ckbIfLM','Parent',O_figFit),'Enable','on','String','Levenberg-Marquardt');
     ComVarStr.ifRob=true;
     set (uic,'Visible','on', ...
         'Position',[pofigFit(3)*.19 pofigFit(4)*.1 pofigFit(3)*0.25 pofigFit(4)*.035] ...
         );
     set (uic1,'Visible','on', ...
         'Position',[pofigFit(3)*.19 pofigFit(4)*.135 pofigFit(3)*0.25 pofigFit(4)*.03] ...
         );
     set (uic4,'Visible','on', ...
         'Position',[pofigFit(3)*.19 pofigFit(4)*.03 pofigFit(3)*0.25 pofigFit(4)*.035] ...
         );
     set (uic7,'Visible','on', ...
         'Position',[pofigFit(3)*.19 pofigFit(4)*.065 pofigFit(3)*0.25 pofigFit(4)*.03] ...
         );
     SetRobPar; % seting the default robust parameters
     set (uic10,'Visible','on', ...
         'Position',[pofigFit(3)*0.19 pofigFit(4)*.17 pofigFit(3)*.25 pofigFit(4)*.025]);
 else
     ComVarStr.ifRob=false;
     set (uic,'Visible','off');
     set (uic1,'Visible','off');
     set (uic4,'Visible','off');
     set (uic7,'Visible','off');
     set (uic10,'Visible','off');
 end
 ckbIfLM_Callback; % to refresh ComVarStr.ifLM
 try
%     drawnow; % to refresh controls
     pause(0.01); % to refresh controls
 catch
%     pause(0.01); % to refresh controls
end
return

function SetRobPar
 global O_figFit  % main figure handle
 global ComVarStr
 global O_cRobs % current values of the robust function parameters
 if isempty(O_cRobs)
     O_cRobs = ones(7,1);
     O_cRobs(1) = 2;
     O_cRobs(2) = 2;
     O_cRobs(3) = 6/pi;
     O_cRobs(4) = 27;
     O_cRobs(5) = 1.0/3.0;
     O_cRobs(6) = 18;
     O_cRobs(7) = 27;
 end
 uic  = findobj('Tag','popRob','Parent',O_figFit);
 uic4 = findobj('Tag','edRobPar','Parent',O_figFit);
 uic5 = findobj('Tag','txtRobPar','Parent',O_figFit);
 %
 RobStr = get(uic,'String');
 curRob = RobStr(get(uic,'Value'));
 ParVal = myGenRead(uic4);
 %
     if strcmp(curRob,'Huber')
         myGenWrite(uic4,O_cRobs(1),'2',[]);
         set(uic5,'String','s','TooltipString','Robust parameter. Default s=2; the less s the stronger is the robustness');
         ComVarStr.hRob = @HuberRob;
         ComVarStr.cRob = O_cRobs(1);
     elseif strcmp(curRob,'Winsor')
         myGenWrite(uic4,O_cRobs(2),'2',[]);
         set(uic5,'String','s','TooltipString','Robust parameter. Default s=2; the less s the stronger is the robustness');
         ComVarStr.hRob = @WinsorRob;
         ComVarStr.cRob = O_cRobs(2);
     elseif strcmp(curRob,'Andrews')
         myGenWrite(uic4,O_cRobs(3),'1.90985931710274',[]);
         set(uic5,'String','a','TooltipString','Robust parameter. Default a = 6/pi = 1.90985931710274;  the less a the stronger is the robustness');
         ComVarStr.hRob = @AndrewsRob;
         ComVarStr.cRob = O_cRobs(3);
     elseif strcmp(curRob,'Tukey')
         myGenWrite(uic4,O_cRobs(4),'27',[]);
         set(uic5,'String','c^2','TooltipString','Robust parameter. Default c^2=27; the less c^2 the stronger is the robustness');
         ComVarStr.hRob = @TukeyRob;
         ComVarStr.cRob = O_cRobs(4);
     elseif strcmp(curRob,'Ramsey')
         myGenWrite(uic4,O_cRobs(5),'0.3333333333333333',[]);
         set(uic5,'String','lambda','TooltipString','Robust parameter. Default lambda=1/3; the greater lambda the stronger is the robustness');
         ComVarStr.hRob = @RamseyRob;
         ComVarStr.cRob = O_cRobs(5);
     elseif strcmp(curRob,'Welsch')
         myGenWrite(uic4,O_cRobs(6),'18',[]);
         set(uic5,'String','c^2','TooltipString','Robust parameter. Default c^2=18; the less c^2 the stronger is the robustness');
         ComVarStr.hRob = @WelschRob;
         ComVarStr.cRob = O_cRobs(6);
     elseif strcmp(curRob,'Lorenzian')
         myGenWrite(uic4,O_cRobs(7),'27',[]);
         set(uic5,'String','c^2','TooltipString','Robust parameter. Default c^2=27; the less c^2 the stronger is the robustness');
         ComVarStr.hRob = @LorUDRob;
         ComVarStr.cRob = O_cRobs(7);
     else
         myGenWrite(uic4,[],'');
         set(uic5,'String','Parameter','TooltipString','Parameter of the robust estimation function');
         ComVarStr.hRob = [];
         ComVarStr.cRob = [];
     end
return

function refrOptimizer
%
% refresh all the controls in the Optimizer window
global O_figFit  % main figure handle
global ComVarStr;
try
    if ~exist('O_figFit','var')
        return;
    end
catch
end
% if ~isfield(ComVarStr,'ifLM') || isempty(ComVarStr.ifLM)
%     ComVarStr.ifLM = true;
%     ifLM=true;
% else
%     ifLM=ComVarStr.ifLM(1);
% end
try
    drawnow; % to refresh controls
catch
    pause(0.01); % to refresh controls
end
%
% refresh Decimal digit accuracy
if isfield(ComVarStr,'VPALim') && ~isempty(ComVarStr.VPALim) && all(all(isnumeric(ComVarStr.VPALim))) && ComVarStr.VPALim>=0
    ComVarStr.VPALim = round(ComVarStr.VPALim);
else
    ComVarStr.VPALim = 16;
end
%
% refresh number of iterations
if isfield(ComVarStr,'StopIter') && ~isempty(ComVarStr.StopIter) && all(all(isnumeric(ComVarStr.StopIter))) && ComVarStr.StopIter>=0
    ComVarStr.StopIter = round(ComVarStr.StopIter);
else
    ComVarStr.StopIter = 1;
end
myGenWrite('edMaxIt',ComVarStr.StopIter,'-',[]);
%
% refresh desired accuracy
if ~isfield(ComVarStr,'EpsIter') || isempty(ComVarStr.EpsIter) || ~isnumeric(ComVarStr.EpsIter)
%    ComVarStr.EpsIter=abs(ComVarStr.EpsIter);
%else
    ComVarStr.EpsIter=0;
end
myGenWrite('edDesAccur',ComVarStr.EpsIter,'-',[]);
%
% refresh radiobuttons
nRob=[];
cRob=[];
try
    if ComVarStr.ifRob % robust button is activated
        h = findobj('Tag','RBRob','Parent',O_figFit);
        try
            f = functions(ComVarStr.hRob);
            f = f.function;
            if   strcmp(f,'HuberRob')
                nRob = 1;
                cRob = 2;
            elseif strcmp(f,'WinsorRob')
                nRob = 2;
                cRob = 2;
            elseif strcmp(f,'AndrewsRob')
                nRob = 3;
                cRob = 1.90985931710274;
            elseif strcmp(f,'TukeyRob')
                nRob = 4;
                cRob = 27;
            elseif strcmp(f,'RamseyRob')
                nRob = 5;
                cRob = 1.0/3.0;
            elseif strcmp(f,'WelschRob')
                nRob = 6;
                cRob = 18;
            elseif strcmp(f,'LorUDRob')
                nRob = 7;
                cRob = 27;
            end
        catch
        end
        try
            cRob = ComVarStr.cRob;
        catch
        end
        if ~isempty(nRob)
            set(findobj('Tag','popRob','Parent',O_figFit),'Value',nRob);
            ChkReg_arr;
            if ~isempty(cRob)
                myGenWrite('edRobPar',cRob);
            end
        end
    elseif isfield(ComVarStr,'kkk') && ~isempty(ComVarStr.kkk) && all(all(isnumeric(ComVarStr.kkk))) && (any(size(ComVarStr.kkk)>1) || length(getpara)==1) && isfield(ComVarStr,'lambda') && any(size(ComVarStr.kkk)==length(ComVarStr.lambda)) % Hypothesis check button is activated
        h = findobj('Tag','RBFishPar','Parent',O_figFit);
        try
            if ComVarStr.ifAdopConstr
                set(findobj('Tag','ckbFishParad','Parent',O_figFit),'Value',get(findobj('Tag','ckbFishParad','Parent',O_figFit),'Max'));
            else
                set(findobj('Tag','ckbFishParad','Parent',O_figFit),'Value',get(findobj('Tag','ckbFishParad','Parent',O_figFit),'Min'));
            end
        catch
            ComVarStr.ifAdopConstr = false;
            set(findobj('Tag','ckbFishParad','Parent',O_figFit),'Value',get(findobj('Tag','ckbFishParad','Parent',O_figFit),'Min'));
        end
    elseif  isfield(ComVarStr,'lambda') && ~isempty(ComVarStr.lambda) && all(isnumeric(ComVarStr.lambda)) && any(ComVarStr.lambda~=0) && (~isfield(ComVarStr,'ifplot') || isempty(ComVarStr.ifplot) || ~ComVarStr.ifplot(1) || length(ComVarStr.lambda)==3) % Tikhonov regularization button is activated
        h = findobj('Tag','RBTikh','Parent',O_figFit);
        myGenWrite('edLambda0',ComVarStr.lambda(1),'1.0E-10');
        if isfield(ComVarStr,'ifplot') && ~isempty(ComVarStr.ifplot) && length(ComVarStr.lambda)==3
            set(findobj('Tag','ckbTikh','Parent',O_figFit),'Value',get(findobj('Tag','ckbTikh','Parent',O_figFit),'Max'));
            ckbTikh_Callback;
            myGenWrite('edLambda1',ComVarStr.lambda(2),'1.0E-6');
            myGenWrite('edLambdaN',ComVarStr.lambda(3),'10');
            if ComVarStr.ifplot
                set(findobj('Tag','ckbTikhLplot','Parent',O_figFit),'Value',get(findobj('Tag','ckbTikhLplot','Parent',O_figFit),'Max'));
            else
                set(findobj('Tag','ckbTikhLplot','Parent',O_figFit),'Value',get(findobj('Tag','ckbTikhLplot','Parent',O_figFit),'Min'));
            end
        else
            set(findobj('Tag','ckbTikh','Parent',O_figFit),'Value',get(findobj('Tag','ckbTikh','Parent',O_figFit),'Min'));
            ckbTikh_Callback;
        end
    elseif isfield(ComVarStr,'kkk') && ~isempty(ComVarStr.kkk) && isnumeric(ComVarStr.kkk) && ComVarStr.kkk>0
        h = findobj('Tag','RBFishSVD','Parent',O_figFit);
        Radio_Callback(h);
    else
        h = findobj('Tag','RBno','Parent',O_figFit);
    end
    Radio_Callback(h);
    %
    % refresh the Levenberg-Marquardt checkbox
%    ComVarStr.ifLM=ifLM; % Radio_Callback could ruin it
    uic = findobj('Tag','ckbIfLM','Parent',O_figFit);
    if strcmp(get(uic,'Enable'),'on')
        if ~isfield(ComVarStr,'ifLM') || isempty(ComVarStr.ifLM)
            ComVarStr.ifLM=true;
        end
        if ComVarStr.ifLM
            set (uic,'Value',get(uic,'Max'));
        else
            set (uic,'Value',get(uic,'Min'));
        end
    end
    %
    % refresh Temp file checkbox
    if ~isfield(ComVarStr,'ifTM') || isempty(ComVarStr.ifTM)
        ComVarStr.ifTM=false;
    end
    uic = findobj('Tag','ckbIfTM','Parent',O_figFit);
    if ComVarStr.ifTM
        set (uic,'Value',get(uic,'Max'));
    else
        set (uic,'Value',get(uic,'Min'));
    end
catch
end
refrOptimRes;
try
    drawnow; % to refresh controls
catch
    pause(0.01); % to refresh controls
end
return

function refrOptimRes
%
% refresh the optimization results
global O_figFit  % main figure handle
global ComVarStr
try
    try
        if ~exist('O_figFit','var')
            return;
        end
    catch
    end
    y = getresults;
    if isempty(y)
        R='-';
        y='-';
        ComVarStr.sigma2=NaN;
    else
        try
            if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isnumeric(ComVarStr.inpCov))) && ~all(all(ComVarStr.inpCov==0))
                R = resi(ComVarStr.input,y,ComVarStr.inpCov);
            elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar) && all(all(isnumeric(ComVarStr.inpCovar))) && ~all(all(ComVarStr.inpCovar==0))
                R = resi(ComVarStr.input,y,ComVarStr.inpCovar);
            else
                R = resi(ComVarStr.input,y);
            end
            try
                y = max(abs(y-ComVarStr.input));
            catch
                y = max(abs(y-ComVarStr.input'));
            end
            CN=getOpVal;        % get the parameter names in the original order
            try
                if length(CN)>1 || ~strcmp(CN,'-')
                    CN(ComVarStr.ParStep==0)=[];     % exclude parameters not being fitted currently 
                end
            catch
            end
            Nvar=length(CN);                 % total number of the parameters being fitted currently
            ComVarStr.sigma2 = R / (length(ComVarStr.input) - Nvar);
        catch
            R = '-';
            y='-';
            ComVarStr.sigma2=NaN;
        end
    end
    myGenWrite('edRepResidual',R,'-');
    myGenWrite('edRepMax',y,'-');
    myGenWrite('edRepSigma',sqrt(ComVarStr.sigma2),'-');
    try
        myGenWrite('edAchIt',ComVarStr.NIter,'-');
        myGenWrite('edAchAccur',ComVarStr.EpsIterFin,'-',[]);
        myGenWrite('edSVDdimAct',ComVarStr.kkk0(1),'-');
        myGenWrite('edSVDdimRec',ComVarStr.kkk0(2),'-');
    catch
        myGenWrite('edAchIt','-','-');
        myGenWrite('edAchAccur','-','-',[]);
        myGenWrite('edSVDdimAct','-','-');
        myGenWrite('edSVDdimRec','-','-');
    end
    if ComVarStr.NIter>0 && size(get(findobj('Tag','txtAdvice','Parent',O_figFit),'String'),1)<2
        try
            if ComVarStr.kkk0(2) < ComVarStr.kkk0(1)
                str0 = get(findobj('Tag','txtAdvice','Parent',O_figFit),'String');
                if strcmp (str0,'No problem has been detected')
                    str0 = 'The fit step is peformed';
                end
                str0 = strvcat(str0,'The problem is unstable due to small singular values','or has an unreasonable differentiation step');
                set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',str0,'ForegroundColor','red');
            elseif isfield (ComVarStr,'Df') && ~isempty(find(diag(ComVarStr.Df)==0,1))
                str0 = get(findobj('Tag','txtAdvice','Parent',O_figFit),'String');
                if strcmp (str0,'No problem has been detected')
                    str0 = 'The fit is peformed.';
                end
                str0 = strvcat(str0,'Some of the parameters do not influence the result','or has an unreasonable differentiation step');
                set(findobj('Tag','txtAdvice','Parent',O_figFit),'String',str0,'ForegroundColor','red');
            end
        catch
        end
    end
    if isfield(ComVarStr,'kkk0') && length(ComVarStr.kkk0)>=3 && strcmp(get(findobj('Tag','edpRes','Parent',O_figFit),'Visible'),'on')
        myGenWrite('edpRes',ComVarStr.kkk0(3),'-');
    end
    if isfield(ComVarStr,'lambda0') && ~isempty(ComVarStr.lambda0) && strcmp(get(findobj('Tag','edLambda0Res','Parent',O_figFit),'Visible'),'on')
        myGenWrite('edLambda0Res',ComVarStr.lambda0,'-');
    end
catch
    myGenWrite('edAchIt','-','-');
    myGenWrite('edAchAccur','-','-');
    myGenWrite('edRepSigma','-','-');
    myGenWrite('edRepResidual','-','-');
    myGenWrite('edSVDdimAct','-','-');
    myGenWrite('edSVDdimRec','-','-');
    myGenWrite('edRepMax','-','-');
    myGenWrite('edLambda0Res','-','-');
    myGenWrite('edpRes','-','-');
end
%
% refresh the listboxes
try
    [CN,CV] = getOpVal;
    set (findobj('Tag','lstbOpPar','Parent',O_figFit),'Value',1);
    set (findobj('Tag','lstbOpParV','Parent',O_figFit),'Value',1);
    set (findobj('Tag','lstbOpPar','Parent',O_figFit),'String',CN);
    set (findobj('Tag','lstbOpParV','Parent',O_figFit),'String',CV);
catch
end
try
    drawnow; % to refresh controls
catch
    pause(0.01); % to refresh controls
end
return

function findConstr
% a procedure to construct the constraint equations (creates a matrix ComVarStr.kkk and a right-hand vector ComVarStr.lambda)
global ComVarStr;
ComVarStr.kkk=[];
try
    n  = length(ComVarStr.ParCnstr);
    if n>0
        k = find(ComVarStr.ParStep~=0);
        k0 = length(k);
        kkk    = zeros(k0);
        lambda = zeros(k0,1);
        if k0>0
            for i=k0:-1:1
                if i<=n && ~isempty(ComVarStr.ParCnstr{k(i)}) && isnumeric(ComVarStr.ParCnstr{k(i)})
                    kkk(i,i)  = 1;
                    lambda(i) = ComVarStr.ParCnstr{k(i)};
                else
                    kkk(i,:)  = [];
                    lambda(i) = [];
                end
            end
        end
    end
    ComVarStr.kkk = [];
    ComVarStr.kkk = kkk;
    ComVarStr.lambda = lambda;
catch
end
return

function edMaxIt_Callback
% "edit" control gets maximum number of iterations
global ComVarStr
a = myGenRead('edMaxIt');
if ~isempty(a)
    ComVarStr.StopIter=a;
elseif ~isfield(ComVarStr,'StopIter') || isempty(ComVarStr.StopIter) || any(any(~isnumeric(ComVarStr.StopIter))) || ComVarStr.StopIter<0
    ComVarStr.StopIter=1;
end
ComVarStr.StopIter=floor(abs(ComVarStr.StopIter));
myGenWrite('edMaxIt',ComVarStr.StopIter,'-',[]);
return

function edDesAccur_Callback
% "edit" control gets desired relative accuracy of the residual sum of squares in the Levenberg-Marquardt iterations
global ComVarStr
a = myGenRead('edDesAccur');
if ~isempty(a)
    ComVarStr.EpsIter=a;
elseif ~isfield(ComVarStr,'EpsIter') || isempty(ComVarStr.EpsIter) || any(any(~isnumeric(ComVarStr.EpsIter)))
    ComVarStr.EpsIter=0;
end
% ComVarStr.EpsIter = abs(ComVarStr.EpsIter);
myGenWrite('edDesAccur',ComVarStr.EpsIter,'-',[]);
return

function edRobPar_Callback
%
% gets the parameter of the robust function
 global O_figFit  % main figure handle
 global ComVarStr
 global O_cRobs      % current values of the robust function parameters
 c = myGenRead('edRobPar');
 if ~isempty(c)
     k = get (findobj('Tag','popRob','Parent',O_figFit),'Value');
     O_cRobs(k) = abs(c);
 end
 ComVarStr.cRob = O_cRobs(k);
 myGenWrite('edRobPar');
return

function ckbTikh_Callback
%
% checkbox turning on/off the L-curve method
ChkReg_arr;
global O_figFit  % main figure handle
global ComVarStr;
global O_lambda1; % for keeping the current refularization parameter
global O_lambda3; % for keeping boundaries for the L-curve method
if isempty(O_lambda1)
    O_lambda1 = 1E-10;
end
if isempty(O_lambda3)
    O_lambda3(1:3) = O_lambda1;
    O_lambda3(2)   = 1E-6;
    O_lambda3(3)   = 101;
end
uic = findobj('Tag','ckbTikh','Parent',O_figFit);
if get(uic,'Value') == get(uic,'Max')
    ComVarStr.lambda = O_lambda3;
    uic1 = findobj('Tag','ckbTikhLplot','Parent',O_figFit);
    if get(uic1,'Value') == get(uic1,'Max')
        ComVarStr.ifplot = true;
    else
        ComVarStr.ifplot = false;
    end
    myGenWrite('edLambda0',ComVarStr.lambda(1),'-');
    myGenWrite('edLambda1',ComVarStr.lambda(2),'-');
    myGenWrite('edLambdaN',ComVarStr.lambda(3),'-');
else
    ComVarStr.lambda = []; % so that to make it a scalar if it was a vector
    ComVarStr.lambda = O_lambda1;
    ComVarStr.ifplot = [];
    myGenWrite('edLambda0',ComVarStr.lambda,'-');
end
return

function ckbTikhLplot_Callback
%
% turning on/off the L-curve plotting
global O_figFit  % main figure handle
global ComVarStr;
uic = findobj('Tag','ckbTikhLplot','Parent',O_figFit);
if get(uic,'Value') == get(uic,'Max');
    ComVarStr.ifplot = true;
else
    ComVarStr.ifplot = false;
end
return

function edLambda0_Callback
%
% gets the initital value of the regularization parameter
 global ComVarStr
 global O_lambda1; % for keeping the current refularization parameter
 global O_lambda3; % for keeping boundaries for the L-curve method
 a = abs(myGenRead('edLambda0'));
 if ComVarStr.ifplot && ~isempty(a)
     O_lambda3(1) = min(a,O_lambda3(2));
     ComVarStr.lambda = O_lambda3;
 elseif ~isempty(a)
     O_lambda1 = a;
     ComVarStr.lambda = O_lambda1;
 end
 myGenWrite('edLambda0',ComVarStr.lambda(1),'-');
return

function edLambda1_Callback
%
% gets the final value of the regularization parameter
 global ComVarStr
 global O_lambda3; % for keeping boundaries for the L-curve method
 a = abs(myGenRead('edLambda1'));
 if ~isempty(a)
     O_lambda3(2) = max(a,O_lambda3(1));
     ComVarStr.lambda = O_lambda3;
 end
 myGenWrite('edLambda1',ComVarStr.lambda(2),'-');
return

function edLambdaN_Callback
% gets the number of the L-curve grid nodes
 global ComVarStr
 global O_lambda3; % for keeping boundaries for the L-curve method
 a = floor(abs(myGenRead('edLambdaN')));
 if ~isempty(a)
     O_lambda3(3) = max(a,1);
     ComVarStr.lambda = O_lambda3;
 end
 myGenWrite('edLambdaN',ComVarStr.lambda(3),'-');
return

function edFishSVD_Callback
%
% get the truncation condition
global O_Truncation; % for keeping the current truncation condition
if isempty(O_Truncation)
    O_Truncation = 0;
end
a = abs(myGenRead('edFishSVD'));
if ~isempty(a)
    if a>1
        a = floor(a);
    end
    O_Truncation = a;
end
global ComVarStr;
ComVarStr.kkk = [];
ComVarStr.kkk = O_Truncation;
myGenWrite('edFishSVD',ComVarStr.kkk);
return

function ckbFishParad_Callback
%
% gets the flag if to adopt the constraints or not
 global O_figFit  % main figure handle
 global ComVarStr
 uic1 = findobj('Tag','ckbFishParad','Parent',O_figFit);
 if get(uic1,'Value') == get(uic1,'Max')
     ComVarStr.ifAdopConstr=true;
 else
     ComVarStr.ifAdopConstr=false;
 end
 refrOptimizer; % to turn on/off the Levenberg-Marquardt adaptation if needed
return

function ckbIfLM_Callback
%
% get the need to perform the Levenberg-Marquardt step adaptation
global O_figFit  % main figure handle
uic = findobj('Tag','ckbIfLM','Parent',O_figFit);
global ComVarStr;
if get(uic,'Value')==get(uic,'Max') && strcmp(get(uic,'Enable'),'on')
    ComVarStr.ifLM = true;
else
    ComVarStr.ifLM = false;
end
return

function lstbOpPar_Callback(h,varargin)
 global O_figFit  % main figure handle
 uic = findobj('Style','listbox','Parent',O_figFit);
 set (uic,'Value',get (h,'Value'));
return

function pbOuSim_Callback(name1)
% output results of the optimization to a file
persistent pathname
global ComVarStr;
s = warning;
s0 = 'on';
for i=1:length(s)
    if strcmp(s(i).identifier,'all')
        s0 = s(i).state;
        break;
    end
end
clear s;
warning off;
key=0;
while (key==0)
  try
      if nargin<1 || isempty(name1) || ~ischar(name1)
        [fname1,pname1] = uiputfile(strcat(pathname,'*.OUT'),'Output results');
        if (isnumeric(fname1) && fname1==0)
            return
        end
        if isempty(findstr(fname1,'.'))
            fname1 = strcat(fname1,'.OUT');
        end
        name1=strcat(pname1,fname1);
        pathname = pname1;
      end
        fid = fopen(name1,'w');
        fprintf (fid,'                  OPTIMIZATION RESULTS \r\n\r\n');
        Nproc = length(ComVarStr.Proc);
        if Nproc == 0
            fprintf(fid, 'Nothing to output');
            status = fclose(fid);
            return
        end
        [CN,CV,CN0,CV0] = getOpVal('%+26.16e');
        if ischar(CV) && strcmp(CV,'-')
            Nvar=0;
        else
            Nvar = length(CN);
        end
        fprintf (fid,strcat(num2str(Nvar,'\t%10u'),' parameters were varied \r\n'));
        if Nvar>=1
            fprintf (fid,'         RESULT            STANDARD DEVIATION (SD)        CONDITIONAL SD        NAME         REGIME \r\n');
            for i = 1:Nvar
                fprintf (fid,strcat(CV{i},'\t',CN{i},' \r\n'));
            end
        end
        Nvar0 = length(CN0);
        if Nvar0>0
            fprintf (fid,strcat(num2str(Nvar0,'\t%10u'),' parameters were fixed \r\n'));
            for i = 1:Nvar0
                fprintf (fid,strcat(CV0{i},'\t',CN0{i},' \r\n'));
            end
        end
        clear CN0;
        clear CV0;
        clear CN;
        clear CV;
        %
        % output the covariance matrix
        if isfield(ComVarStr,'Df') && ~isempty(ComVarStr.Df) && all(all(isnumeric(ComVarStr.Df)))
            Df = ComVarStr.Df;
            CN = '\t\tCovariance matrix of the solution [not corrected by the approximant variance sigma2 = R/(n-m)]\n'; % output comment
            if (~isfield(ComVarStr,'ifSigMult') || isempty(ComVarStr.ifSigMult) || ComVarStr.ifSigMult(1)) && isfield(ComVarStr,'sigma2') && ~isempty(ComVarStr.sigma2) && all(all(isnumeric(ComVarStr.sigma2)))
                try
                    Df = ComVarStr.sigma2*Df;
                    CN = '\t\tCovariance matrix of the solution [corrected by the approximant variance sigma2 = R/(n-m)]\n'; % output comment
                catch
                end
            end
            if isfield(ComVarStr,'ifAdopConstr') && ~isempty(ComVarStr.ifAdopConstr) && ComVarStr.ifAdopConstr(1) && isfield(ComVarStr,'ParCnstr') && ~isempty(ComVarStr.ParCnstr) && iscell(ComVarStr.ParCnstr)
                for kC=1:numel(ComVarStr.ParCnstr)
                    if ~isempty(ComVarStr.ParCnstr{kC}) && isnumeric(ComVarStr.ParCnstr{kC})
                        Df(kC,:)=0;
                        Df(:,kC)=0;
                    end
                end
            end
            fprintf(fid,'\n');
            fprintf(fid,CN);
            try
                for i=1:Nvar
                    C='';
                    for j=1:Nvar
                        if j~=Nvar
                            C = strcat(C,num2str(Df(i,j),'%+26.16e'),'\t');
                        else
                            C=strcat(C,num2str(Df(i,j),'%+26.16e'),'\n');
                        end
                    end
                    fprintf (fid,C);
                end
            catch
                C='-';
                fprintf (fid,C);
            end
            clear Df;
            clear C;
        end
        %
        % output the residual information
        y = getresults;
        reslength = length(y);
        if ~isempty(y)
            if reslength~=numel(ComVarStr.input)
                y=Inf(size(ComVarStr.input));
            end
            try
                D = ComVarStr.inpCov;
            catch
                D = [];
            end
            if isempty(D)
                try
                    D = ComVarStr.inpCovar;
                catch
                    D = ones(reslength,1);
                end
            end
            R = resi(y,ComVarStr.input,D);
            fprintf(fid,'\n');
            fprintf(fid,'R     - Residual sum of squares [with weights predefined by the input uncertainties or the input covariance matrix]\n');
            fprintf(fid,'%26.16g\r\n',R);
            fprintf(fid,'Dmax  - Maximum absolute deviation of the input and model data\r\n');
            fprintf(fid,'%26.16g\r\n',max(abs(y-ComVarStr.input)));
            fprintf(fid,'sigma - Standard deviation of the input data [sqrt(R/(n-m))]\n');
            fprintf(fid,'%26.16g\r\n',sqrt(ComVarStr.sigma2));
            clear y;
            clear D;
        end
        %
        % output the confidence probability
        try
            CP  = fcdf(1/Nvar,Nvar,reslength-Nvar); % the Fisher cumulative distribution function
            CP2 = fcdf(4/Nvar,Nvar,reslength-Nvar); % the Fisher cumulative distribution function
            CP3 = fcdf(9/Nvar,Nvar,reslength-Nvar); % the Fisher cumulative distribution function
            fprintf(fid,'CP    - Confidence probability for a 1, 2, and 3-sigma ellipsoid [Fisher distribution estimate]\n');
            fprintf(fid,'%26.16g  %26.16g  %26.16g\r\n',CP,CP2,CP3);
            CR  = sqrt(finv(0.95,Nvar,reslength-Nvar)*Nvar); % inverse of the Fisher cumulative distribution function
            CR0 = sqrt(finv(0.99,Nvar,reslength-Nvar)*Nvar); % inverse of the Fisher cumulative distribution function
            fprintf(fid,'CR    - Reduced radius of the 95%% and 99%%-confidence ellipsoid [Fisher distribution estimate]\n');
            fprintf(fid,'%26.16g  %26.16g\r\n',CR,CR0);
        catch
        end
        %
        status = fclose(fid);
        key = 1;
  catch mectc
      try
        status = fclose(fid);
      catch
      end
  end
end
if strcmp(s0,'on')
    warning on;
end
return

function [CN,CV,CN00,CV00] = getOpVal(s)
%
% gets string arrays CN and CV containing names and values of the parameters which were varied
% s is optional string for formatting the values
% if number of arguments >2 then the values which were varied (ComVarStr.ParStep~=0) go in CN,CV,
% and the others go in CN00,CV00
% For the parameters with constraints defined by ComVarStr.ParCnstr the
% characters /C/ are added to the name;
% for the non-varied parameters with ComVarStr.ParStep=0 the
% characters /0/ are added to the name;
global ComVarStr
if nargout>2
    ifArr=true;
else
    ifArr=false;
end
try
    N = length(ComVarStr.Proc);
    if N>0
        CV=[];
        CN=[];
        Df=[];
        CV00=''; % for keeping parameters with ParStep = 0
        CN00=''; % for keeping parameters with ParStep = 0
        i  = 0; % current number of the parameter
        i0 = 0; % current number of the parameter which was varied (step~=0)
        i1 = 0; % current number of the 1-D parameter
        for k=1:N
            try
                M = length(ComVarStr.ParField{k});
            catch
                ComVarStr.ParField{k}=[];
                M=0;
            end
            if M>0
                for n=1:M
                    i = i+1;
                    CN0 = ComVarStr.ParField{k}{n};
                    try
                        try
                            CV0 = ComVarStr.(getProNm(k)).(CN0);
%                            CV0 = getfield(ComVarStr,getProNm(k),CN0);
                        catch
                            CV0='-';
                        end
                        [k1,k2] = size(CV0);
                        for j2=1:k2
                            for j1=1:k1
                                if nargin==0 || isempty(s)
                                    CV1 = num2str(CV0(j1,j2));
                                else
                                    try
                                        CV1 = num2str(CV0(j1,j2),s);
                                    catch
                                        CV1 = num2str(CV0(j1,j2),'%+26.16e');
                                    end
                                end
                                i1 = i1+1;
%                                 if k1>1 && k2==1
%                                     CN1 = strcat(CN0,'(',num2str(j1),')');
%                                 elseif k1==1 && k2>1
%                                     CN1 = strcat(CN0,'(',num2str(j2),')');
%                                 elseif k1>1 && k2>1
%                                     CN1 = strcat(CN0,'(',num2str(j1),',',num2str(j2),')');
%                                 else
%                                     CN1 = CN0;
%                                 end
                                if k1>1 || k2>1
                                    CN1 = strcat(CN0,'(',num2str(j1),',',num2str(j2),')');
                                else
                                    CN1 = CN0;
                                end
                                %
                                try
%                                    if isfield(ComVarStr,'ifAdopConstr') && ~isempty(ComVarStr.ifAdopConstr) && ComVarStr.ifAdopConstr(1) && ~isempty(ComVarStr.ParCnstr{i1}) && isnumeric(ComVarStr.ParCnstr{i1})
                                    if ~isempty(ComVarStr.ParCnstr{i1}) && isnumeric(ComVarStr.ParCnstr{i1})
                                        CN1 = strcat(CN1,'        /C/');
                                    end
                                catch
                                end
                                try
                                    if ~isfield(ComVarStr,'ParStep') || isempty(ComVarStr.ParStep(i1)) || ~isnumeric(ComVarStr.ParStep(i1)) || ComVarStr.ParStep(i1)==0
                                        CN1 = strcat(CN1,'        /0/');
                                    end
                                catch
                                        CN1 = strcat(CN1,'        /0/');
                                end
                                %
                                CV01=[];
                                if isfield(ComVarStr,'Df') && ~isempty(ComVarStr.Df) && isnumeric(ComVarStr.Df) && ComVarStr.ParStep(i1)~=0
                                    if isempty(Df)
                                        Df = ComVarStr.Df;
                                        if (~isfield(ComVarStr,'ifSigMult') || isempty(ComVarStr.ifSigMult) || ComVarStr.ifSigMult(1)) && isfield(ComVarStr,'sigma2') && ~isempty(ComVarStr.sigma2) && all(all(isnumeric(ComVarStr.sigma2)))
                                            try
                                                Df = ComVarStr.sigma2*Df;
                                            catch
                                            end
                                        end
                                        if nargin>0 && exist('s','var') && ~isempty(s) % no need in this calculation when the short format is used
                                            try
                                                if isfield(ComVarStr,'Dfi') && isnumeric(ComVarStr.Dfi) && numel(ComVarStr.Dfi)==size(Df,1)
                                                    if (~isfield(ComVarStr,'ifSigMult') || isempty(ComVarStr.ifSigMult) || ComVarStr.ifSigMult(1)) && isfield(ComVarStr,'sigma2') && ~isempty(ComVarStr.sigma2) && all(all(isnumeric(ComVarStr.sigma2)))
                                                        sdDep = ComVarStr.sigma2./ComVarStr.Dfi;
                                                    else
                                                        sdDep = 1./ComVarStr.Dfi;
                                                    end
                                                else
                                                    s0=warning('query');
                                                    s0=strcmp(s0.state,'on');
                                                    warning off;
                                                    lastwarn('');
                                                    sdDep = 1 ./ diag(inv(Df)); % to compute the constrained standard deviations
                                                    if ~isempty(lastwarn) || any(sdDep<0) || any(sdDep>diag(Df)) % switch to vpa (higher precision) computations
                                                        for kl=1:4
                                                            lastwarn('');
                                                            sdDep = 1 ./ diag(double(inv(vpa(Df,16*(k+1))))); % to compute the constrained standard deviations in a case of a badly scaled matrix
                                                            if isempty(lastwarn) && all(sdDep>=0) &&  all(sdDep<=diag(Df))
                                                                break;
                                                            end
                                                        end
                                                        if (~isempty(lastwarn) || any(sdDep<0) || any(sdDep>diag(Df))) && (~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1))
                                                            beep;
                                                            disp('WARNING: conditional standard deviations can be incorrect due to:');
                                                            lastwarn
                                                            beep;
                                                        end
                                                    end
                                                    if s0
                                                        warning on;
                                                    end
                                                end
                                            catch
                                                sdDep = [];
                                            end
                                        end
                                    end
                                    i0 = i0+1;
                                    try
                                        if nargin>0 && ~isempty(s)
                                            if isfield(ComVarStr,'ifAdopConstr') && ~isempty(ComVarStr.ifAdopConstr) && ComVarStr.ifAdopConstr(1) && ~isempty(ComVarStr.ParCnstr{i1}) && isnumeric(ComVarStr.ParCnstr{i1})
                                                try
                                                    CV1 = strcat(CV1,' [',num2str(0.0,s),']');
                                                    if ~isempty(sdDep)
                                                        CV1 = strcat(CV1,' [',num2str(0.0,s),']');
                                                    end
                                                catch
                                                    try
                                                        CV1 = strcat(CV1,' [',num2str(0.0,'%+26.16e'),']');
                                                        if ~isempty(sdDep)
                                                            CV1 = strcat(CV1,' [',num2str(0.0,'%+26.16e'),']');
                                                        end
                                                    catch % for a case of an error at a previous step of the iterations
                                                        CV1 = strcat(CV1,' [-1]');
                                                        if ~isempty(sdDep)
                                                            CV1 = strcat(CV1,' [-1]');
                                                        end
                                                    end
                                                end
                                            else
                                                try
                                                    CV1 = strcat(CV1,' [',num2str(sqrt(Df(i0,i0)),s),']');
                                                    if ~isempty(sdDep)
                                                        CV1 = strcat(CV1,' [',num2str(sqrt(sdDep(i0)),s),']');
                                                    end
                                                catch
                                                    try
                                                        CV1 = strcat(CV1,' [',num2str(sqrt(Df(i0,i0)),'%+26.16e'),']');
                                                        if ~isempty(sdDep)
                                                            CV1 = strcat(CV1,' [',num2str(sqrt(sdDep(i0)),'%+26.16e'),']');
                                                        end
                                                    catch % for a case of an error at a previous step of the iterations
                                                        CV1 = strcat(CV1,' [-1]');
                                                        if ~isempty(sdDep)
                                                            CV1 = strcat(CV1,' [-1]');
                                                        end
                                                    end
                                                end
                                            end
                                        else
                                            try
                                                CV1 = strcat(CV1,' [',num2str(sqrt(Df(i0,i0))),']');
                                            catch % for a case of an error at a previous step of the iterations
                                                CV1 = strcat(CV1,' [-1]');
                                            end
%                                                if ~isempty(sdDep) % no need to output the constrained sd's when the short format is used
%                                                    CV1 = strcat(CV1,' [',num2str(sqrt(sdDep(i0))),']');
%                                                end
                                        end
                                        CV01=[];
                                    catch
                                        CV01 = strcat(CV1,' [0]');
                                        CV1=[];
                                    end
                                elseif ~isfield(ComVarStr,'ParStep') || isempty(ComVarStr.ParStep(i1)) || ~isnumeric(ComVarStr.ParStep(i1)) || ComVarStr.ParStep(i1)==0 % elseif isfield(ComVarStr,'Df') && ~isempty(ComVarStr.Df) && isnumeric(ComVarStr.Df)
                                    CV01 = strcat(CV1,' [0]');
                                    CV1=[];
                                end
                                if ifArr && ~isempty(CV01)
                                    CN00{length(CN00)+1} = strcat( getProNm(k),'.',CN1);
                                    CV00{length(CV00)+1} = CV01;
                                elseif ~isempty(CV01)
                                    CV{length(CV)+1} = CV01;
                                    CN{length(CN)+1} = strcat( getProNm(k),'.',CN1);
                                elseif isfield(ComVarStr,'ParStep') && ~isempty(ComVarStr.ParStep(i1)) && isnumeric(ComVarStr.ParStep(i1)) && ComVarStr.ParStep(i1)~=0
                                    CV{length(CV)+1} = CV1;
                                    CN{length(CN)+1} = strcat( getProNm(k),'.',CN1);
                                end
                            end
                        end
                    catch
                        i1 = min(length(CV),length(CN)) + 1;
                        CV{i1} = '-';
                        CN{i1} = '-';
                    end
                end
            end
        end
    else
        CV = '-';
        CN = '-';
    end
catch
        CV = '-';
        CN = '-';
end
if isempty(CV)
    CV = '-';
    CN = '-';
end
return

function ckbIfTM_Callback
global O_figFit;  % main figure handle
global ComVarStr;
uic = findobj('Tag','ckbIfTM','Parent',O_figFit);
if get(uic,'Value') == get(uic,'Max')
    ComVarStr.ifTM = true;
else
    ComVarStr.ifTM = false;
end
return

function pbShake_Callback(ifRefr)
% ifRefr flag, default =true
%   if true, the view of the modeler window is refreshed after shaking,
%   and TMP files are created when ComVarStr.ifTM=true
%
if nargin==0 || isempty(ifRefr)
    ifRefr=true;
end
global ComVarStr;
    % save the current state to the TMP file if needed
    if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM(1) && ifRefr(1)
            try
                save('TMP.MOT','-MAT','ComVarStr');
%                save -MAT TMP.MOT ComVarStr;
                pause(0.01); % to get saved before any modifications of the saved data happened
            catch
                global O_figFit;  % main figure handle
                ComVarStr.ifTM = false;
                uic = findobj('Tag','ckbIfTM','Parent',O_figFit);
                set (uic,'Value',get(uic,'Min'));
            end
    end
    %
    x0 = collectparam;
    k1 = length(x0);
    ifstepShake =  isfield(ComVarStr,'ifstepShake') && ~isempty(ComVarStr.ifstepShake) && ComVarStr.ifstepShake(1);
    if isfield(ComVarStr,'cShake') && all(all(isnumeric(ComVarStr.cShake))) && ~isempty(ComVarStr.cShake)
        cShake = ComVarStr.cShake;
    else
        if ifstepShake
            cShake = 100;
        else
            cShake = 0.01; % 5% randomizing is the default value
        end
    end
    i0 = 0;
    for i =1:k1
        if iscell(x0{i})
            k2 = length(x0{i});
            for j=1:k2
                [i1 j1] = size(x0{i}{j});
                for jj = 1:j1
                    for ii = 1:i1
                        try
                            i0 = i0+1;
                            try
                             if ComVarStr.ParStep(i0)==0 || (...
                                    isfield(ComVarStr,'ifAdopConstr') && ~isempty(ComVarStr.ifAdopConstr) && ComVarStr.ifAdopConstr(1) &&...
                                    length(ComVarStr.ParCnstr)>=i0 && ~isempty(ComVarStr.ParCnstr{i0}) && isnumeric(ComVarStr.ParCnstr{i0}) )
                                continue;
                             end
                            catch
                            end
                            if  isfield(ComVarStr,'ifstepShake') && ~isempty(ComVarStr.ifstepShake) && ComVarStr.ifstepShake(1)
                                x0{i}{j}(ii,jj) = x0{i}{j}(ii,jj)  + randn(1).*cShake.*ComVarStr.ParStep(i0);
                            else
                                x0{i}{j}(ii,jj) = x0{i}{j}(ii,jj) .* (1 + randn(1).*cShake);
                            end
                        catch
                        end
                    end
                end
            end
        else
            [i1 j1] = size(x0{i});
            for ii = 1:i1
               for jj = 1:j1
                    try
                        i0 = i0+1;
                        if ComVarStr.ParStep(i0)~=0
                            x0{i}(ii,jj) = x0{i}(ii,jj) .* (1 + randn(1).*cShake);
                        end
                    catch
                    end
                end
            end
       end
    end
    putpara(x0); %^^^%
    if ifRefr
        ComVarStr.Df=[];
        ComVarStr.sigma2=[];
        ComVarStr.EpsIterFin = [];
        ComVarStr.NIter = [];
        ComVarStr.kk0 = [];
        ComVarStr.lambda0=[];
        ComVarStr.ifChange=true; % The model has been changed
%        putresults; % clears all the results fields
        refrOptimRes;
        %
        % refresh the Modeler window if it is open
        global M_figMod;
        global O_figFit;
        if ~isempty(M_figMod) && ishandle(M_figMod) && ishandle(figure(M_figMod))
            Modeler('popPron_Callback');
            figure(O_figFit);
        else
            clear global M_figMod;
        end
    end
return

function varargout = pbFminunc_Callback(h, varargin)
global O_figFit  % main figure handle
global ComVarStr;
%
uic = findobj('Tag','pbComp','Parent',O_figFit);
uic1 = findobj('Tag','pbFminunc','Parent',O_figFit);
uic2 = findobj('Tag','pbFminsearch','Parent',O_figFit);
set(uic,'String','WAIT','Enable','off');
set(uic1,'String','WAIT','Enable','off');
set(uic2,'String','WAIT','Enable','off');
try
    drawnow;
end
try
    try
        D = ones(length(ComVarStr.input),1); % default covariance matrix
    catch
        try
            D = ones(getresults,1); % default covariance matrix
        catch
            D = [];
        end
    end
    if isfield(ComVarStr,'inpCov') && all(all(isnumeric(ComVarStr.inpCov))) && isfield(ComVarStr,'input') && any(size(ComVarStr.inpCov)==length(ComVarStr.input)) && ~all(all(ComVarStr.inpCov==0))
        D = ComVarStr.inpCov;
    elseif isfield(ComVarStr,'inpCovar') && all(all(isnumeric(ComVarStr.inpCovar))) && isfield(ComVarStr,'input') && any(size(ComVarStr.inpCovar)==length(ComVarStr.input)) && ~all(all(ComVarStr.inpCovar==0))
        D = ComVarStr.inpCovar;
    end
    try
        R = resi(ComVarStr.input,getresults,D);
    catch
        funval;
        R = resi(ComVarStr.input,getresults,D);
    end
    if isfield(ComVarStr,'StopIter') && ~isempty(ComVarStr.StopIter) && all(all(isreal(ComVarStr.StopIter))) && ComVarStr.StopIter>=0
        MaxIter = round(ComVarStr.StopIter);
    else
        MaxIter = 10;
    end
    if isfield(ComVarStr,'EpsIter') && ~isempty(ComVarStr.EpsIter) && all(all(isreal(ComVarStr.EpsIter)))
        TolFun = abs(ComVarStr.EpsIter);
    else
        TolFun = 1E-6;
    end
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) && ComVarStr.ifDisp(1)
        displ = 'iter';
        T0 = clock;
    else
        displ = 'off';
    end
    OPTIONS = optimset('Display',displ,'MaxIter',MaxIter,'TolFun',TolFun,'TolX',0,'MaxFunEvals',Inf);
    x0 = getpara([],[],false);
    % save ComVarStr to the TMP.MOT file if needed
    if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM
        try
            save('TMP.MOT','-mat','ComVarStr');
%            save -MAT TMP.MOT ComVarStr;
            pause(0.01); % to get saved before any modifications of the saved data happened
            if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                disp('=======================================================================');
                disp('Initial state is saved as ''TMP.MOT''');
            end
        catch
            ComVarStr.ifTM = false;
            uic0 = findobj('Tag','ckbIfTM','Parent',O_figFit);
            set (uic1,'Value',get(uic0,'Min'));
        end
    end
    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No problem has been detected','ForegroundColor','black');
    %
    s = warning;
    s0 = 'on';
    for i=1:length(s)
        if strcmp(s(i).identifier,'all')
            s0 = s(i).state;
            break;
        end
    end
    clear s;
    warning off;
    try
        drawnow; % to refresh controls
    catch
        pause(0.01); % to refresh controls
    end
    [x,fval,exitflag,output] = fminunc(@modfunRes,x0,OPTIONS);
    %
    if fval<R
        setpara(x,false);
        funval;
        ComVarStr.Df=[];
        ComVarStr.kkk0 =[length(x);length(x)];
        ComVarStr.sigma2 = fval/(length(ComVarStr.input)-length(x));
        ComVarStr.EpsIterFin=(R-fval)/R;
        ComVarStr.NIter=output.iterations;
        refrOptimRes; % refresh the results of the optimization
        if strcmp(s0,'on')
            warning on;
        end
        if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM
            try
                pbOuSim_Callback('1.out');
                if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                    disp(strcat('1.out'' contains the current solution/'));
                end
            catch
                ComVarStr.ifTM = false;
                uic1 = findobj('Tag','ckbIfTM','Parent',O_figFit);
                set (uic1,'Value',get(uic,'Min'));
            end
        end
    else
        set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No convergence','ForegroundColor','black');
        setpara(x0,false);
        funval;
        refrOptimRes; % refresh the results of the optimization
        if strcmp(s0,'on')
            warning on;
        end
    end
    %
    % refresh the Modeler window if it is open
    global M_figMod;
    if ~isempty(M_figMod) && ishandle(M_figMod) && ishandle(figure(M_figMod))
        Modeler('popPron_Callback');
        figure(O_figFit);
    else
        clear global M_figMod;
    end
    %
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('=======================================================================');
        T1 = clock;
        disp('the starting and the current time are:');
        try
            disp(datestr(T0));
        catch
        end
        disp(datestr(T1));
        try % etime function can break at month boundaries
            et = etime(T1,T0);
            disp(strcat('elapsed time Tel=',num2str(et/60),' m.'));
        end
        disp('          THE END');
        disp('!!!   the current results can be inspected using the ''Viewer'' window   !!!');
        disp('!!!   the current state can be saved using the ''Modeler'' window   !!!');
        beep;
    end
catch
    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Cannot compute. Please check if the ''Optimization'' toolbox is installed and if all the input data are prepared properly','ForegroundColor','red');
end
set(uic,'String','Iterations','Enable','on');
set(uic1,'String','fminunc','Enable','on');
set(uic2,'String','fminsearch','Enable','on');
return

function varargout = pbFminsearch_Callback(h, varargin)
global O_figFit  % main figure handle
global ComVarStr;
%
uic = findobj('Tag','pbComp','Parent',O_figFit);
uic1 = findobj('Tag','pbFminunc','Parent',O_figFit);
uic2 = findobj('Tag','pbFminsearch','Parent',O_figFit);
set(uic,'String','WAIT','Enable','off');
set(uic1,'String','WAIT','Enable','off');
set(uic2,'String','WAIT','Enable','off');
try
    drawnow;
end
try
    try
        D = ones(length(ComVarStr.input),1); % default covariance matrix
    catch
        try
            D = ones(getresults,1); % default covariance matrix
        catch
            D = [];
        end
    end
    if isfield(ComVarStr,'inpCov') && all(all(isnumeric(ComVarStr.inpCov))) && isfield(ComVarStr,'input') && any(size(ComVarStr.inpCov)==length(ComVarStr.input))
        D = ComVarStr.inpCov;
    elseif isfield(ComVarStr,'inpCovar') && all(all(isnumeric(ComVarStr.inpCovar))) && isfield(ComVarStr,'input') && any(size(ComVarStr.inpCovar)==length(ComVarStr.input))
        D = ComVarStr.inpCovar;
    end
    try
        R = resi(ComVarStr.input,getresults,D);
    catch
        funval;
        R = resi(ComVarStr.input,getresults,D);
    end
    if isfield(ComVarStr,'StopIter') && ~isempty(ComVarStr.StopIter) && all(all(isreal(ComVarStr.StopIter))) && ComVarStr.StopIter>=0
        MaxIter = round(ComVarStr.StopIter);
    else
        MaxIter = 10;
    end
    if isfield(ComVarStr,'EpsIter') && ~isempty(ComVarStr.EpsIter) && all(all(isreal(ComVarStr.EpsIter)))
        TolFun = abs(ComVarStr.EpsIter);
    else
        TolFun = 1E-6;
    end
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        displ = 'iter';
        T0 = clock;
    else
        displ = 'off';
    end
    OPTIONS = optimset('Display',displ,'MaxIter',MaxIter,'TolFun',TolFun,'TolX',0,'MaxFunEvals',Inf);
    x0 = getpara([],[],false);
    % save ComVarStr to the TMP.MOT file if needed
    if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM
        try
            save('TMP.MOT','-mat','ComVarStr');
%            save -MAT TMP.MOT ComVarStr;
            pause(0.01); % to get saved before any modifications of the saved data happened
            if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                disp('=======================================================================');
                disp('Initial state is saved as ''TMP.MOT''');
            end
        catch
            ComVarStr.ifTM = false;
            uic0 = findobj('Tag','ckbIfTM','Parent',O_figFit);
            set (uic1,'Value',get(uic0,'Min'));
        end
    end
    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No problem has been detected','ForegroundColor','black');
    %
    s = warning;
    s0 = 'on';
    for i=1:length(s)
        if strcmp(s(i).identifier,'all')
            s0 = s(i).state;
            break;
        end
    end
    clear s;
    warning off;
    try
        drawnow; % to refresh controls
    catch
        pause(0.01); % to refresh controls
    end
    [x,fval,exitflag,output] = fminsearch(@modfunRes,x0,OPTIONS);
    %
    if fval<R
        setpara(x,false);
        funval;
        ComVarStr.Df=[];
        ComVarStr.kkk0 =[length(x);length(x)];
        ComVarStr.sigma2 = fval/(length(ComVarStr.input)-length(x));
        ComVarStr.EpsIterFin=(R-fval)/R;
        ComVarStr.NIter=output.iterations;
        refrOptimRes; % refresh the results of the optimization
        if strcmp(s0,'on')
            warning on;
        end
        if isfield(ComVarStr,'ifTM') && ~isempty(ComVarStr.ifTM) && ComVarStr.ifTM
            try
                pbOuSim_Callback('1.out');
                if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                    disp(strcat('1.out'' contains the current solution/'));
                end
            catch
                ComVarStr.ifTM = false;
                uic1 = findobj('Tag','ckbIfTM','Parent',O_figFit);
                set (uic1,'Value',get(uic,'Min'));
            end
        end
    else
        set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','No convergence','ForegroundColor','black');
        setpara(x0,false);
        funval;
        refrOptimRes; % refresh the results of the optimization
        if strcmp(s0,'on')
            warning on;
        end
    end
    %
    % refresh the Modeler window if it is open
    global M_figMod;
    if ~isempty(M_figMod) && ishandle(M_figMod) && ishandle(figure(M_figMod))
        Modeler('popPron_Callback');
        figure(O_figFit);
    else
        clear global M_figMod;
    end
    %
    if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('=======================================================================');
        T1 = clock;
        disp('the starting and the current time are:');
        try
            disp(datestr(T0));
        catch
        end
        disp(datestr(T1));
        try % etime function can break at month boundaries
            et = etime(T1,T0);
            disp(strcat('elapsed time Tel=',num2str(et/60),' m.'));
        end
        disp('          THE END');
        disp('!!!   the current results can be inspected using the ''Viewer'' window   !!!');
        disp('!!!   the current state can be saved using the ''Modeler'' window   !!!');
        beep;
    end
catch
    set(findobj('Tag','txtAdvice','Parent',O_figFit),'String','Cannot compute. Please check if the ''Optimization'' toolbox is installed and if all the input data are prepared properly','ForegroundColor','red');
end
set(uic,'String','Iterations','Enable','on');
set(uic1,'String','fminunc','Enable','on');
set(uic2,'String','fminsearch','Enable','on');
return

function varargout = Fit_ResizeFcn(h, varargin)
 pause(0.1);
 pofigFit = get(h,'Position');
 if ~isempty(find(pofigFit(3:4)<=0, 1))
    return;
 end

 set (findobj('Tag','lstbOpPar','Parent',h),      'Position',[pofigFit(3)*.03 pofigFit(4)*.4 pofigFit(3)*.2 pofigFit(4)*.5]);
 set (findobj('Tag','lstbOpParV','Parent',h),     'Position',[pofigFit(3)*.25 pofigFit(4)*.4 pofigFit(3)*.2 pofigFit(4)*.5]);
 set (findobj('Tag','pbViewSim','Parent',h),      'Position',[pofigFit(3)*.35 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbModSim','Parent',h),       'Position',[pofigFit(3)*.23 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbOuSim','Parent',h),        'Position',[pofigFit(3)*.03 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);

 set (findobj('Tag','pbFminsearch','Parent',h),   'Position',[pofigFit(3)*.88 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbFminunc','Parent',h),      'Position',[pofigFit(3)*.758 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbExFit','Parent',h),        'Position',[pofigFit(3)*.88 pofigFit(4)*.03 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbHelp','Parent',h),         'Position',[pofigFit(3)*.758 pofigFit(4)*.03 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','pbComp','Parent',h),         'Position',[pofigFit(3)*.634 pofigFit(4)*.93 pofigFit(3)*.1 pofigFit(4)*.04]);

 set (findobj('Tag','edMaxIt','Parent',h),        'Position',[pofigFit(3)*.573 pofigFit(4)*.93 pofigFit(3)*.05 pofigFit(4)*.035]);
 set (findobj('Tag','txtMaxIt','Parent',h),       'Position',[pofigFit(3)*.513 pofigFit(4)*.93 pofigFit(3)*.06 pofigFit(4)*.03]);
 set (findobj('Tag','edDesAccur','Parent',h),     'Position',[pofigFit(3)*0.573 pofigFit(4)*.87 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtDesAccur','Parent',h),    'Position',[pofigFit(3)*0.758 pofigFit(4)*.87 pofigFit(3)*.2 pofigFit(4)*.035]);
 set (findobj('Tag','edAchIt','Parent',h),        'Position',[pofigFit(3)*0.573 pofigFit(4)*.77 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtAchIt','Parent',h),       'Position',[pofigFit(3)*0.758 pofigFit(4)*.77 pofigFit(3)*.2 pofigFit(4)*.035]);
 set (findobj('Tag','edAchAccur','Parent',h),     'Position',[pofigFit(3)*0.573 pofigFit(4)*.71 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtAchAccur','Parent',h),    'Position',[pofigFit(3)*0.758 pofigFit(4)*.71 pofigFit(3)*.2 pofigFit(4)*.035]);
 set (findobj('Tag','edRepResidual','Parent',h),  'Position',[pofigFit(3)*0.573 pofigFit(4)*.61 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtRepResidual','Parent',h), 'Position',[pofigFit(3)*0.758 pofigFit(4)*.61 pofigFit(3)*.2 pofigFit(4)*.035]);
 set (findobj('Tag','edRepSigma','Parent',h),     'Position',[pofigFit(3)*0.573 pofigFit(4)*.55 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtRepSigma','Parent',h),    'Position',[pofigFit(3)*0.758 pofigFit(4)*.55 pofigFit(3)*.2 pofigFit(4)*.035]);
 set (findobj('Tag','edRepMax','Parent',h),       'Position',[pofigFit(3)*0.573 pofigFit(4)*.49 pofigFit(3)*.16 pofigFit(4)*.035]);
 set (findobj('Tag','txtRepMax','Parent',h),      'Position',[pofigFit(3)*0.758 pofigFit(4)*.49 pofigFit(3)*.2 pofigFit(4)*.035]);
 
 set (findobj('Tag','txtNR','Parent',h),          'Position',[pofigFit(3)*.05 pofigFit(4)*.28 pofigFit(3)*.44 pofigFit(4)*.025]);
 set (findobj('Tag','ckbIfTM','Parent',h),        'Position',[pofigFit(3)*.03 pofigFit(4)*0.33 pofigFit(3)*.15 pofigFit(4)*.03]);
 set (findobj('Tag','pbShake','Parent',h),        'Position',[pofigFit(3)*.634 pofigFit(4)*.4 pofigFit(3)*.1 pofigFit(4)*.04]);
 set (findobj('Tag','ckbIfLM','Parent',h),        'Position',[pofigFit(3)*.19 pofigFit(4)*0.21 pofigFit(3)*.15 pofigFit(4)*.03]);

% hR   = findobj ('Style','RadioButton','Parent',h); % this "turn on" fragment of the code is required for Octave
% for i1=1:length(hR)
%     if get(hR(i1),'Max')
%        break;
%     end
% end
 set (findobj('Tag','RBFishPar','Parent',h),      'Position',[pofigFit(3)*.028 pofigFit(4)*0.21 pofigFit(3)*.15 pofigFit(4)*.03]);
 set (findobj('Tag','RBFishSVD','Parent',h),      'Position',[pofigFit(3)*.028 pofigFit(4)*.165 pofigFit(3)*.15 pofigFit(4)*.03]);
 set (findobj('Tag','RBTikh','Parent',h),         'Position',[pofigFit(3)*.028 pofigFit(4)*.12 pofigFit(3)*.15 pofigFit(4)*.03]);
 set (findobj('Tag','RBRob','Parent',h),          'Position',[pofigFit(3)*.028 pofigFit(4)*.075 pofigFit(3)*.15 pofigFit(4)*.03]);
 set (findobj('Tag','RBno','Parent',h),           'Position',[pofigFit(3)*.028 pofigFit(4)*.03 pofigFit(3)*.15 pofigFit(4)*.03]);
% for i=1:length(hR)
%     if i==i1
%         set (hR(i),'Value',1);
%     else
%         set (hR(i),'Value',0);
%     end
% end

 set (findobj('Tag','txtSVDdim','Parent',h),      'Position',[pofigFit(3)*.758 pofigFit(4)*.17 pofigFit(3)*0.22 pofigFit(4)*0.025]);
 set (findobj('Tag','edSVDdimAct','Parent',h),    'Position',[pofigFit(3)*.758 pofigFit(4)*0.1 pofigFit(3)*.1 pofigFit(4)*.035]);
 set (findobj('Tag','txtSVDdimAct','Parent',h),   'Position',[pofigFit(3)*.758 pofigFit(4)*.14 pofigFit(3)*.1 pofigFit(4)*.025]);
 set (findobj('Tag','edSVDdimRec','Parent',h),    'Position',[pofigFit(3)*.88 pofigFit(4)*.1 pofigFit(3)*.1 pofigFit(4)*.035]);
 set (findobj('Tag','txtSVDdimRec','Parent',h),   'Position',[pofigFit(3)*.88 pofigFit(4)*.14 pofigFit(3)*.1 pofigFit(4)*.025]);

 set (findobj('Tag','txtAdvice','Parent',h),   'Position',[pofigFit(3)*0.573 pofigFit(4)*.25 pofigFit(3)*.4 pofigFit(4)*.06]);
 
 ChkReg_arr;
 
return

function EnaButtons
    global ComVarStr
    global O_figFit  % main figure handle
    uic = findobj('Tag','pbComp','Parent',O_figFit);
    uic1 = findobj('Tag','pbFminunc','Parent',O_figFit);
    uic2 = findobj('Tag','pbFminsearch','Parent',O_figFit);
    set(uic,'String','Iterations','Enable','on');
    set(uic1,'String','fminunc','Enable','on');
    set(uic2,'String','fminsearch','Enable','on');
    set (findobj('Tag','edMaxIt','Parent',O_figFit),'String',num2str(ComVarStr.StopIter));
    refrOptimizer;
return

function clearglFit
 global O_figFit     % main figure handle
 global O_cRobs      % current values of the robust function parameters
 global O_lambda1; % for keeping the current refularization parameter
 global O_lambda3; % for keeping boundaries for the L-curve method
 global O_Truncation; % for keeping the current truncation condition
 clear global O_figFit;
 clear global O_cRobs;
 clear global O_lambda1;
 clear global O_lambda3;
 clear global O_Truncation;
return