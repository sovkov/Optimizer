function ViewResOp(ifEr,ND)
% Shows the "Optimizer"/"Modeler" results, alternatively to "Viewer",
% every "output" parameter is shown in a separate graph window sequentially.
%
% USAGE: ViewResOp(ifEr,ND) or ViewResOp(ifEr) or ViewResOp (implying ifEr=1)
%
% Addresses the global structure ComVarStr.
% ifEr=0 - the simulation results are only shown,
% ifEr<0 - the simulation errors are only shown,
% ifEr>0 - the simulation results and errors are shown.
% ND     - the array of the ordinal numbers of the "output" parameters
%          to be shown; by default all parameters.
% By default, every next plot is shown in the same graph window and paused;
% just press "Enter" to continue;
% press any numeric key to keep the current plot and open a new window for further plots.
%%
global ComVarStr
try
    if nargin==0 || isempty(ifEr) || (~isnumeric(ifEr) && ~islogical(ifEr))
        ifEr=1;
    else
        ifEr=ifEr(1);
    end
    if nargin<2 || ~isnumeric(ND)
        ND=[];
    end
    if isfield(ComVarStr,'ResField') && iscell(ComVarStr.ResField)
        ff=[];
        NR=0;  % total number of scalar components being treated
        NDD=0; % number of vector parameters being treated
        if isfield(ComVarStr,'X0')
            NX=numel(ComVarStr.X0);
        else
            NX=0;
        end
        if isfield(ComVarStr,'input')
            Ni=numel(ComVarStr.input);
        else
            Ni=0;
        end
        for n=1:numel(ComVarStr.ResField)
            if ~isempty(ComVarStr.ResField{n})
                if iscell(ComVarStr.ResField{n})
                    for k=1:numel(ComVarStr.ResField{n})
                        ResN=ComVarStr.ResField{n}{k};
                        BlockN=ComVarStr.Proc(n).Name;
                        while iscell(BlockN)
                            BlockN=BlockN{1};
                        end
                        kp=strfind(BlockN,'.');
                        if ~isempty(kp)
                            BlockN(kp(1):end)=[];
                        end
                        kp=strfind(BlockN,'/');
                        if ~isempty(kp)
                            BlockN(1:kp(end))=[];
                        end
                        [NE,descr]=numelP(n,ResN);
                        NDD=NDD+1;
                        if isempty(ND) || ~isempty(find(NDD==ND,1))
                            if ifEr>=0
                                [N,ff]=plotBl(BlockN,ResN,NR,Ni,NX,NE,n,false,descr,ff);
                            end
                            if ifEr
                                if ifEr
                                    if NR<Ni
                                        [N,ff]=plotBl(BlockN,ResN,NR,Ni,NX,NE,n,true,descr,ff);
                                    else
                                        beep;
                                        disp('ViewResOp WARNING: there is no enough ''experimental'' data to make the desired simulation error plots');
                                    end
                                end
                            end
                        else
                            N=numelP(n,ResN);
                        end
                        NR=NR+N;
                    end
                elseif ischar(ComVarStr.ResField{n})
                    ResN=ComVarStr.ResField{n};
                    BlockN=ComVarStr.Proc(n).Name;
                    while iscell(BlockN)
                        BlockN=BlockN{1};
                    end
                    [NE,descr]=numelP(n,ResN);
                    NDD=NDD+1;
                    if isempty(ND) || ~isempty(find(NDD==ND,1))
                        if ifEr>=0
                            [N,ff]=plotBl(BlockN,ResN,NR,Ni,NX,NE,n,false,descr,ff);
                        end
                        if ifEr
                            if NR<Ni
                                [N,ff]=plotBl(BlockN,ResN,NR,Ni,NX,NE,n,true,descr,ff);
                            else
                                beep;
                                disp('ViewResOp WARNING: there is no enough ''experimental'' data to make the desired simulation error plots');
                            end
                        end
                    else
                        N=numelP(n,ResN);
                    end
                    NR=NR+N;
                else
                    beep;
                    disp(strcat('ViewResOp WARNING: incorrest result field at ComVarStr.ResField(',num2str(n),')'));
                    continue;
                end
            end
        end
    else
        beep;
        disp('ViewResOp WARNING: No model or no results fields of the model are found!');
    end
catch mectc
    beep;
    disp('ViewResOp ERROR!');
    disp(mectc.message);
end
return;
end

%%

function [N,ff]=plotBl(BlockN,ResN,NR,Ni,NX,NE,n,ifEr,descr,ff)
global ComVarStr
    if isempty(ff)
        ff=figure;
    else
        try
            figure(ff);
        catch
            ff=figure;
        end
    end
    if ~isempty(BlockN) && ~isempty(ResN) && isnumeric(ComVarStr.(BlockN).(ResN))
        N=numel(ComVarStr.(BlockN).(ResN));
        z=reshape(ComVarStr.(BlockN).(ResN),N,1);
        if N>NE
            z(NE+1:end)=[];
            N=NE;
            beep;
            disp(strcat('ViewResOp WARNING: actual dimensions do not comply Dim1*Dim2! ComVarStr.',BlockN,'.',ResN,', Block No.',num2str(n),'; range-',num2str(NR+1),':',num2str(NR+N)));
        elseif N<NE
            z(N+1:NE)=NaN;
            N=NE;
            disp(strcat('ViewResOp WARNING: actual dimensions do not comply Dim1*Dim2! ComVarStr.',BlockN,'.',ResN,', Block No.',num2str(n),'; range-',num2str(NR+1),':',num2str(NR+N)));
        end
        if ifEr && Ni>=NR+N
            z=ComVarStr.input(NR+(1:N))-z;
            M='+b';
        else
            ifEr=false;
            M='or';
        end
        if N>0
            if NR+N<=NX
                plot(ComVarStr.X0(NR+(1:N)),z,M);
            else
                plot((1:N),z,M);
            end
            if ifEr
                legend('simulation errors');
            elseif NR+N<=Ni
                hold on
                if NR+N<=NX
                    plot(ComVarStr.X0(NR+(1:N)),ComVarStr.input(NR+(1:N)),'.-k');
                else
                    plot((1:N),ComVarStr.input(NR+(1:N)));
                end
                legend('simulation','experiment');
                hold off
            else
                legend('simulation');
            end
            if ifEr
                title(strcat('SIMULATION ERRORS: ComVarStr.',BlockN,'.',ResN,', block No.',num2str(n),'; range-',num2str(NR+1),':',num2str(NR+N)));
            else
                title(strcat('DATA: ComVarStr.',BlockN,'.',ResN,', block No.',num2str(n),'; range-',num2str(NR+1),':',num2str(NR+N)));
            end
            if ~isempty(descr)
                ylabel(descr);
            end
            rf=input('ViewResOp: To continue: within the same graph--press ''Enter''\nIn a new graph--press any numerical key and ''Enter''>');
            if ~isempty(rf)
                ff=[];
            end
        end
    end
return;
end

%%

function [NE,descr]=numelP(n,ResN)
% returns the number of elements NE as prescribed by Dims, and a description descr
% of a parameter ResN in the block No. n.
global ComVarStr
NE=0;
descr=[];
for k=1:numel(ComVarStr.Proc(n).Par)
    ParN=ComVarStr.Proc(n).Par(k).Name;
    while ~isempty(ParN) && iscell(ParN)
        ParN=ParN{1};
    end
    if strcmp(ResN,ParN)
        NE=ComVarStr.Proc(n).Par(k).Dim1*ComVarStr.Proc(n).Par(k).Dim2;
        if isfield(ComVarStr.Proc(n).Par(k),'Descr') && ~isempty(ComVarStr.Proc(n).Par(k).Descr) && ischar(ComVarStr.Proc(n).Par(k).Descr)
            descr=(ComVarStr.Proc(n).Par(k).Descr);
        end
        break;
    end
end
return;
end