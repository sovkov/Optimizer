function setCVS(x,Prc)
% Sets all the empty (presumably RESULT) data fields in the global structure ComVarStr to the contents of the cells of x.
%
% USAGE: setCVS(x,Prc)
%
% Addresses the global structure ComVarStr
% x   - cell array containing fields (model blocks) of ComVarStr whose empty
%       parameters are to be set to the corresponding non-empty parameters of x;
% Prc - a vector of structures with the short names of all the blocks of the model;
global ComVarStr
Nx=length(x);
Np=length(Prc);
for nx=1:Nx
    ifch=0;
    for np=1:Np
        if ~isfield(x{nx},Prc(np).Name) || ~isfield(ComVarStr,Prc(np).Name)
            continue;
        end
        xx=x{nx}.(Prc(np).Name);
%        xx=getfield(x{nx},Prc(np).Name);
        xc=ComVarStr.(Prc(np).Name);
%        xc=getfield(ComVarStr,Prc(np).Name);
        K0=length(ComVarStr.Proc(np).Par);
        for k=1:K0
            pn=ComVarStr.Proc(np).Par(k).Name;
%            pn=getfield(ComVarStr.Proc(np).Par(k),'Name');
            while iscell(pn)
                pn=pn{1};
            end
            yx=xx.(pn);
%            yx=getfield(xx,pn);
            yc=xc.(pn);
%            yc=getfield(xc,pn);
            if ~isempty(yx) && isempty(yc)
                xc.(pn)=yx;
%                xc=setfield(xc,pn,yx);
                ifch=1;
            end
        end
        if ifch
            ComVarStr.(Prc(np).Name)=xc;
%            ComVarStr=setfield(ComVarStr,Prc(np).Name,xc);
        end
%        break;
    end
end
return