function varargout = ParaPlan(varargin)
% The tool for the planning the Optimizer parallel job;

global P_figPar  % main figure handle
global ComVarStr

if (nargin==0)
    if ~isempty(P_figPar)
        figure (P_figPar);
        return
    end
    %
    ParaPlanStart;
	set(P_figPar,'Color',get(0,'defaultUicontrolBackgroundColor'));
    if isfield(ComVarStr,'ifMuPr') && ~isempty(ComVarStr.ifMuPr) && ComVarStr.ifMuPr(1)>0
        Radio_Callback(findobj('Tag','RBplsf','Parent',P_figPar));
    elseif isfield(ComVarStr,'ifMuPr') && ~isempty(ComVarStr.ifMuPr) && ComVarStr.ifMuPr(1)<0
        Radio_Callback(findobj('Tag','RBpmod','Parent',P_figPar));
    else
        Radio_Callback(findobj('Tag','RBpno','Parent',P_figPar));
    end
    %
else
    try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
    end
end
return

function varargout = Par_CloseRequestFcn(h,varargin)
 clearglPar;
 delete (gcbf)
return

function varargout = Par_DeleteFcn(h,varargin)
 clearglPar;
return

function clearglPar
 global P_figPar     % main figure handle
 clear global P_figPar
return

function varargout = Radio_Callback(h, varargin)
 global P_figPar  % main figure handle
 global ComVarStr
hR   = findobj ('Style','RadioButton','Parent',P_figPar);
 for i=1:length(hR)
     if hR(i) ~= h
         set (hR(i),'Value',get(hR(i),'Min'));
     else
         set (hR(i),'Value',get(hR(i),'Max'));
         Tag0=get(hR(i),'Tag');
     end
 end
if strcmp(Tag0,'RBpno')
 set (findobj('Tag','txtPP','Parent',P_figPar), 'String','No parallelism; individual user procedures can be parallalized independently');
 ComVarStr.ifMuPr=0;
 tontof('off');
elseif strcmp(Tag0,'RBplsf')
 set (findobj('Tag','txtPP','Parent',P_figPar), 'String','LSF procedure is parallized, including numerical differentiation');
 ComVarStr.ifMuPr=1;
 tontof('off');
else
 set (findobj('Tag','txtPP','Parent',P_figPar), 'String','Direct model computation is parallized acccording to the plan below');
 ComVarStr.ifMuPr=-1;
 tontof('on');
 lstPPmod_Callback;
end
return

function varargout = lstPPmod_Callback(h, varargin)
 global P_figPar  % main figure handle
 h=findobj('Tag','lstPPmod','Parent',P_figPar);
 listSel(h);
return

function varargout = lstPPgr_Callback(h, varargin)
 global P_figPar  % main figure handle
 h =findobj('Tag','lstPPgr','Parent',P_figPar);
 listSel(h);
return

function varargout = lstPPsgr_Callback(h, varargin)
 global P_figPar  % main figure handle
 h=findobj('Tag','lstPPsgr','Parent',P_figPar);
 listSel(h);
return

function listSel(h)
 global P_figPar  % main figure handle
 global ComVarStr
 uicmod=findobj('Tag','lstPPmod','Parent',P_figPar);
 uicgr =findobj('Tag','lstPPgr','Parent',P_figPar);
 uicsgr=findobj('Tag','lstPPsgr','Parent',P_figPar);
 if ~nargin
     h=[uicmod uicgr uicsgr];
 end

 if ~isfield(ComVarStr,'Proc') || isempty(ComVarStr.Proc)
     set(uicmod,'String','-');
     set(uicgr,'String','-');
     set(uicsgr,'String','-');
 else
     NP=length(ComVarStr.Proc);
     S=cell(NP+1,1);
     for k=1:NP
         if iscell(ComVarStr.Proc(k).Name)
             S{k}=ComVarStr.Proc(k).Name{1};
         else
             S{k}=ComVarStr.Proc(k).Name;
         end
     end
     S{end}='=dummy=';
     set(uicmod,'String',S);
     kkk=[];
     k00=1;
     if isfield(ComVarStr,'MPind') && ~isempty(ComVarStr.MPind)
         NMP=length(ComVarStr.MPind);
         SMP=cell(3*NMP+1,1);
         kk=0;
         for k=0:NMP-1
             kk=kk+1;
             SMP{kk}='-';
             if isfield(ComVarStr.MPind(k+1),'sec') && ~isempty(ComVarStr.MPind(k+1).sec)
                 kk=kk+1;
                 SMP{kk}=S{ComVarStr.MPind(k+1).sec(1)};
                 if length(ComVarStr.MPind(k+1).sec)>1
                     kk=kk+1;
                     SMP{kk}=S{min(NP+1,ComVarStr.MPind(k+1).sec(end))};
                 else % the group input has not been completed
                     kkk=k+1;
                     kkkk=kk;
                 end
             end
         end
         if kk>1
             kk=kk+1;
             SMP{kk}='-';
         end
         if kk<3*NMP+1
             SMP=SMP(1:kk);
         end
         if get(uicgr,'Value')>kk
             set(uicgr,'Value',kk);
         end
         set(uicgr,'String',SMP);
         if ~isempty(kkk) % the group input has not been completed
             set(uicgr,'Value',kkkk);
             set(uicsgr,'String',SMP{kkkk});
         end
         %
         k00=get(uicmod,'Value');
         if any(h==uicmod)
             nm=get(uicmod,'Value');
             if ~isempty(kkk)
                 if kkk>1 && nm<ComVarStr.MPind(kkk-1).sec(end)
                     set(uicmod,'Value',min(NP+1,max(1,ComVarStr.MPind(kkk-1).sec(end))));
                 elseif kkk<NMP && nm>ComVarStr.MPind(kkk+1).sec(1)
                     set(uicmod,'Value',min(NP+1,max(1,ComVarStr.MPind(kkk+1).sec(1))));
                 end
                 set(findobj('Tag','txtPPmod','Parent',P_figPar),'String',strcat('The current model blocks, block No.',num2str(k00)));
                 return
             end
             k0=3*NMP+1;
             for k=0:NMP-1
                 if nm<ComVarStr.MPind(k+1).sec(1)
                     k0=3*k+1;
                     break;
                 elseif nm<ComVarStr.MPind(k+1).sec(end)
                     k0=3*k+2;
                     break;
                 end
             end
             set(uicgr,'Value',k0);
         end
         k0=get(uicgr,'Value');
         k=floor(k0/3);
         k1=rem(k0,3);
         if k1==1
             set(uicsgr,'Value',1);
             set(uicsgr,'String','-');
             if any(h~=uicmod)
                 if k<NMP
                     set(uicmod,'Value',max(1,ComVarStr.MPind(k+1).sec(1)-1));
                 else
                     set(uicmod,'Value',max(1,min(NP,ComVarStr.MPind(NMP).sec(end))));
                 end
             end
             set(findobj('Tag','txtPPmod','Parent',P_figPar),'String',strcat('The current model blocks, block No.',num2str(k00)));
             return
         end
         %
         if k1==2
             k=k+1;
         end
         NSG=length(ComVarStr.MPind(k).sec)-1;
         if NSG>0
             SSG=cell(NSG,1);
             k02=NSG;
             for k2=1:NSG
                 SSG{k2}=S{ComVarStr.MPind(k).sec(k2)};
                 if k00>=ComVarStr.MPind(k).sec(k2)
                     k02=k2;
                 end
             end
             if get(uicsgr,'Value')>NSG
                 set(uicsgr,'Value',NSG);
             end
             set(uicsgr,'String',SSG);
         elseif NSG<0
             set(uicsgr,'String','-');
         end
         if any(h~=uicmod)
             if any(h==uicgr)
                 if k1==0
                     set(uicsgr,'Value',max(1,NSG));
                 else
                     set(uicsgr,'Value',1);
                 end
             end
             if k1~=0 || any(h~=uicgr)
                 k00=ComVarStr.MPind(k).sec(get(uicsgr,'Value'));
             else
                 k00=max(1,min(NP,ComVarStr.MPind(k).sec(NSG+1)));
             end
             set(uicmod,'Value',k00);
         else
             set(uicsgr,'Value',k02);
         end
         %
     else
         set(uicgr,'Value',1);
         set(uicgr,'String','-');
         set(uicsgr,'Value',1);
         set(uicsgr,'String','-');
     end
 end
 set(findobj('Tag','txtPPmod','Parent',P_figPar),'String',strcat('The current model blocks, block No.',num2str(k00)));
return

function varargout = pbPPadgb_Callback(h, varargin)
 global P_figPar  % main figure handle
 global ComVarStr
 uicgr=findobj('Tag','lstPPgr','Parent',P_figPar);
 uicmod=findobj('Tag','lstPPmod','Parent',P_figPar);
 NM=get(uicmod,'Value');
 if isfield(ComVarStr,'MPind') && ~isempty(ComVarStr.MPind)
     NMP=length(ComVarStr.MPind);
     if length(ComVarStr.MPind(NMP).sec)==1
         k = NMP;
         ifs=false;
     else
         k = NMP+1;
         ifs=true;
     end
     for n=1:NMP-1
         if ComVarStr.MPind(n).sec(end)<=NM && ComVarStr.MPind(n+1).sec(1)>=NM
             if length(ComVarStr.MPind(n).sec)>1
                 k=n+1;
                 break;
             elseif length(ComVarStr.MPind(n).sec)==1
                 k=n;
                 ifs=false;
                 break;
             end
         end
     end
 else
     NMP=0;
     ifs=true;
     k=1;
 end
 if ~ifs
     ComVarStr.MPind(k).sec(2)=NM;
 else
     if k>NMP
         ComVarStr.MPind(k).sec=NM;
     else
         TeMp=ComVarStr.MPind(k:NMP);
         ComVarStr.MPind(k).sec=NM;
         ComVarStr.MPind(k+1:NMP+1)=TeMp;
     end
 end
 %%%
 NMP=length(ComVarStr.MPind);
 if1=false;
 while ~if1
     if1=true;
     for k=1:NMP-1
         if ComVarStr.MPind(k).sec(1)>ComVarStr.MPind(k+1).sec(1)
             if1=false;
             sec1=ComVarStr.MPind(k).sec;
             ComVarStr.MPind(k).sec=ComVarStr.MPind(k+1).sec;
             ComVarStr.MPind(k+1).sec=sec1;
         end
     end
 end
 %%%
 if isfield(ComVarStr,'Proc') && length(ComVarStr.MPind(end).sec)>1 && ComVarStr.MPind(end).sec(end)>numel(ComVarStr.Proc)+1% && ComVarStr.Proc(end).ifExec
     ComVarStr.MPind(end).sec(end)=numel(ComVarStr.Proc)+1;
 end
 listSel(uicmod);
return

function varargout = pbPPdlgb_Callback(h, varargin)
 global P_figPar  % main figure handle
 global ComVarStr
 uicgr=findobj('Tag','lstPPgr','Parent',P_figPar);
 if all(strcmp(get(uicgr,'String'),'-'))
     return;
 else
     k0=get(uicgr,'Value');
     k=floor(k0/3);
     k1=rem(k0,3);
     if k1~=0
         k=k+1;
     end
     if isfield(ComVarStr,'MPind') && length(ComVarStr.MPind)>=k && isfield(ComVarStr.MPind(k),'sec') && ~isempty(ComVarStr.MPind(k).sec)
         if k1==0
             ComVarStr.MPind(k).sec(end)=[];
         else
             ComVarStr.MPind(k).sec(1)=[];
             ComVarStr.MPind(k).sec=ComVarStr.MPind(k).sec-1;
         end
     end
     if isfield(ComVarStr,'MPind') && length(ComVarStr.MPind)>=k && (~isfield(ComVarStr.MPind(k),'sec') || isempty(ComVarStr.MPind(k).sec))
         ComVarStr.MPind(k)=[];
     elseif isfield(ComVarStr,'MPind') && isempty(ComVarStr.MPind)
         ComVarStr=rmfield(ComVarStr,'MPind');
     end
     listSel(uicgr);
 end
return

function varargout = pbPPadsg_Callback(h, varargin)
 global P_figPar  % main figure handle
 global ComVarStr
 uicsgr=findobj('Tag','lstPPsgr','Parent',P_figPar);
 if all(strcmp(get(uicsgr,'String'),'-'))
     pbPPadgb_Callback;
     return
 else
     uicgr =findobj('Tag','lstPPgr', 'Parent',P_figPar);
     uicmod=findobj('Tag','lstPPmod','Parent',P_figPar);
     k0=get(uicgr,'Value');
     k=floor(k0/3);
     k1=rem(k0,3);
     if k1~=0
         k=k+1;
     end
     NM=get(uicmod,'Value');
     if isfield(ComVarStr,'MPind') && isfield(ComVarStr.MPind(k),'sec')
         NPSG=length(ComVarStr.MPind(k).sec);
     else
         NPSG=0;
     end
     if ~NPSG || ComVarStr.MPind(k).sec(NPSG)<NM
         ComVarStr.MPind(k).sec(NPSG+1)=NM+1;
         if NPSG>1
             ComVarStr.MPind(k).sec(NPSG)=ComVarStr.MPind(k).sec(NPSG)-1;
         end
     else
         for n=1:NPSG
             if ComVarStr.MPind(k).sec(n)<NM
                 continue;
             elseif ComVarStr.MPind(k).sec(n)==NM
                 set(uicsgr,'Value',n);
                 break;
             else
                 TeMp=ComVarStr.MPind(k).sec(n:NPSG);
                 ComVarStr.MPind(k).sec(n)=NM;
                 ComVarStr.MPind(k).sec((n+1):(NPSG+1))=TeMp;
                 set(uicsgr,'Value',n);
                 break;
             end
         end
     end
     listSel(uicsgr);
 end
return

function varargout = pbPPdlsg_Callback(h, varargin)
 global P_figPar  % main figure handle
 global ComVarStr
 uicsgr=findobj('Tag','lstPPsgr','Parent',P_figPar);
 if all(strcmp(get(uicsgr,'String'),'-'))
     return;
 else
     uicgr=findobj('Tag','lstPPgr','Parent',P_figPar);
     k0=get(uicgr,'Value');
     k=floor(k0/3);
     k1=rem(k0,3);
     if k1~=0
         k=k+1;
     end
     k2=get(uicsgr,'Value');
     ComVarStr.MPind(k).sec(k2)=[];
     if ~isfield(ComVarStr.MPind(k),'sec') || isempty(ComVarStr.MPind(k).sec)
         ComVarStr.MPind(k)=[];
     elseif ~isfield(ComVarStr,'MPind') || isempty(ComVarStr.MPind)
         ComVarStr=rmfield(ComVarStr,'MPind');
     elseif length(ComVarStr.MPind(k).sec)==1
         ComVarStr.MPind(k).sec=max(ComVarStr.MPind(k).sec-1,1);
     end
 end
 listSel(uicgr);
return

function tontof(ifoo)
 global P_figPar  % main figure handle
  set (findobj('Tag','lstPPmod','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','lstPPgr','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','lstPPsgr','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','txtPPmod','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','txtPPgr','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','txtPPsgr','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','pbPPadgb','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','pbPPdlgb','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','pbPPadsg','Parent',P_figPar), 'Visible',ifoo)
  set (findobj('Tag','pbPPdlsg','Parent',P_figPar), 'Visible',ifoo)
return

function varargout = Par_ResizeFcn(h, varargin)
 pofigPar = get(h,'Position');
 if ~isempty(find(pofigPar(3:4)<=0, 1))
    return;
 end
 set (findobj('Tag','RBpmod','Parent',h),           'Position',[pofigPar(3)*.15 pofigPar(4)*.95 pofigPar(3)*.15 pofigPar(4)*.03]);
 set (findobj('Tag','RBplsf','Parent',h),           'Position',[pofigPar(3)*.01 pofigPar(4)*.95 pofigPar(3)*.15 pofigPar(4)*.03]);
 set (findobj('Tag','RBpno','Parent',h),            'Position',[pofigPar(3)*.3 pofigPar(4)*.95 pofigPar(3)*.15 pofigPar(4)*.03]);
 set (findobj('Tag','txtPP','Parent',h),            'Position',[pofigPar(3)*.5 pofigPar(4)*.95 pofigPar(3)*.44 pofigPar(4)*.03]);
%
 set (findobj('Tag','lstPPmod','Parent',h),         'Position',[pofigPar(3)*.02 pofigPar(4)*.02 pofigPar(3)*.26 pofigPar(4)*.85]);
 set (findobj('Tag','lstPPgr','Parent',h),          'Position',[pofigPar(3)*.37 pofigPar(4)*.02 pofigPar(3)*.26 pofigPar(4)*.85]);
 set (findobj('Tag','lstPPsgr','Parent',h),         'Position',[pofigPar(3)*.72 pofigPar(4)*.02 pofigPar(3)*.26 pofigPar(4)*.85]);
 set (findobj('Tag','txtPPmod','Parent',h),         'Position',[pofigPar(3)*.02 pofigPar(4)*.88 pofigPar(3)*.26 pofigPar(4)*.03]);
 set (findobj('Tag','txtPPgr','Parent',h),          'Position',[pofigPar(3)*.37 pofigPar(4)*.88 pofigPar(3)*.26 pofigPar(4)*.03]);
 set (findobj('Tag','txtPPsgr','Parent',h),         'Position',[pofigPar(3)*.72 pofigPar(4)*.88 pofigPar(3)*.26 pofigPar(4)*.03]);
 set (findobj('Tag','pbPPadgb','Parent',h),         'Position',[pofigPar(3)*.285 pofigPar(4)*.5 pofigPar(3)*.08 pofigPar(4)*.08]);
 set (findobj('Tag','pbPPdlgb','Parent',h),         'Position',[pofigPar(3)*.285 pofigPar(4)*.35 pofigPar(3)*.08 pofigPar(4)*.08]);
 set (findobj('Tag','pbPPadsg','Parent',h),         'Position',[pofigPar(3)*.635 pofigPar(4)*.5 pofigPar(3)*.08 pofigPar(4)*.08]);
 set (findobj('Tag','pbPPdlsg','Parent',h),         'Position',[pofigPar(3)*.635 pofigPar(4)*.35 pofigPar(3)*.08 pofigPar(4)*.08]);
return
