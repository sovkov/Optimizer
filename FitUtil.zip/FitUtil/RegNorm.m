function RegNorm
% Computes the norm of the local solution vector.
% Implied to be used for the regularization procedures.
% All the input and output parameters are contained in the fields of the
% global structure ComVarStr.RegNorm.
%
%     INPUT
% ifzero  - if false or does not exist, then the norm is only computed of the variables with ComVarStr.ParStep~=0
%           if true, the norm is computed of all the variables of
%           ComVarStr.ParField
% y0      - zero point, if available; the norm is computed of the vector
%           Reny .* (y-y0), where y is the vector of the parameters, Reny
%           see below
% Reny    - a vector of the renormalization factors if available; the norm is computed of the vector
%           Reny .* (y-y0), where y is the vector of the parameters, y0 see
%           above
% lambda  - regularization parameter according to Tikhonov
%     OUTPUT
% RegNorm - resulting norm multiplied by the regularization factor:
%           sqrt(2*lambda)*\|Reny .* (y-y0)\|
%
global ComVarStr
ComVarStr.RegNorm.IERR = 0; % everything is OK
ComVarStr.locCov = 1;
if isfield(ComVarStr.RegNorm,'ifzero') && ~isempty(ComVarStr.RegNorm.ifzero) && ComVarStr.RegNorm.ifzero(1)
    y = getpara([],[],true);
else
    y = getpara([],[],false);
    ComVarStr.RegNorm.ifzero = false;
end
if isempty(y)
    ComVarStr.RegNorm.RegNorm = 0;
    ComVarStr.RegNorm.IERR = 1; % empty vector of the parameters
    return
end
if isfield(ComVarStr.RegNorm,'y0') && all(all(isreal(ComVarStr.RegNorm.y0))) && (all(size(ComVarStr.RegNorm.y0)==size(y)) || all(size(ComVarStr.RegNorm.y0)==1))
    y = y-ComVarStr.RegNorm.y0;
end
if isfield(ComVarStr.RegNorm,'Reny') && all(all(isreal(ComVarStr.RegNorm.Reny))) && (all(size(ComVarStr.RegNorm.Reny)==size(y)) || all(size(ComVarStr.RegNorm.Reny)==1))
    Reny = abs(ComVarStr.RegNorm.Reny);
else
    Reny = 1;
end
if isfield(ComVarStr.RegNorm,'lambda') && ~isempty(ComVarStr.RegNorm.lambda) && all(all(isreal(ComVarStr.RegNorm.lambda)))
    Reny = Reny * sqrt(2*abs(ComVarStr.RegNorm.lambda(1)));
end
ComVarStr.RegNorm.RegNorm = norm(y.*Reny);
% try to correct the local design matrix
try
    if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && ComVarStr.ifDer.ifDer(1)
        if ~isfield(ComVarStr,'Der1')
            ComVarStr.Der1 = [];
        end
        if all(size(Reny)==size(y))
            ComVarStr.Der1 = [ComVarStr.Der1 ; reshape(Reny,1,numelsize(Reny))];
        else
            ComVarStr.Der1 = [ComVarStr.Der1 ; Reny*ones(1,length(y))];
        end
    end
catch
    ComVarStr.Der1 = [];
    ComVarStr.ifDer.ifDer=false;
end
%
return