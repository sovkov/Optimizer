function [f,sigma2,Df,k0,S0,V0,U0] = GraDes (A,g,k,lambda,VPAlim)
% Gradient descent method (experimental)
%
% USAGE
% [f,sigma2,Df,k0,S0,V0,U0] = GraDes (A,g,k,lambda,VPAlim)
%       in a simplest case:
% f = MNK(A,g)
%       or any other combination of more input and output parameters
%
% Addresses the global structure ComVarStr
% INPUT     (any number of input variables between 2 and 4)
% A       - matrix of the equation to be solved
%           if A=[] at the input then the SVD decomposition of the matrix A computed at
%           the previous call of the routine is used for the computations
% g       - right-hand vector of the equation to be solved
% k       - not used, can be any input
% lambda  - the step length of the gradient descent in the units of the
%           1-st singular value
% VPAlim  - if exists and not equal 16, than a regime of computations with
%           a high precision is used. This case VPAlim significant digits
%           are traced.
%           REMARKS: (1) this regime slows down the computations.
%                    (2) this value only effects intermediate computations;
%                        all the results are returned as usual double
%                        precision MATLAB variables
%
% OUTPUT    (any number of output variables between 1 and 7)
% f       - the least-square solution of the equation;
%           the length of f is determined by the second dimension of the
%           matrix A or (in a case when input k is a matrix) by the minimum
%           of the second dimensions of A and k if they differ;
% sigma2  - estimate of the variance (sigma^2) of the right-hand values g
%            so, the estimate of the f covariance matrix can be
%            computed as sigma2*Df; standard deviations of the solution can
%            be computed as sqrt(sigma2*diag(Df)); the residual sum of
%            squares R0 = sigma2*(n-k0(1)) (see k0 below).
% Df      - covariance matrix of the solution f implying that the g values
%           standard deviation is indeed 1; otherwise the actual covariance
%           matrix can be computed by multiplying this one by the actual
%           standard deviation of g
% k0      - vector of two equal components k0(1)=k0(2) - the total number
%           of the nonzero singular values
% S0, V0, U0 - elements of the singular value decomposition
%                A(1:n,1:m) = U0(1:n,1:m) * [diag(S0(1:m))] * V0'(1:m,1:m)
%            so, S0 is a vector containing singular values
%
persistent S
persistent V
persistent U
try
    if ~isempty (A)
        n = size(A,1); % number of equations
        m = size(A,2); % number of unknown parameters
    else
        n = size(U,1);
        m = size(V,2);
    end
catch
    f=[];
    Df=[];
    sigma2=[];
    k0=[];
    S0=[];
    V0=[];
    U0=[];
    return
end
if nargin<5 || isempty(VPAlim) || ~isnumeric(VPAlim) || abs(round(VPAlim))==16
    VPAlim=16;
    ifVPA = false;
else
    ifVPA = true;
    DIGITS0=digits;
    digits(abs(round(VPAlim)));
end
%
% Singular Value Decomposition of the A matrix
%
if ~isempty(A)
    try
        if ~issparse(A)
            if ~ifVPA
                [U,S,V] = svd(A,0);
            else
                [U,S,V] = svd(vpa(A));
            end
        else
            if ~ifVPA
                [U,S,V] = svds(A,min(n,m));
            else
                [U,S,V] = svd(vpa(full(A)),0);
            end
        end
    catch
        beep;
        disp('SVD could not be completed. Your computer is probably out of memory.');
        disp('Try to use sparse format if it is not done yet;');
        disp('it can be turned on by the command ''global ComVarStr; ComVarStr.ifSparse=true;''');
        f=[];
        Df=[];
        sigma2=[];
        k0=[];
        S0=[];
        V0=[];
        U0=[];
        return;
    end
    S=diag(S);
end
mmp = find(S>0,1,'last');
k0(1:2)=mmp;
if S(1)==0 || nargin<4 || ~isnumeric(lambda) || isempty(lambda) || isnan(lambda) || isinf(lambda) || lambda==0 % erroneous singular values or no gradient descent is needed
    f=Inf*ones(m,1);
    Df=[];
    sigma2=[];
    S0=[];
    V0=[];
    U0=[];
    return
end
%
s1 = S(1:mmp)/(S(1)*lambda);
%
% compute the solution
%
f=zeros(m,1);
for i=1:mmp
    f0 = (U(1:n,i))'*g .* s1(i); % Gradient vecttor is -2*V*S*U'*g; we go in the direction of the opposite vector V*S*U'*g.
    f = f + f0 * V(1:m,i);
end
if (nargout>2)
    Df=zeros(m);
    for i=1:mmp
        Df = Df + V(1:m,i)*(V(1:m,i))' .* (s1(i).^2);
    end
end
%
% compute the residual sum of squares R0 and the standard deviation of the
% input data sigma2
%
if (nargout>1)
    if ~isempty(A)
        R0 = sum((A*f-g).^2);
    else
        R0=sum((U*diag(S)*V'*f-g).^2);
    end
    if (n ~= mmp)
        sigma2 = R0/(n-mmp);
    else
        sigma2 = 0;
    end
end
%
if nargout > 4
    S0 = S;
    if nargout > 5 
        V0 = V;
        if nargout > 6
            U0 = U;
        end
    end
end
%
if ifVPA
    switch nargout % [f,sigma2,Df,k0,S,V,U] = ...
        case 1
            f = double(f);
        case 2
            f = double(f);
            sigma2 = double(sigma2);
        case 3
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
        case 4 % k0 is already double
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
        case 5
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            S = double(S);
        case 6
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            S = double(S);
            V = double(V);
        otherwise
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            S = double(S);
            V = double(V);
            U = double(U);
    end
    digits(DIGITS0); % return to the initial value
end
%
return