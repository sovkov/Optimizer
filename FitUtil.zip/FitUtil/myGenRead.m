function [x,k0] = myGenRead(u,ifErl)
% Returns numeric content of a control (listbox, edit, or text) or an empty variable
%
% USAGE: [x,k0] = myGenRead(u,ifErl)
%
% INPUT
% u     - either a handle (numeric) or a Tag (character string) of a control;
% ifErl - logical variable determining how to treat the situation when one
%         of the listbox entries contain non-numeric data:
%         ifErl=true - the whole output x is empty
%         ifErl=false - elements of x corresponding to the problem entries
%                       of the listbox are empty so the length of the output x
%                       is less than the number of the listbox entries
%         if ifErl does not exist in the input it is treated as true;
%
% OUTPUT
% x     - numeric vector containing numeric contents of a control
%         or an empty variable if the control contents is not numeric;
%         if the control is the edit or text than it is implied to
%         contain one number, if it does not than the output is empty;
%         if the control is the listbox than it is implied to contain one
%         number in every entry, if it does not than the result is formed
%         according to the rules prescribed by the input variable ifErl;
% k0    - actual length of the output x.
%
x =[];
k0=0;
if nargin==0 return; end
%
try
    % find a handle of the object
    if ischar(u)
        try
            u0=findobj('Tag',u,'Parent',gcf);
            if isempty(u0)
                u0=findobj('Tag',u);
                u0 = u0(1);
            end
        catch
            u0=findobj('Tag',u);
            u0 = u0(1);
        end
    else
        u0=u;
    end
    %
    % find out if the object the "edit" or "listbox" style
    uStyle=get(u0,'Style');
    %
    if strcmp(uStyle,'edit') || strcmp(uStyle,'text')
        try
            x = str2num( strtrim(get(u0,'String')) );
        catch
            x=[];
        end
    elseif strcmp(uStyle,'listbox')
        if nargin<2 || isempty(ifErl)
            ifErl0=true;
        else
            ifErl0=ifErl(1);
        end
        ifErl00=false; % to be changed to true if an error occurs during conversion of a current cell into a numeric form
        x0=get(u0,'String');
        k = size(x0,1);
        x = zeros(k,1);
        i0=1;
        for i=1:k
            try
               x1=str2num( strtrim(x0(i,:)) ); 
               if any(size(x1)~=1)
                   ifErl00=true;
                   if ifErl00
                       break;
                   else
                       continue;
                   end
               end
               x(i0)=x1;
               i0=i0+1;
            catch
                x=[];
            end
        end
        if ifErl0 && ifErl00
            x=[];
        elseif i0<=k
            x(i0:k)=[];
        end
    end
    k0=size(x);
    if any(k0==1)
        k0 = max(k0);
    end
catch
end
return