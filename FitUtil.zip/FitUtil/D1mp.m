function [Der,Rmi,yp,PSm,PS,ierr]=D1mp(j1,lp,R0,R01,CVS,y,CN)
% Computes the first derivatives of the multidimentional function with respect to its j-th argument
%
% USAGE: [Der,Rmi,yp,PSm,PS,ierr]=D1mp(j1,lp,R0,R01,CVS,y,CN)
%
%     INPUT
% j1   - argument number;
% lp   - number of parameters
% R0   - initial value of the evaluation function;
% R01  - either the same as R0 or a flag for switching regimes;
% CVD  - a current replica of ComVarStr, needed if the ComVarStr itself is
%        empty.
% y  - if exists, contains the 0-th approximation results and works as aflag that the fast 1-step differentiation is performed;
%      if does not exist or empty, then more accurate 2-step
%      differentiation is performed.
% CN - cells with varied parameters to be diplayed if needed
%     OUTPUT
% Der  - derivatives vector;
% Rmi  - the less one between the evaluation function values at the
%        negative and positive step points;
% yp   - results vector at the step point corresponding to Rm;
% PSm  - the step of the j1-th variable corresponding to Rm;
% PS   - the step of the j1-th variable for the next call.
% ierr - error flag:
%         =0   everything is OK
%         >0   non-critical error flag of the last call of the procedure for computing
%              function values; the computations are proceeded
%         =100 no ierr flag is produced by the procedure for computing the
%             function to be diffirentiated; the computations are done
%         <0   something was wrong; the computations are seized
global ComVarStr
try
    if nargin>4 && ~isempty(CVS)
        if isempty(ComVarStr)
            ComVarStr=CVS;
        end
%        CVS=[];
    end
    if nargin<6 || isempty(y) || ~isnumeric(y)
        if1Step=false;
    else
        if1Step=true;
    end
    [k,i,i0,l0]=paracount(j1);
    nPS = num2str(numel(find(ComVarStr.ParStep~=0))); % number of varied parameters
    ifDisp = ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1); % if the current state of the program to be displayed in the Matlab command window
    ifStAd = ~isfield(ComVarStr,'ifStAd') || isempty(ComVarStr.ifStAd) || ComVarStr.ifStAd(1); % should we adapt or not differentiation steps?
    if ifDisp && (nargin<7 || isempty(CN) || ~iscell(CN))
        if nargin>7 && ischar(CN)
            CN = {CN};
        else
            [CN,~,~]=Optimizer('getOpVal');        % get the parameter names in the original order
        end
    end
    if nargin>2 && ~isempty(lp) && isreal(lp) && lp>0
        Der=zeros(round(lp),1);
    else
        Der=[];
    end
    ierr=0;
    Nm = getProNm(k);
    if iscell(ComVarStr.ParField{k})
        x0 = ComVarStr.(Nm).(ComVarStr.ParField{k}{i});
%            x0 = getfield(ComVarStr,Nm,ComVarStr.ParField{k}{i});
    else
        x0 = ComVarStr.(Nm).(ComVarStr.ParField{k});
%            x0 = getfield(ComVarStr,Nm,ComVarStr.ParField{k});
    end
    kx = size(x0,1);
    iy=ceil(l0/kx);
    ix=rem(l0,kx);
    if ix==0
        ix=kx;
    end
    ierr0 = -1;
    x = x0;
    while ierr0 <0
%
% positive step
%
        x(ix,iy) = x0(ix,iy) + ComVarStr.ParStep(i0);
        if iscell(ComVarStr.ParField{k})
            ComVarStr.(Nm).(ComVarStr.ParField{k}{i}) = x; % increase i-th parameter
%                ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x); % increase i-th parameter
        else
            ComVarStr.(Nm).(ComVarStr.ParField{k})=x; % increase i-th parameter
%                ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x); % increase i-th parameter
        end
            [ierr0,yp]=funval(true);
%             if ierr0 >0
%                 ierr = -ierr0;
%                 break;
%             elseif ierr0<0 || isempty (yp) || any(any(~isreal (yp))) || any(any(isinf(yp))) || any(any(isnan(yp)))
        if ierr0<0 || isempty (yp) || any(any(~isreal (yp))) || any(any(isinf(yp))) || any(any(isnan(yp)))
            ierr0 = -1; % wrong result
            ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
            continue;
        end
%
% negative step
%
        if ~if1Step
            x(ix,iy) = x0(ix,iy) - ComVarStr.ParStep(i0);
            if iscell(ComVarStr.ParField{k})
                ComVarStr.(Nm).(ComVarStr.ParField{k}{i})=x; % decrease i-th parameter
%                    ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x); % decrease i-th parameter
            else
                ComVarStr.(Nm).(ComVarStr.ParField{k})=x; % decrease i-th parameter
%                    ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x); % decrease i-th parameter
            end
            % try
            %     [ierr0,ym]=funval0; % works if all the procedures are in the matlab path or in the current directory
            % catch
                [ierr0,ym]=funval(true);
            % end
            if ierr0 < 0 || isempty (ym) || any(any(~isreal (ym))) || any(any(isinf(ym))) || any(any(isnan(ym)))
                ierr0 = -1; % wrong result
                ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
                continue;
            end
        end
    end
    if iscell(ComVarStr.ParField{k})
        ComVarStr.(Nm).(ComVarStr.ParField{k}{i})=x0; % return to the initial value
%            ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x0); % return to the initial value
    else
        ComVarStr.(Nm).(ComVarStr.ParField{k})=x0; % return to the initial value
%            ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x0); % return to the initial value
    end
    try
        if ~if1Step
            Der = (yp(:)-ym(:))/2/ComVarStr.ParStep(i0); % compute the derivatives
            if R01>0 || ~isempty(R0) % && R0>0 % adapt a current step if it is too small or too big or adopt the coordinate-wise minimum
                try
                    if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
                        Rm = resi(ym,ComVarStr.input,ComVarStr.inpCov);
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCov);
                    elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
                        Rm = resi(ym,ComVarStr.input,ComVarStr.inpCovar);
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                    else
                        Rm = resi(ym,ComVarStr.input);
                        Rp = resi(yp,ComVarStr.input);
                    end
                catch
                    try
                        Rm = resi(ym,ComVarStr.input,ComVarStr.inpCovar);
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                    catch
                        Rm = resi(ym,ComVarStr.input);
                        Rp = resi(yp,ComVarStr.input);
                    end
                end
                % which one is less?
                if Rp<Rm
                    Rmi=Rp;
                    PSm=ComVarStr.ParStep(i0);
                else
                    Rmi=Rm;
                    yp=ym;
                    PSm=-ComVarStr.ParStep(i0);
                end
                if ifDisp
                    try
                        if isempty(R0)
                            disp(strcat('D1mp: Rneg=',num2str(Rm),', Rpos=',num2str(Rp),'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                        else
                            if Rm-R0>0
                                sm=strcat(num2str(Rm),' (+',num2str(Rm-R0),')');
                            else
                                sm=strcat(num2str(Rm),' (',num2str(Rm-R0),')');
                            end
                            if Rp-R0>0
                                sp=strcat(num2str(Rp),' (+',num2str(Rp-R0),')');
                            else
                                sp=strcat(num2str(Rp),' (',num2str(Rp-R0),')');
                            end
                            disp(strcat('D1mp: Rneg=',sm,', Rpos=',sp,'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                        end
                    catch
                        disp(strcat('D1mp: Rneg=',num2str(Rm),', Rpos=',num2str(Rp),'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                    end
%                        disp('--------------------------------------------------');
                end
                % ADAPTATION OF THE PARAMETER STEPS if needed
                if ifStAd && ~isempty(R0)
                    Rmax = max(abs((Rp-R0))/R0,abs((Rm-R0))/R0);
                    Rmin = min(abs((Rp-R0))/R0,abs((Rm-R0))/R0);
                    if Rp>R0 && Rm>R0 && (Rmax>10 || Rmin<1e-8)
                        if Rmax>10
                            if Rm<Rp
                                ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
                            else
                                ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/5;
                            end
                        elseif Rmin<1.0E-8
                            if Rm<Rp
                                ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*3;
                            else
                                ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                            end
                        end
                    elseif Rmin<1.0E-8
                        if Rm<Rp
                            ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*3;
                        else
                            ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                        end
                    elseif Rp<=R0 && Rm<=R0
                        if Rm<Rp
                            ComVarStr.ParStep(i0)=-ComVarStr.ParStep(i0)*2.1;
                        else
                            ComVarStr.ParStep(i0)=ComVarStr.ParStep(i0)*2.1;
                        end
                    else
                        [ifmin,st,yst]=locParExtr(-ComVarStr.ParStep(i0),0,ComVarStr.ParStep(i0),Rm,R0,Rp);
                        rt=abs(st/ComVarStr.ParStep(i0));
                        if ifmin && rt<10 && rt>0.01 && abs((yst-R0)/R0)>1e-8
                            if Rm>=R0 && Rp>=R0 || st>ComVarStr.ParStep(i0)
                                ComVarStr.ParStep(i0)=st;
                            else
                                if Rm<Rp
                                    ComVarStr.ParStep(i0)=-ComVarStr.ParStep(i0)*1.3;
                                else
                                    ComVarStr.ParStep(i0)=ComVarStr.ParStep(i0)*1.3;
                                end
                            end
                        else
                            if Rp>=R0 && Rm>=R0
                                if Rm<Rp
                                    ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/2;
                                else
                                    ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/2;
                                end
                            else
                                if Rm<Rp
                                    ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*1.5;
                                else
                                    ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*1.5;
                                end
                            end
                        end
                    end
                end
            end
        else
            Der = (yp(:)-y(:))/ComVarStr.ParStep(i0); % compute the derivatives
            if R01>0 || ~isempty(R0) % && R0>0 % adapt a current step if it is too small or too big or adopt the coordinate-wise minimum
                try
                    if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCov);
                    elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                    else
                        Rp = resi(yp,ComVarStr.input);
                    end
                catch
                    try
                        Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                    catch
                        Rp = resi(yp,ComVarStr.input);
                    end
                end
                % which one is less?
                Rmi=Rp;
                PSm=ComVarStr.ParStep(i0);
                if ifDisp
                    try
                        if isempty(R0)
                            disp(strcat('D1mp: R=',num2str(Rp),'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                        else
                            if Rp-R0>0
                                sp=strcat(num2str(Rp),' (+',num2str(Rp-R0),')');
                            else
                                sp=strcat(num2str(Rp),' (',num2str(Rp-R0),')');
                            end
                            disp(strcat('D1mp: R=',sp,'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                        end
                    catch
                        disp(strcat('D1mp: R=',num2str(Rp),'     [',num2str(j1),'/',nPS,'--',CN{j1},']'));
                    end
%                        disp('--------------------------------------------------');
                end
                % ADAPTATION OF THE PARAMETER STEPS if needed
                if ifStAd && ~isempty(R0)
                    Rmax = abs((Rp-R0))/R0;
                    Rmin = abs((Rp-R0))/R0;
                    if Rp>R0 && (Rmax>10 || Rmin<1e-8)
                        if Rmax>10
                            ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/5;
                        elseif Rmin<1.0E-8
                            ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                        end
                    elseif Rmin<1.0E-8
                        ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                    elseif Rp>R0
                        ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/2;
                    else
                        ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*1.5;
                    end
                end
%%%%%%%%%%%%                
            end
        end
    catch
        ierr=-i0; % something is wrong with the i0-th parameter
    end
    PS=ComVarStr.ParStep(i0);
%    clear global ComVarStr
catch mectc
    ierr=-i0; % something is wrong with the i0-th parameter
    if isfield(ComVarStr,'ifDisp') && ComVarStr.ifDisp
        beep;
        disp('D1mp ERROR');
        disp(mectc.message);
%         mectc.stack
%         disp('file:');
%         mectc.stack.file
%         disp('line:');
%         mectc.stack.line
% %        mectc.cause
        beep;
    end
end
return