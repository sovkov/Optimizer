function [y,nn,nnn]=getpara (k0,n0,ifzero,ifCount)
% Puts the contents of all the "variable" parameters fields into a column vector y up to n0-th parameter of the k0-th procedure;
%
% USAGE: [y,nn,nnn]=getpara (k0,n0,ifzero,ifCount) or y=getpara (k0,n0), etc.
%
% default k0=total number of procedures, n0=total number of the parameters belonging to the k0-th procedure.
% nn - total number of the parameters y up to n0-th parameter of the k0-th
%      (=nnn if ifzero=false, otherwise it is<=nnn);
% nnn - total number of the parameters independent of if their ComVarStr.ParStep=0 or not up to n0-th parameter of the k0-th
% procedure
% ifzero  - if false, then y contains only the variables with ComVarStr.ParStep~=0,
%           and nn is their number
%           if true or does not exist, y contains all the variables
%           and nn is their number
% ifCount - if true, output y is empty so that only nn and nnn are provided;
%           if false or does not exist, both y and nn are provided.
%
% If input parameters are absent or empty, the entire set is considered.
% Uses global structure ComVarStr.
global ComVarStr;
try
    y=[];
    nn=0;
    nnn=0;
    if nargin==0 || isempty(k0) || ~isnumeric(k0) || k0<0 || k0>length(ComVarStr.Proc)
        k0=length(ComVarStr.Proc);
    elseif k0==0
        return
    end
    if nargin<=1 || isempty(n0) || ~isnumeric(n0) || n0<0 || n0>length(ComVarStr.Proc(k0).Par)
        n0=length(ComVarStr.Proc(k0).Par);
    end
    if nargin<3 || isempty(ifzero)
        ifzero = true;
    end
    if nargin<4 || isempty(ifCount)
        ifCount = false;
    end
    ParField=ComVarStr.ParField; % the name of the ComVarStr structure field containing the main procedure resulting values
    for k=1:k0
        if iscell(ParField{k})
            if k==k0 && nargin>=2 && ~isempty(n0) && all(isnumeric(n0)) && n0>=0
                n1=n0;
            else
                n1=length(ParField{k});
            end
            if n1==0
                continue;
            end
            y1 = [];
            fn = getProNm(k);
            for n=1:n1
                try
                    if ifCount
                        nnn = nnn + numel(ComVarStr.(fn).(ParField{k}{n}));
%                        nnn = nnn + numel(getfield (ComVarStr,fn,ParField{k}{n}));
                    else
                        y0 = ComVarStr.(fn).(ParField{k}{n});
%                        y0 = getfield (ComVarStr,fn,ParField{k}{n});
                        y0=reshape(y0,numel(y0),1);
                        y1 = [y1;y0];
                    end
                catch
                    continue;
                end
            end
        else
            try
                fn = getProNm(k);
                if ifCount
                    nnn = nnn + numel(ComVarStr.(fn).(ParField{k}));
%                    nnn = nnn + numel(getfield (ComVarStr,fn,ParField{k}));
                else
                    y1 = ComVarStr.(fn).(ParField{k});
%                    y1 = getfield (ComVarStr,fn,ParField{k});
                end
            catch
                continue;
            end
            y1=reshape(y1,numel(y1),1);
        end
        y = [y;y1];
    end
    if ~ifCount
        nnn = length(y);
    end
    if ~ifzero 
        if isfield(ComVarStr,'ParStep') && all(isreal(ComVarStr.ParStep)) && length(ComVarStr.ParStep)>=nnn
            i = find(ComVarStr.ParStep(1:nnn)==0);
            nn=nnn-length(i);
            if ~ifCount && ~isempty(i)
                y(i)=[];
            end
        end
    else
        nn=nnn;
    end
catch
    y=[];
end
return