function [fnShrt,extName,pthName,fnameCorrect] = ShrtName(fname,ifCorrect)
% Produces and (ifCorrect) corrects the short name, extension name, and path name from the full name of a block
% USAGE: % [fnShrt,extName,pthName,fnameCorrect] = ShrtName(fname,ifCorrect)
% or ShrtName(fname)
     if nargin<2 || isempty(ifCorrect)
         ifCorrect=false;
     end
     if nargin==0 || isempty(fname) || ~ischar(fname)
         fnShrt=[];
         extName=[];
         pthName=[];
         fnameCorrect=[];
         return
     end
     fname=strtrim(fname);
     fnmK1 = strfind(fname,'\');
     if isempty(fnmK1)
         fnmK = 0;
         pSmb='';
     else
         fnmK = fnmK1(end);
         pSmb='\';
     end
     if ifCorrect
         fnmK1 = strfind(fname,'/'); % possible misprint of '\'; correct it
         if ~isempty(fnmK1) && fnmK1(end)>fnmK
             fname(fnmK1)='\';
             fnmK = fnmK1(end);
         end
     end
     fnmK2 = strfind(fname,':');
     if ~isempty(fnmK2)
         fnmK2 = fnmK2(end);
         if fnmK2(end)>fnmK
             fnmK = fnmK1(end);
             pSmb=':';
         end
     else
         fnmK2 = 0;
     end
     fnmK1 = strfind(fname,'.');
     if ~isempty(fnmK1) && fnmK1(end)>fnmK
         fnmK1=fnmK1(end);
     else
         fnmK1=length(fname)+1;
     end
     fnShrt=fname(fnmK+1:fnmK1-1);
     %
     kN = length(fnShrt);
     if ifCorrect
         if kN
             for i=kN:-1:1
                 if ~isletter(fnShrt(i)) && ~(fnShrt(i)>='0' && fnShrt(i)<='9') && fnShrt(i)~='_' && fnShrt(i)~='-'
                     fnShrt(i)=[];
                 end
             end
         end
         while ~isempty(fnShrt) && ~isletter(fnShrt(1))
             fnShrt(1)=[];
         end
%         kN=length(fnShrt);
     end
     %
     if nargout>1
         if fnmK1<length(fname)
             extName=fname(fnmK1+1:end);
         else
             extName='';
         end
         ke = length(extName);
         if ifCorrect
             if ke>0
                 for i=ke:-1:1
                     if ~isletter(extName(i)) && ~(extName(i)>='0' && extName(i)<='9' && i~=1) && i~=1
                         extName(i)=[];
                     end
                 end
             end
             ke = length(extName);
         end
         if nargout>2
             if fnmK>1
                 pthName=fname(1:fnmK-1);
             else
                 pthName='';
             end
             kp = length(pthName);
             if ifCorrect
                 if kp>0
                     for i=kp:-1:1
                         if ~isletter(pthName(i)) && ~(pthName(i)>='0' && pthName(i)<='9') && pthName(i)~='.' && pthName(i)~='\' && pthName(i)~='_' && pthName(i)~='-' && ~strcmp(pthName(i),':') && (~strcmp(pthName(i),' ') || i<fnmK2)
                             pthName(i)=[];
                         end
                     end
                 end
                 kp = length(pthName);
             end
             if nargout>3
                 fnameCorrect = fnShrt;
                 if ke>0
                     fnameCorrect = strcat(fnameCorrect,'.',extName);
                 end
                 if kp>0
                     fnameCorrect = strcat(pthName,pSmb,fnameCorrect);
                 end
             end
         end
     end
return