function [sd,Df1] = sdCompute(Df,sigma2)
% Computes covariance matrix Df1 and standard deviations sd of the output model data
% from the covariance matrix Df of the model parameters. If there is input sigma2,
% the covariance matrix Df is multiplied by sigma2 before computations.
%
% USAGE: [sd,Df1] = sdCompute(Df,sigma2)
%
% The function implies that the model has been already constructed and its
% output and input parameters declaired, e.g., with the help of the Modeler
% program. The derivatives are computed by the Deriv1 function using the
% finite-differences algorithm, hence, the values of the parameter steps
% can be significant.
[ierr,Der] = Deriv1;
Df1 = Der * Df * Der';
if nargin>1 && ~isempty(sigma2) && isreal(sigma2)
    Df1 = Df1*sigma2;
end
sd = sqrt(diag(Df1));
return