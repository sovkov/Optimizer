function varargout = Modeler(varargin)
% The main tool for the models construction, tuning, and execution.
% For a help info launch the command FitHelp.

global M_figMod  % main figure handle
global ComVarStr

if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp)
    ComVarStr.ifDisp=true; % can be turned off in the command window
elseif ~isscalar(ComVarStr.ifDisp)
    ComVarStr.ifDisp=ComVarStr.ifDisp(1);
end

if (nargin==0)
    if ~isempty(M_figMod)
        figure (M_figMod);
        return
    end
    %
    ModStart;
	set(M_figMod,'Color',get(0,'defaultUicontrolBackgroundColor'));
    %
    C=what;
    C=C.path;
    ComVarStr.IniPath = C;
    clear C;
    if isfield(ComVarStr,'Proc') && isfield(ComVarStr.Proc,'Name')
        C(1)={'-'};
        if isfield (ComVarStr,'ProcN') % current number of the procedure
            N = ComVarStr.ProcN;
            if isempty(N) || any(any(~isreal(N))) || N<=0
                N = 0;
            end
        else
            N = 0;
        end
        try
            N0 = length(ComVarStr.Proc);
            if N0>0
                for i=1:N0
                    if iscell(ComVarStr.Proc(i).Name)
                        C(i+1,1) = ComVarStr.Proc(i).Name;
                    else
                        C(i+1,1) = {ComVarStr.Proc(i).Name};
                    end
                end
            else
                N = 0;
            end
        catch
            N = 0;
        end
        set(findobj('Tag','popPron','Parent',M_figMod),'String',C);
        set(findobj('Tag','popPron','Parent',M_figMod),'Value',N+1);
        if N>0
            popPron_Callback;
        end
    else
        if ~isfield(ComVarStr,'Proc')
            ComVarStr.Proc=[];
        end
        set(findobj('Tag','popPron','Parent',M_figMod),'String',{'-'});
        set(findobj('Tag','popPron','Parent',M_figMod),'Value',1);
        N0 = 0;
    end
    for i=1:N0
        try
            if ComVarStr.Proc(i).ifExec
                set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
                break;
            end
        catch
            break;
        end
    end
else
    try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
        refrDetail;
        set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on','String','Run All'); % turn off the "Run All" button
        set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on','String','Run'); % turn off the "Run" button
		disp(lasterr);
        button = errordlg(lasterr,'Path or procedure name error');
    end
end
return

function varargout = Mod_CloseRequestFcn(h,varargin)
 clearglMod;
 delete (gcbf);
return

function varargout = Mod_DeleteFcn(h,varargin)
 clearglMod;
return

function pbPronBro_Callback
%
% Browses for a new procedure
 global M_figMod  % main figure handle
 persistent pname;
 if isempty(pname) || ~ischar(pname)
     global ComVarStr;
     try
         pname=strcat(ComVarStr.IniPath);
         if ~strcmp(pname(end),'\')
             pname = strcat(pname,'\');
         end
     catch
         pname='';
     end
 end
% [fname,pname] = uigetfile({strcat(pname,'*.m');strcat(pname,'*.exe')},'Find the procedure');
 [fname,pname] = uigetfile('*.m','Find the procedure',strcat(pname,'*.m'));
 if ischar(fname) && ischar(pname)
    global ComVarStr
    try
        pname = relpath(pname,ComVarStr.IniPath); % modify the full path to the relative path
    catch
    end
    fname=strcat(pname,fname);
    set(findobj('Tag','edPron','Parent',M_figMod),'String',fname);
end
return

function edPron_Callback
 global M_figMod  % main figure handle
 fname = get (findobj('Tag','edPron','Parent',M_figMod),'String');
 fname=deblank(fname);
 if ~isempty(fname)
     [fnameShrt,fnameExt,pname,fname]=ShrtName(fname,true);
 end
 if isempty(fname)
     fname='-';
 end
 set (findobj('Tag','edPron','Parent',M_figMod),'String',fname);
return

function pbPronAd_Callback
% Adds a procedure to the list
 global M_figMod  % main figure handle
 global ComVarStr
 fname = get (findobj('Tag','edPron','Parent',M_figMod),'String');
 if strcmp(fname,'-')
     return
 elseif isempty(fname)
     set (findobj('Tag','edPron','Parent',M_figMod),'String','-');
     return
 end
 set (findobj('Tag','edPron','Parent',M_figMod),'String','-');
 try
  ComVarStr.ifChange=true; % the model has been changed
  if isfield(ComVarStr,'Proc') && numel(ComVarStr.Proc)>0 && isfield(ComVarStr.Proc(1),'Name') && ~isempty(ComVarStr.Proc(1).Name)
    N = getNM;
    N0=length(ComVarStr.Proc);
    if N<N0
        ComVarStr.Proc(N+2:N0+1) = ComVarStr.Proc(N+1:N0);
        for i=N0:-1:N+1
            try
                ComVarStr.ParField{i+1} = ComVarStr.ParField{i};
            catch
            end
        end
        for i=N0:-1:N+1
            try
                ComVarStr.ResField{i+1} = ComVarStr.ResField{i};
            catch
            end
        end
        if isfield(ComVarStr,'Parkeep') && ~isempty(ComVarStr.Parkeep)
            try
                NNP=length(ComVarStr.Parkeep);
                for i=NNP:-1:N+1
                    ComVarStr.Parkeep{i+1} = ComVarStr.Parkeep{i};
                end
%                ComVarStr.Parkeep{N+1}={[]};
            catch
            end
        end
    end
  else
    N=0;
    N0=0;
  end
 catch
  N=0;
  N0=0;
 end
 %
 % set the new field contents
 try
     ComVarStr.ParField{N+1} = []; % contents of the cell is put to [], the cell is not removed!
 catch
 end
 try
     ComVarStr.ResField{N+1} = []; % contents of the cell is put to [], the cell is not removed!
 catch
 end
 try % attempt to read the procedure data from the MOP file
     fn1 = fname;
     k = max(strfind(fn1,'.'));
     if ~isempty(k)
         fn1(k:length(fn1)) = [];
     end
     fn2 = strcat(fn1,'.MOP');
     if ~strcmp(fn1,'Aux') && ~strcmp(fn1,'aux') && ~strcmp(fn1,'AUX')
      %
      load(fn2,'-mat');
      if ~strcmp(Proc.Name,fname)
          Proc.Name = fname;
          try
              save(fn2,'-mat','Proc','ParVal');
          catch
              save(fn2,'-mat','Proc');
          end
      end
      %
%         try
%           feval(@load,'-MAT',fn2);
%           if ~strcmp(Proc.Name,fname)
%               Proc.Name = fname;
%               try
%                   feval(@save,'-MAT',fn2,'Proc','ParVal');
%               catch
%                   feval(@save,'-MAT',fn2,'Proc');
%               end
%           end
%         catch % for Octave
%           feval(@load,fn2);
%           if ~strcmp(Proc.Name,fname)
%               Proc.Name = fname;
%               try
%                   feval(@save,fn2,'Proc','ParVal');
%               catch
%                   feval(@save,fn2,'Proc');
%               end
%           end
%         end
     end
     ComVarStr.Proc(N+1).Name = fname;
     ComVarStr.Proc(N+1).Descr = Proc.Descr;
     ComVarStr.Proc(N+1).Par = Proc.Par;
     ComVarStr.Proc(N+1).ifExec = Proc.ifExec;
     k = max(strfind(fn1,'\'));
     if ~isempty(k)
         fn1(1:k) = [];
     end
     try
        ComVarStr.(fn1)=ParVal;
%        ComVarStr = setfield(ComVarStr,fn1,ParVal);
     catch
     end
     clear Proc;
     clear fn1;
     clear fn2;
 catch % if the MOP file is incorrect, attempt to set default data
     ComVarStr.Proc(N+1).Name={fname};
     try
        ComVarStr.Proc(N+1).Par = [];
    catch
    end
    try
        ComVarStr.Proc(N+1).Descr = [];
    catch
    end
    try
        ComVarStr.Proc(N+1).ifExec=true;
    catch
    end
 end
 %
 N0=N0+1;
 C={'-'};
 for i=1:N0
     try
        C(i+1,1)=ComVarStr.Proc(i).Name;
    catch
        C(i+1,1)={ComVarStr.Proc(i).Name};
    end
 end
 set (findobj('Tag','popPron','Parent',M_figMod),'String',C);
 set (findobj('Tag','popPron','Parent',M_figMod),'Value',N+2);
 findModName(true,N+1); % attempt to find the procedure parameters in the workspace
 popPron_Callback;
 set( findobj ('Tag','ckbExeProMod','Parent',M_figMod) ,'Value', get ( findobj('Tag','ckbProModGet','Parent',M_figMod),'Max' ) );
 set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on'); % turn on the "Run" button
 set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
 if isfield(ComVarStr,'MPind')
     for i=1:length(ComVarStr.MPind)
         if isfield(ComVarStr.MPind(i),'sec') && ~isempty(ComVarStr.MPind(i).sec) && isreal(ComVarStr.MPind(i).sec)
             k=find(ComVarStr.MPind(i).sec>N);
             if ~isempty(k)
                 ComVarStr.MPind(i).sec(k)=ComVarStr.MPind(i).sec(k)+1;
             end
         end
     end
     refrParaPlan; % refreshes ParaPlan window if needed
end
fn1 = ShrtName(fname); % short version of the name
if ~isempty(fn1) && ~isfield(ComVarStr,fn1)
    ComVarStr.(fn1)=[];
%    ComVarStr=setfield(ComVarStr,fn1,[]);
end
% ComVarStr.ModName='Modeler';
% if ishandle(M_figMod)
%     set(M_figMod,'Name',ComVarStr.ModName);
% end
return

function pbPronDel_Callback(NN)
%
% Deletes a procedure from the list
 global M_figMod  % main figure handle
 global ComVarStr
% fnm = get (findobj('Tag','popPron','Parent',M_figMod),'String');
 if nargin==0 || isempty(NN) || ~all(all(isreal(NN))) || (size(NN,1)~=1 && size(NN,2)~=1)
    NN = get (findobj('Tag','popPron','Parent',M_figMod),'Value')-1;
    NK=1;
 else
     try
        NN = round(sort(NN));
        fnmK = length(ComVarStr.Proc);
        K = find(NN>fnmK);
        if ~isempty(K)
            NN(K)=[];
        end
        NK = length(NN);
        if NK>1
            while true
                K = find(NN(1:NK-1)==NN(2:NK));
                if isempty(K)
                    break;
                end
                NN(K)=[];
            end
        end
        NK = length(NN);
     catch
        NN = get (findobj('Tag','popPron','Parent',M_figMod),'Value')-1;
        NK=1;
     end
 end
 for K=NK:-1:1
     N = NN(K);
     if N<1
         continue;
     end
     if iscell(ComVarStr.Proc(N).Name)
        fname = ComVarStr.Proc(N).Name{1};
     else
        fname = ComVarStr.Proc(N).Name;
     end
    fnameShrt = ShrtName(fname); % short version of the name
     %
     if ~(isfield(ComVarStr,'Proc') && N<=length(ComVarStr.Proc) && N>0)
         if ~isempty(M_figMod)
             set (findobj('Tag','edPron','Parent',M_figMod),'String','-');
         end
         return
     end
     ComVarStr.ifChange=true; % the model has been changed
     pbProFitDel_Callback(N); % to clear all the input variables fields
     ComVarStr.Proc(N)=[];
     try
         ComVarStr.ParField(N)=[]; % removes the cell from the array
     catch
     end
     try
        if isfield(ComVarStr,'Parkeep') && ~isempty(ComVarStr.Parkeep)
            ComVarStr.Parkeep(N)=[]; % removes the cell from the array
        end
     catch
     end
     try
         ComVarStr.ResField(N)=[]; % removes the cell from the array
     catch
     end
     try
         if0 = true; % remains true if no other instances of this routine remains
         N0 = length(ComVarStr.Proc);
         if N0>0
            for i=1:length(ComVarStr.Proc)
                if iscell(ComVarStr.Proc(i).Name)
                    Snm = ShrtName(ComVarStr.Proc(i).Name{1});
                else
                    Snm = ShrtName(ComVarStr.Proc(i).Name);
                end
                if isempty(Snm)
                    ComVarStr.Proc(i:end)=[];
                    break;
                end
                if strcmp(Snm,fnameShrt)
                    if0 = false;
                    break;
                end
            end
         end
         if if0
%            fnameShrt = getProName;
            if isfield(ComVarStr,fnameShrt)
                ComVarStr = rmfield(ComVarStr,fnameShrt); % removes the variable field
            end
         end
     catch
     end
     %
     N0=length(ComVarStr.Proc);
     C={'-'};
     for i=1:N0
        C0 = ComVarStr.Proc(i).Name;
        if isempty(C0) || (iscell(C0) && isempty(C0{1}))
            N0=i-1;
            break;
        end
        try
            C(i+1,1)=C0;
        catch
            C(i+1,1)={C0};
        end
     end
     if ~isempty(M_figMod)
         set (findobj('Tag','edPron','Parent',M_figMod),'String',fname);
         set (findobj('Tag','popPron','Parent',M_figMod),'Value',max(min(N,N0+1),1));
         set (findobj('Tag','popPron','Parent',M_figMod),'String',C);
         popPron_Callback;
     end
 end
 if isfield(ComVarStr,'MPind')
     for i=1:length(ComVarStr.MPind)
         if isfield(ComVarStr.MPind(i),'sec') && ~isempty(ComVarStr.MPind(i).sec) && isreal(ComVarStr.MPind(i).sec)
             k=find(ComVarStr.MPind(i).sec>N);
             if ~isempty(k)
                 ComVarStr.MPind(i).sec(k)=ComVarStr.MPind(i).sec(k)-1;
             end
             k=find(ComVarStr.MPind(i).sec>N0);
             if length(k)>1
                 ComVarStr.MPind(i).sec(k(2:end))=[];
             end
         end
     end
     refrParaPlan; % refreshes ParaPlan window if needed
 end
% ComVarStr.ModName='Modeler';
% if ishandle(M_figMod)
%     set(M_figMod,'Name',ComVarStr.ModName);
% end
return

function ckbExeProMod_Callback
try
    global M_figMod  % main figure handle
    N = getNM;
    uic = findobj ('Tag','ckbExeProMod','Parent',M_figMod);
    if N==0
        set (uic,'Value',get(uic,'Min'));
        return
    end
    global ComVarStr;
    ck    = get (uic,'Value');
    ckmax = get (uic,'Max');
    if ck==ckmax
        ComVarStr.Proc(N).ifExec=true;
        set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on'); % turn on the "Run" button
        set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
    else
        ComVarStr.Proc(N).ifExec=false;
        set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','off'); % turn off the "Run" button
        set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','off'); % turn off the "Run All" button
        for i=1:length(ComVarStr.Proc)
            if ComVarStr.Proc(i).ifExec
                set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
                break;
            end
        end
    end
    ComVarStr.ifChange=true; % indicate that the model has been changed; it will cause a call of funval and a consequent clearing of ComVarStr.Der1 and ComVarStr.inpCov
catch
end
return

function pbProModAdNew_Callback
%
% Ads a new parameter to the list of the current procedure
global M_figMod  % main figure handle
global ComVarStr;
try
 fname = get (findobj('Tag','edProModNew','Parent',M_figMod),'String');
 [N,N1] = getNM;
 if ~isfield(ComVarStr,'Proc') || N==0
     beep;
     disp('NO PROCEDURE IS CHOSEN');
     return
 end
     if isfield(ComVarStr.Proc(N),'Par') && (length(ComVarStr.Proc(N).Par)>1 || (length(ComVarStr.Proc(N).Par)==1 && isfield(ComVarStr.Proc(N).Par,'Name') && ~isempty(ComVarStr.Proc(N).Par.Name)) ) % this one also allows to deal with improper models produced by early versions of the program
        N0 = length(ComVarStr.Proc(N).Par);
        nn=[];
        for i=1:N0
            try
                if strcmp(ComVarStr.Proc(N).Par(i).Name,fname);
                    nn=i;
                    break;
                end
            catch
            end
        end
        if ~isempty(nn)
            set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',nn);
            return
        end
        if N1<N0
            ComVarStr.Proc(N).Par(N1+2:N0+1) = ComVarStr.Proc(N).Par(N1+1:N0);
        end
     else
        N1=0;
        N0=0;
     end
 ComVarStr.Proc(N).Par(N1+1).Name = {fname};
 ComVarStr.Proc(N).Par(N1+1).Descr = 'No description';
 ComVarStr.Proc(N).Par(N1+1).From = [];
 N0=N0+1;
 for i=1:N0
     C(i,1)=ComVarStr.Proc(N).Par(i).Name;
 end
 ComVarStr.Proc(N).Par(N1+1).Dim1=1;
 ComVarStr.Proc(N).Par(N1+1).Dim2=1;
 pname = getProName(N); % the short name of the procedure
 ComVarStr.(pname).(fname)=0;
% ComVarStr = setfield(ComVarStr,pname,fname,0); % set the new parameter equal to zero
 set (findobj('Tag','lstProMods','Parent',M_figMod),'String',C);
 set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',N1+1);
 set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','bold');
 lstProMods_Callback; % the same as click at the parameter name in the list
catch
end
return

function pbProModDelNew_Callback
%
% delete a parameter from the list of the procedure parameters
 global M_figMod  % main figure handle
 global ComVarStr
 [N,N1,paname] = getNM;
 fname = getProNm(N);
 if ~N || ~N1 || ~isfield(ComVarStr,'Proc') || ~isfield(ComVarStr.Proc(N),'Par')
     return
 end
 N0 = length(ComVarStr.Proc(N).Par);
 if N0>0
    try
        C = ComVarStr.(fname);
%        C = getfield(ComVarStr,fname);
        if isfield(C,paname)
            C = rmfield(C,paname);
            ComVarStr.(fname)=C;
%            ComVarStr = setfield(ComVarStr,fname,C);
        end
        clear C;
    catch
    end
    if N0>1
        for i=1:N0
            if i<N1
                C(i,1)=ComVarStr.Proc(N).Par(i).Name;
            elseif i>N1
                C(i-1,1)=ComVarStr.Proc(N).Par(i).Name;
            end
        end
    else
        C={'-'};
        set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','normal');
    end
    ComVarStr.Proc(N).Par(N1) = [];
    N1 = max(N1-1,1);
    set (findobj('Tag','edProModNew','Parent',M_figMod),'String',paname);
 else
    C={'-'};
    N1=1;
    set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','normal');
 end
 set (findobj('Tag','lstProMods','Parent',M_figMod),'String',C);
 set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',N1);
 lstProMods_Callback; % the same as click at the parameter name in the list
return

function popPron_Callback
 global M_figMod  % main figure handle
 global ComVarStr;
 N=getNM; % new ordinal number of the procedure
 set (findobj('Tag','txtProResMod','Parent',M_figMod),'FontWeight','normal');
 set (findobj('Tag','txtProFitMod','Parent',M_figMod),'FontWeight','normal');
 set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','normal');
 %
 if N==0
     set (findobj('Tag','txtProModNew','Parent',M_figMod),'String','ComVarStr.');
     set( findobj ('Tag','ckbExeProMod','Parent',M_figMod) ,'Value', get ( findobj('Tag','ckbProModGet','Parent',M_figMod),'Min' ) );
     set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','off'); % turn off the "Run" button
     set (findobj('Tag','edPronInf','Parent',M_figMod),'String','''-'' is a dummy mark');
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'String','-');
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',1);
     set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String','-');
     set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',1);
     set (findobj('Tag','lstProMods','Parent',M_figMod),'String','-');
     set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',1);
     refrDetail;
     if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        disp(strcat('Dummy block #',num2str(N),' is chosen'));
     end
     return;
 end
 %
 ip = 1; % current number of the parameter
 %
 % refresh the text part of the parameter name
 set (findobj('Tag','txtProModNew','Parent',M_figMod),'String',strcat('ComVarStr.',getProName(N),'.'));
 %
 % refresh the "Executable" checkbox
 if ComVarStr.Proc(N).ifExec
    set( findobj ('Tag','ckbExeProMod','Parent',M_figMod) ,'Value', get ( findobj('Tag','ckbProModGet','Parent',M_figMod),'Max' ) );
    set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on'); % turn on the "Run" button
    set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
 else
    set( findobj ('Tag','ckbExeProMod','Parent',M_figMod) ,'Value', get ( findobj('Tag','ckbProModGet','Parent',M_figMod),'Min' ) );
    set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','off'); % turn off the "Run" button
    set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','off'); % turn off the "Run All" button
    try
        for i=1:length(ComVarStr.Proc)
            try
                if ComVarStr.Proc(i).ifExec
                    set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on'); % turn on the "Run All" button
                end
            catch
            end
        end
    catch
    end
 end
 %
 % refresh the procedure information
 try
     C = ComVarStr.Proc(N).Descr;
     if isempty(C)
         C = 'THERE IS NO PROCEDURE DESCRIPTION';
     end
     set (findobj('Tag','edPronInf','Parent',M_figMod),'String',C);
 catch
     set (findobj('Tag','edPronInf','Parent',M_figMod),'String','THERE IS NO PROCEDURE DESCRIPTION');
 end
 clear C;
 %
 % refresh output parameters list
 try
    for i=1:length(ComVarStr.ResField{N})
        C(i,1)=ComVarStr.ResField{N}(i);
    end
    set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',1);
    set (findobj('Tag','lstProResMod','Parent',M_figMod),'String',C);
 catch
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',1);
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'String','-');
 end
 clear C;
 %
 % refresh input parameters list
 try
    for i=1:length(ComVarStr.ParField{N})
        C(i,1)=ComVarStr.ParField{N}(i);
    end
    set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',1);
    set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String',C);
 catch
     set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',1);
     set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String','-');
 end
 clear C;
 %
 % refresh the total parameters list
 try
    for i=1:length(ComVarStr.Proc(N).Par)
        try
            C(i,1)=ComVarStr.Proc(N).Par(i).Name;
        catch
            ComVarStr.Proc(N).Par(i:end)=[];
        end
    end
    set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',ip);
    set (findobj('Tag','lstProMods','Parent',M_figMod),'String',C);
 catch
    set (findobj('Tag','lstProMods','Parent',M_figMod),'Value',1);
    set (findobj('Tag','lstProMods','Parent',M_figMod),'String','-');
 end
 lstProMods_Callback; % the same as the mouse click at the 1-st line of the list
 clear C;
 %
 % refresh "DETAILS"
 refrDetail(N,ip);
 %
 % refresh the Optimizer window if it is open
 global O_figFit;
 if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
     Optimizer('refrOptimizer');
     figure(M_figMod);
 else
     clear global O_figFit;
 end
 try
     drawnow; % to refresh controls
 catch
     pause(0.01); % to refresh controls
 end
 %
 % output procedure details to the Command window if needed
 if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
     try
        if ~iscell(ComVarStr.Proc(N).Name)
            disp(strcat('Block #',num2str(N),' (',ComVarStr.Proc(N).Name,') is chosen'));
        else
            disp(strcat('Block #',num2str(N),' (',ComVarStr.Proc(N).Name{1},') is chosen'));
        end
     catch
        disp(strcat('Block #',num2str(N),' is chosen'));
     end
 end
 %
return

function refrDetail(N,ip)
% refreshes the "DETAILS" block accorng to the data on the ip-th parameter of the N-th procedure
global M_figMod  % main figure handle
global ComVarStr;
pause(0.05); % take some time to refresh parameters
if nargin<2
    ip=0;
    if nargin==0
        N=0;
    end
end
%
if N==0 || ip==0
     set (findobj('Tag','edProModDscr','Parent',M_figMod),'String','No description');
     set (findobj('Tag','edProModDim1','Parent',M_figMod),'String','1');
     set (findobj('Tag','edProModDim2','Parent',M_figMod),'String','1');
     set (findobj('Tag','edProModInd1','Parent',M_figMod),'String',':');
     set (findobj('Tag','edProModInd2','Parent',M_figMod),'String',':');
     set (findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
     set(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value',get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Min'));
     set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','-');
     set (findobj('Tag','edProFitModStep','Parent',M_figMod),'String','-');
     set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'String','-');
     return
 end
%
 %
 % refresh the parameter description
 try
     C = ComVarStr.Proc(N).Par(ip).Descr;
 catch
     C = 'No description';
 end
 if isempty(C)
     C = 'No description';
 end
 set (findobj('Tag','edProModDscr','Parent',M_figMod),'String',C);
 clear C;
 %
 % refresh dimensions
 try
     try
        D1 = ComVarStr.Proc(N).Par(ip).Dim1;
     catch
         D1=[];
     end
     if isempty(D1) || any(any(~isreal(D1))) || isinf(D1) || isnan(D1) || D1 < 0
         D1=1;
         if ~isempty(ComVarStr.Proc(N).Par)
            ComVarStr.Proc(N).Par(ip).Dim1 = D1;
         end
     end
     myGenWrite('edProModDim1',D1,'1');
     try
        D2 = ComVarStr.Proc(N).Par(ip).Dim2;
     catch
         D2=[];
     end
     if isempty(D2) || any(any(~isreal(D2))) || isinf(D2) || isnan(D2) || D2 < 0
         D2=1;
         if ~isempty(ComVarStr.Proc(N).Par)
            ComVarStr.Proc(N).Par(ip).Dim2 = D2;
         end
     end
     myGenWrite('edProModDim2',D2,'1');
%     edProModDim1_Callback; % act the Dim1 control
     clear D1;
     clear D2;
 catch
     set (findobj('Tag','edProModDim1','Parent',M_figMod),'String','1');
     set (findobj('Tag','edProModDim2','Parent',M_figMod),'String','1');
 end
 %
 % refresh indexes
 set (findobj('Tag','edProModInd1','Parent',M_figMod),'String','1');
 set (findobj('Tag','edProModInd2','Parent',M_figMod),'String','1');
 %
 try
     C = ComVarStr.Proc(N).Par(ip).From;
     if ~isempty(C)
        set(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value',get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Max'));
        set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','on');
        set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','on');
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','on');
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String',C);
     else
        set(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value',get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Min'));
        set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','off');
        set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','off');
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','off');
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','-');
     end
     clear C;
 catch
     set(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value',get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Min'));
     set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','-');
 end
 % Value, Step and Constraint are refreshed via a "mouse click" at indexes
 edProModInd1_Callback;
 pause(0.05); % to refresh controls
return

function edPronInf_Callback
%
% get the procedure description
    N = getNM;
    if N >0
        global M_figMod  % main figure handle
        global ComVarStr;
        ComVarStr.Proc(N).Descr = get(findobj('Tag','edPronInf','Parent',M_figMod),'String');
    end
return

function edProModDscr_Callback
%
% get the parameter description
try
    [N,M] = getNM;
    if N>0 && M>0
        global M_figMod  % main figure handle
        global ComVarStr;
        ComVarStr.Proc(N).Par(M).Descr = get(findobj('Tag','edProModDscr','Parent',M_figMod),'String');
    end
catch
end
return

function edProModDim1_Callback
%
% get the 1-st dimension
try
    global ComVarStr;
    [N,M,paname]=getNM;
    if M>0
        D = myGenRead('edProModDim1');
    else
        D=1;
    end
    if length(D)~=1
        try
            D=ComVarStr.Proc(N).Par(M).Dim1;
            if isempty(D) || any(any(~isreal(D))) || length(D)~=1 || D<0
                D=1;
            end
        catch
            D=1;
        end
    end
    D = max(0,floor(abs(D)));
    myGenWrite('edProModDim1',D,'-');
    try
        if D<myGenRead('edProModInd1')
            edProModInd1_Callback;
        end
    end
    if N>0 && M>0
        try
            ComVarStr.Proc(N).Par(M).Dim1 = D;
            ProName=getProName(N);
            Val = ComVarStr.(ProName).(paname);
%            Val = getfield(ComVarStr,ProName,paname);
            DVal = size(Val,1);
            if DVal>D
                Val(D+1:DVal,:) = [];
                setVal(Val,N,M);
%                ComVarStr = setfield(ComVarStr,ProName,paname,Val);
            elseif DVal<D
                Val(DVal+1:D,:) = 0;
                setVal(Val,N,M);
%                ComVarStr = setfield(ComVarStr,ProName,paname,Val);
            end
            if D==0
                myGenWrite('edProModDim2','0','-');
                ComVarStr.Proc(N).Par(M).Dim2 = D;
            end
        catch
        end
    end
    %
catch
    myGenWrite('edProModDim1','-','-');
end
return

function edProModDim2_Callback
%
% get the second dimension
try
    global ComVarStr;
    [N,M,paname]=getNM;
    if M>0
        D = myGenRead('edProModDim2');
    else
        D=1;
    end
    if length(D)~=1
        try
            D=ComVarStr.Proc(N).Par(M).Dim2;
            if isempty(D) || length(D)~=1 || ~isnumeric(D) || D<1
                D=1;
            end
        catch
            D=1;
        end
    end
    D = max(0,floor(abs(D)));
    myGenWrite('edProModDim2',D,'-');
    try
        if D<myGenRead('edProModInd2')
            edProModInd2_Callback;
        end
    end
    if N>0 && M>0
        try
            ComVarStr.Proc(N).Par(M).Dim2 = D;
            ProName=getProName(N);
            Val = ComVarStr.(ProName).(paname);
%            Val = getfield(ComVarStr,ProName,paname);
            DVal = size(Val,2);
            if DVal>D
                Val(:,D+1:DVal) = [];
                setVal(Val,N,M);
%                ComVarStr = setfield(ComVarStr,ProName,paname,Val);
            elseif DVal<D
                Val(:,DVal+1:D) = 0;
                setVal(Val,N,M);
%                ComVarStr = setfield(ComVarStr,ProName,paname,Val);
            end
            if D==0
                myGenWrite('edProModDim2','0','-');
                ComVarStr.Proc(N).Par(M).Dim2 = D;
            end
        catch
        end
    end
catch
    myGenWrite('edProModDim2','-','-');
end
return

function edProModInd1_Callback
%
% get the 1-st index
global M_figMod  % main figure handle
try
    D = myGenRead('edProModDim1');
    if D>0
        I = get(findobj('Tag','edProModInd1','Parent',M_figMod),'String');
        if ~strcmp (I,':')
            I = str2num(I);
            if isempty (I)
                I=1;
            end
            I = floor(abs(I));
            k1 = find(I>D);
            if ~isempty(k1)
                k=find(I>=D);
                I(k(1))=D;
                if numel(k)>1
                    I(k(2:end))=[];
                end
            end
            k2 = find(I<1);
            if ~isempty(k2)
                k = find(I<=1);
                I(k(1))=1;
                if numel(k)>1
                    I(k(2:end))=[];
                end
            end
            k=length(I);
            if ~isempty(k1) || ~isempty(k2)
                if k==1
                    set(findobj('Tag','edProModInd1','Parent',M_figMod),'String',num2str(I));
                elseif k<10
                    set(findobj('Tag','edProModInd1','Parent',M_figMod),'String',strcat('[',num2str(I),']') );
                elseif I(2)-I(1)~=1
                    set(findobj('Tag','edProModInd1','Parent',M_figMod),'String',strcat(num2str(I(1)),':',num2str(I(2)-I(1)),':',num2str(I(k))) );
                else
                    set(findobj('Tag','edProModInd1','Parent',M_figMod),'String',strcat(num2str(I(1)),':',num2str(I(k))) );
                end
            end
        else
            k=D;
        end
    else
        k=0;
        set(findobj('Tag','edProModInd1','Parent',M_figMod),'String','0' );
    end
    %
    % display the value
    [N,M]=getNM;
    if M==0
        return
    end
    [I,J] = getij; % to get J; I remains the same
    Val = getVal(N,M,I,J);
    if k>1 || length(J)>1
        myGenWrite('edProModVal',Val,':');
    else
        myGenWrite('edProModVal',Val,'-');
    end
    %
    % refresh Step and Constraint
    if strcmp(get (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable'),'off')
        set (findobj('Tag','edProFitModStep','Parent',M_figMod),'String','-');
        set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'String','-');
    else
        global ComVarStr;
        M1 = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value');
        L = NordPa(N,M1,I,J,'ParField');
        try
            Step = ComVarStr.ParStep(L);
            if length(Step)>1 && all(Step==Step(1))
                Step(2:length(Step)) = [];
            end
        catch
            Step = 0;
        end
        try
            for i=1:length(L)
                try
                    Constr(i) = ComVarStr.ParCnstr{L(i)};
                catch
                    Constr(i) = ComVarStr.ParCnstr(L(i));
                end
            end
            if length(Constr)>1 && all(Constr==Constr(1))
                Constr(2:length(Constr)) = [];
            end
        catch
            Constr = '-';
        end
        if k>1 || length(J)>1
            myGenWrite('edProFitModStep',Step,':');
            myGenWrite('edProFitModConstr',Constr,':');
        else
            myGenWrite('edProFitModStep',Step,'-');
            myGenWrite('edProFitModConstr',Constr,'-');
        end
    end
catch
end
return

function edProModInd2_Callback
%
% get the 2-nd index
try
    global M_figMod  % main figure handle
    D = myGenRead('edProModDim2');
    if D>0
        I = get(findobj('Tag','edProModInd2','Parent',M_figMod),'String');
        if ~strcmp (I,':')
            I = str2num(I);
            if isempty (I)
                I=1;
            end
            I = floor(abs(I));
            k1 = find(I>D);
            if ~isempty(k1)
                k = find(I>=D);
                I(k(1))=D;
                if numel(k)>1
                    I(k(2:end))=[];
                end
            end
            k2 = find(I<1);
            if ~isempty(k2)
                k = find(I<=1);
                I(k(1))=1;
                if numel(k)>1
                    I(k(2:end))=[];
                end
            end
            k=length(I);
            if ~isempty(k1) || ~isempty(k2)
                if k==1
                    set(findobj('Tag','edProModInd2','Parent',M_figMod),'String',num2str(I));
                elseif k<10
                    set(findobj('Tag','edProModInd2','Parent',M_figMod),'String',strcat('[',num2str(I),']') );
                elseif I(2)-I(1)~=1
                    set(findobj('Tag','edProModInd2','Parent',M_figMod),'String',strcat(num2str(I(1)),':',num2str(I(2)-I(1)),':',num2str(I(k))) );
                else
                    set(findobj('Tag','edProModInd2','Parent',M_figMod),'String',strcat(num2str(I(1)),':',num2str(I(k))) );
                end
            end
        else
            k=D;
        end
    else
        k=0;
        set(findobj('Tag','edProModInd2','Parent',M_figMod),'String','0');
    end
    %
    % display the value
    [N,M]=getNM;
    if M==0
        return
    end
    [J,I] = getij; % to get J; I remains the same 
    Val = getVal(N,M,J,I);
    if k>1 || length(J)>1
        myGenWrite('edProModVal',Val,':');
    else
        myGenWrite('edProModVal',Val,'-');
    end
    %
    % refresh Step and Constraint
    if strcmp(get (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable'),'off')
        set (findobj('Tag','edProFitModStep','Parent',M_figMod),'String','-');
        set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'String','-');
    else
        global ComVarStr;
        M1 = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value');
        L = NordPa(N,M1,J,I,'ParField');
        try
            Step = ComVarStr.ParStep(L);
            if length(Step)>1 && all(Step==Step(1))
                Step(2:length(Step)) = [];
            end
        catch
            Step = 0;
        end
        try
            for i=1:length(L)
                try
                    Constr(i) = ComVarStr.ParCnstr{L(i)};
                catch
                    Constr(i) = ComVarStr.ParCnstr(L(i));
                end
            end
            if length(Constr)>1 && all(Constr==Constr(1))
                Constr(2:length(Constr)) = [];
            end
        catch
            Constr = '-';
        end
        if k>1 || length(J)>1
            myGenWrite('edProFitModStep',Step,':');
            myGenWrite('edProFitModConstr',Constr,':');
        else
            myGenWrite('edProFitModStep',Step,'-');
            myGenWrite('edProFitModConstr',Constr,'-');
        end
    end
catch
end
return

function edProModVal_Callback
%
% get a new value of the parameter
global M_figMod  % main figure handle
global ComVarStr;
try
    C = get(findobj('Tag','edProModVal','Parent',M_figMod),'String');
    [N,M,paname] = getNM;
    [i,j] = getij;
    if N>0 && M>0 && ~isempty(i) && ~isempty(j)
        %
        if isempty(C) || (length(C)==2 && all(C=='[]')) || (length(C)==1 && C=='-')
            C=[];
            set (findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
        else
            C = str2num(C);
            if isempty(C)
                C = 0;
                set (findobj('Tag','edProModVal','Parent',M_figMod),'String','0');
            end
        end
        try
            Ccur = ComVarStr.(getProNm(N)).(paname); % current values of the parameters
%            Ccur = getfield(ComVarStr,getProNm(N),paname); % current values of the parameters
        catch
            if isempty(C) || C(1)~=0
                Ccur = zeros(length(i),length(j)); % cannot equal C any case
            else
                Ccur = ones(length(i),length(j)); % cannot equal C any case
            end
        end
        if isempty(Ccur)
            i=0;
            j=0;
        else
            if ~isnumeric(Ccur) && ~islogical(Ccur)
                beep;
                warndlg([{'This editing is forbidden!'};{'See details in the command window.'}]);
                disp('!!!');
                disp('WARNING: the variable attempted to be edited is not numerical: its contents is not altered.');
                disp('It can be only edited via a direct manipulating of the global structure ComVarStr (see the manual for details).');
                disp('E. g., for the string variable, type:');
                disp('global ComVarStr');
                disp('ComVarStr.(Block Name).(Parameter Name)=''your string''');
                disp('!!!');
                beep;
                if iscell(Ccur)
                    Ccur=Ccur{i,j};
                    if isnumeric(Ccur)
                        Ccur=num2str(Ccur);
                    end
                end
                try
                    set(findobj('Tag','edProModVal','Parent',M_figMod),'String',Ccur);
                catch
                    set(findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
                end
                return;
            end
            if numel(Ccur)==numel(C)
                i=1:size(Ccur,1);
                j=1:size(Ccur,2);
            end
        end
        try
            Ccur = Ccur(i,j); % if the value is empty
        catch
            if isempty(C) || C(1)~=0
                Ccur = zeros(length(i),length(j)); % cannot equal C any case
            else
                Ccur = ones(length(i),length(j)); % cannot equal C any case
            end
        end
        if any(size(Ccur)~=size(C)) || any(any(Ccur~=C)) % any(any.. for the case of matrices where any(.. would return a vector
            setVal(C,N,M,i,j);
            ComVarStr.Df=[];
            ComVarStr.sigma2=[];
            putresults;
            ComVarStr.ifChange=true; % indicate that the model has been changed; it will cause a call of funval and a consequent clearing of ComVarStr.Der1 and ComVarStr.inpCov
            global O_figFit;  % Optimizer figure handle
            if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
                Optimizer('refrOptimRes');
                figure(M_figMod);
            else
                clear global O_figFit;
            end
        end
    else
        set (findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
    end
catch
    set (findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
end
return

function ckbProModGet_Callback
%
% is the current parameter to be got from another field?
 global M_figMod  % main figure handle
 global ComVarStr
 [N,M] = getNM;
 if N<=0 || M<=0
     set(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value',get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Min'));
 end
 if get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Value') == get(findobj('Tag','ckbProModGet','Parent',M_figMod),'Max')
     set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','on');
     set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','on');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','on');
     try
        pname = ComVarStr.Proc(N).Par(M).From;
     catch
        pname  = [];
     end
     if isempty(pname) || ~ischar(pname)
        [N,M,paname] = getNM; % parameter name is only needed
        pname  = getProName(N);
        pname = strcat(pname,'.',paname);
     end
     ComVarStr.Proc(N).Par(M).From = pname;
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String',pname);
 else
     set(findobj('Tag','pbProModGet','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','pbProModPut','Parent',M_figMod),'Enable','off');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','-');
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'Enable','off');
     try
        if isfield(ComVarStr.Proc(N).Par(M),'From')
            ComVarStr.Proc(N).Par(M).From = [];
        end
    catch
    end
 end
return

function edProModValGlo_Callback
%
% which field is to get the current parameter from?
global ComVarStr;
global M_figMod  % main figure handle
try
    GloN = get(findobj('Tag','edProModValGlo','Parent',M_figMod),'String');
    [N,M]=getNM;
    if ~isempty(GloN) % correct misprinted dots
        np=strfind(GloN,',');
        if ~isempty(np)
          GloN(np)='.';
        end
        np=strfind(GloN,'.');
        if numel(np)>=2
          k=find(np(2:end)-np(1:end-1)==1);
          if ~isempty(k)
            GloN(np(k))=[];
            np=strfind(GloN,'.');
          end
        end
        if ~isempty(np) && np(end)==length(GloN)
          GloN(end)=[];
          np(end)=[];
        end
    end
    if isempty(GloN) || (length(GloN)==2 && all(GloN=='[]')) || all(GloN=='-') % (length(GloN)==1 && all(GloN=='-')) 
        if N>0 && M>0 && ~(length(ComVarStr.Proc(N).Par(M).From)==1 && ComVarStr.Proc(N).Par(M).From == '-')
            if ~isfield(ComVarStr.Proc(N).Par(M),'From') || length(ComVarStr.Proc(N).Par(M).From)~=1 || ComVarStr.Proc(N).Par(M).From~='-'
                ComVarStr.Proc(N).Par(M).From = '-';
                ComVarStr.ifChange=true; % the model has been changed
            end
        end
        return
    end
%    np = strfind(GloN,'.');
%    kp = length(np);
%    if kp>0
%        % eliminate end dots
%        kG = length(GloN);
%        while np(kp)==kG
%            GloN(kG)=[];
%            kG=kG-1;
%            np(kp)=[];
%            kp=kp-1;
%        end
%        while kp>=1 && kG>1 && np(1)==1
%            GloN(1)=[];
%            kG=kG-1;
%            np = np-1;
%            np(1)=[];
%            kp=kp-1;
%        end
%        while kp>1 && kG>1 && any (np(2:kp)-np(1:kp-1)==1)
%            k = find(np(2:kp)-np(1:kp-1)==1);
%            GloN(np(k))=[];
%            np = strfind(GloN,'.');
%            kp = length(np);
%        end
%        if kp>2
%            set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','REDUCE ''.'' DEPTH');
%            pause(0.5);
%            GloN=GloN(1:np(3)-1);
%        end
%    end
    %
    % check for invalid characters
%    if isempty(str2num(GloN)) % incorrectr in Octave!
%    lN = length(GloN);
    if ~(  ( isempty(np) && length(GloN)>0 && isfield(ComVarStr,GloN) && isnumeric(ComVarStr.GloN) ) || ...
       ( isscalar(np) && np~=1 && isfield(ComVarStr,GloN(1:np-1)) && isfield(ComVarStr.(GloN(1:np-1)),GloN(np+1:end)) && isnumeric(ComVarStr.(GloN(1:np-1)).(GloN(np+1:end))) ) || ...
       ( numel(np)==2 && np(1)~=1 && isfield(ComVarStr,GloN(1:np(1)-1)) && isfield(ComVarStr.(GloN(1:np(1)-1)),GloN(np(1)+1:np(2)-1)) && isfield(ComVarStr.(GloN(1:np(1)-1)).(GloN(np(1)+1:np(2)-1)),GloN(np(2)+1:end)) && isnumeric(ComVarStr.(GloN(1:np(1)-1)).(GloN(np(1)+1:np(2)-1)).(GloN(np(2)+1:end))) ) ...
       )
       if isempty(str2num(GloN))
          beep;
          GloN='Invalid name!';
       end
%        if lN>0
%            for i=lN:-1:1
%                ch = GloN(i);
%                if ~(i~=1 && (ch>='0' && ch<='9')) && ~(ch>='A' && ch<='Z') && ~(ch>='a' && ch<='z') && ~(ch=='.' && i~=length(GloN))
%                    set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','Invalid character!');
%                    pause(0.2);
%                    GloN(i) = [];
%                end
%            end
%        end
%        while ~isempty(GloN) && ( (GloN(1)>='0' && GloN(1)<='9') || GloN(1)=='.')
%            set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','Invalid name!');
%            pause(0.2);
%            GloN(1)=[];
%        end
%        np = strfind(GloN,'.');
%        kp = length(np);
%        if kp>0
%            for i=kp:-1:1
%                try
%                    while GloN(np(i)+1)>='0' && GloN(np(i)+1)<='9'
%                        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','Invalid name!');
%                        pause(0.2);
%                        GloN(np(i)+1) = [];
%                    end
%                catch
%                        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','Invalid name!');
%                        pause(0.2);
%                        GloN(np(i)) = [];
%                end
%            end
%        end
    end
    set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String',GloN);
    if N>0 && M>0
        ComVarStr.Proc(N).Par(M).From = GloN;
        ComVarStr.ifChange=true; % the model has been changed
    end
catch
end
return

function pbProModGet_Callback
%
% get the current parameter from the field!
global M_figMod  % main figure handle
global ComVarStr;
try
    [N,M] = getNM;
    [i,j] = getij;
    GloN = get(findobj('Tag','edProModValGlo','Parent',M_figMod),'String');
    if isempty(GloN) || (length(GloN)==2 && all(GloN=='[]')) || (length(GloN)==1 && all(GloN=='-'))
        Val=[];
    else
%        edProModValGlo_Callback; % in case the GloN was entered incorrectly
        np = strfind(GloN,'.');
        kp = length(np);
        while kp>1
            kkp=find(np(2:end)-np(1:end-1)==1);
            if isempty(kkp)
                break;
            end
            GloN(kkp)=[];
            np(kkp)=[];
            kp = length(np);
        end
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String',GloN);
        %
        % try to get the current value of the global parameter
        if kp==0
          if isfield(ComVarStr,GloN) && isnumeric(ComVarStr.(GloN))
            Val = ComVarStr.(GloN);
%             Val = getfield ( ComVarStr,GloN );
          elseif ~exist(GloN,'file')
            Val=str2num(GloN);
            if isempty(Val)
              Val=NaN;
            end
          else
            Val = NaN;
          end
        elseif kp==1 && np~=1 && np~=length(GloN)
          if isfield(ComVarStr,GloN(1:np(1)-1)) && isfield(ComVarStr.(GloN(1:np(1)-1)),GloN (np(1)+1:length(GloN))) && isnumeric(ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:length(GloN))))
            Val = ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:length(GloN)));
%             Val = getfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:length(GloN)) );
          elseif ~exist(GloN(1:np(1)-1),'file')
            Val=str2num(GloN);
            if isempty(Val)
              Val=NaN;
            end
          else
            Val = NaN;
          end
        elseif kp==2 && np(1)~=1 && np(2)~=length(GloN)
          if isfield(ComVarStr,GloN(1:np(1)-1)) && isfield(ComVarStr.(GloN(1:np(1)-1)),GloN (np(1)+1:np(2)-1)) && isfield(ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:np(2)-1)),GloN (np(2)+1:length(GloN))) && isnumeric(ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:np(2)-1)).(GloN (np(2)+1:length(GloN))))
            Val = ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:np(2)-1)).(GloN (np(2)+1:length(GloN)));
%             Val = getfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:np(2)-1), GloN (np(2)+1:length(GloN)) );
          elseif ~exist(GloN(1:np(1)-1),'file')
            Val=str2num(GloN);
            if isempty(Val)
              Val=NaN;
            end
          else
            Val = NaN;
          end
        elseif ~exist(GloN(1:np(1)-1),'file')
          Val=str2num(GloN);
          if isempty(Val)
            Val=NaN;
          end
        else
          Val = NaN;
        end
    end
    if isempty(Val) || any(any(~isnan(Val)))
      %
      % eliminate large indexes
      ki  = length(i);
      kj  = length(j);
      kV1 = size(Val,1);
      kV2 = size(Val,2);
      if (ki>1 && kV1>1) || (kj>1 && kV2>1)
          k = find (i>kV1);
          if ~isempty(k)
              i(k)=[];
              ki = length(i);
          end
          k = find (j>kV2);
          if ~isempty(k)
              j(k)=[];
              kj = length(j);
          end
      end
      %
      % eliminate unused elements of Val
      if kV1>i(ki)
          Val(i(ki)+1:kV1,:)=[];
      end
      if kV1>=i(1) && i(1)>1
          Val(1:i(1)-1,:)=[];
      end
      if kV2>j(kj)
          Val(:,j(kj)+1:kV2)=[];
      end
      if kV2>=j(1) && j(1)>1
          Val(:,1:j(1)-1)=[];
      end
      setVal(Val,N,M,i,j);
      %
      edProModInd1_Callback; % to refresh the value in the form
    else
      if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
%        disp('WARNING: incorrect FROM: no data transfer is done');
        set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','INCORRECT INPUT!');
      end
    end
catch
    set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','INCORRECT INPUT!');
end
return

function pbProModPut_Callback
%
% put the current parameter to the field!
    global M_figMod  % main figure handle
    global ComVarStr;
    [N,M] = getNM;
    GloN = get(findobj('Tag','edProModValGlo','Parent',M_figMod),'String');
    edProModValGlo_Callback; % in case the GloN was entered incorrectly
    np = strfind(GloN,'.');
    kp = length(np);
    %
    [i,j] = getij;
    %
    % try to get the current values of the global parameters
    Val0 = getVal(N,M,i,j);
    try
        if kp==0
            Val = ComVarStr.(GloN);
%            Val = getfield ( ComVarStr,GloN );
        elseif kp==1
            Val = ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:length(GloN)));
%            Val = getfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:length(GloN)) );
        else
            Val = ComVarStr.(GloN (1:np(1)-1)).(GloN (np(1)+1:np(2)-1)).(GloN (np(1)+1:length(GloN)));
%            Val = getfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:np(2)-1), GloN (np(1)+1:length(GloN)) );
        end
    catch
        try
            Val = getVal(N,M);
        catch
            try
                D1 = myGenRead('edProModDim1');
                D2 = myGenRead('edProModDim2');
                Val= zeros(D1,D2);
            catch
                Val=[];
            end
        end
    end
    %
    % eliminate large indexes
    if length(i)>1 || length(j)>1
        k = find (i>size(Val,1));
        if ~isempty(k)
            i(k)=[];
        end
        k = find (j>size(Val,2));
        if ~isempty(k)
            j(k)=[];
        end
    end
    %
    Val(i,j) = Val0;
    %
    if ~kp
        ComVarStr.(GloN)=Val;
%        ComVarStr = setfield ( ComVarStr,GloN , Val);
    elseif kp==1
        ComVarStr.(GloN(1:np(1)-1)).(GloN(np(1)+1:length(GloN)))=Val;
%        ComVarStr = setfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:length(GloN)) , Val);
    else
        ComVarStr.(GloN(1:np(1)-1)).(GloN(np(1)+1:np(2)-1)).(GloN(np(2)+1:length(GloN)))=Val;
%        ComVarStr = setfield ( ComVarStr,GloN (1:np(1)-1), GloN (np(1)+1:np(2)-1), GloN (np(2)+1:length(GloN))  , Val);
    end
    %
    % eliminate unused elements of Val
    edProModInd1_Callback; % to refresh the value in the form
try
catch
     set(findobj('Tag','edProModValGlo','Parent',M_figMod),'String','INCORRECT INPUT!');
end
return

function lstProMods_Callback
%
% click the list of the parameters
global M_figMod  % main figure handle
try
    set (findobj('Tag','pbProModDelNew'),'enable','on'); % turn on the "delete parameter" button
    [N,M,paname] = getNM;
    fname = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','on'); % turn on the DIMs
    set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','on'); % turn on the DIMs
    if L
        set(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',L);
        set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
        set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
        lstProFitMod_Callback; % let the input parameters list be active
        return
    end
    %
    fname = get(findobj('Tag','lstProResMod','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    if L
        set(findobj('Tag','lstProResMod','Parent',M_figMod),'Value',L);
        set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
        set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
        lstProResMod_Callback; % let the result parameters list be active
        return
    end
    %
    set (findobj('Tag','txtProResMod','Parent',M_figMod),'FontWeight','normal');
    set (findobj('Tag','txtProFitMod','Parent',M_figMod),'FontWeight','normal');
    set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','bold');
    set (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable','off');
    set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'Enable','off');
    %
    refrDetail(N,M);
catch
end
return

function pbProFitAd_Callback
%
% add a parameter to the list of the varied parameters
global M_figMod  % main figure handle
global ComVarStr;
try
 % collect data
 [N,M,paname] = getNM; % N is a current number of the procedure, M is an ordinal number of the parameter in the all parameters of the procedure list paname is a name of the current parameter
 pname =getProName(N); % short name of the current procedure
 L = 0; % to be the total number of variable paramaters
 i = 1;
 while true
     try
        L = L + length(ComVarStr.ParField{i}); % names of all variable parameters
        i = i+1;
     catch
        if i<=N
            ComVarStr.ParField{i}=[];
            i = i+1;
        else
            break;
        end
    end
 end
 i=i-1;
% try
%    L = length(ComVarStr.ParField{N}); % total number of variables for the N-th procedure
% catch
%    L = 0;
% end
 D1 = myGenRead('edProModDim1'); % dimensions of the parameter to be added to the list of the variable parameters
 D2 = myGenRead('edProModDim2');
 kVal = D1*D2; % total number of elements in Val
 L0 = get (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value'); % ordinal number of the current variable parameter in the list for the current procedure
 LL = length(ComVarStr.ParField{N}); % total number of variable parameters for the current procedure
 try
    if isempty (ComVarStr.ParField{N}{L0})
        L0=0;
    end
 catch
     L0=0;
 end
 K  = NordPa(N,L0+1); % total number of 1-D elements up (including) to the current variable parameter
 K0 = NordPa(i,L+1);  % total number of 1-D elements in all the variable parameter
 %
 % modify data
 if LL==0
     ComVarStr.ParField{N}{1} = paname;
     set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String',paname);
 else
    try
        fname = ComVarStr.ParField{N};
    catch
        fname = {'.'}; % a fool name
    end
    L1 = findCellTxt(fname,paname);
    if L1>0
        set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',L1);
        return;
    end
    %
%    LL = L;
    for i=LL:-1:1 % eliminate empty cells
        try
            if isempty (ComVarStr.ParField{N}{i})
                ComVarStr.ParField{N}(i) = [];
                L=L-1;
            else
                break;
            end
        catch
            if isempty (ComVarStr.ParField{N})
                % ComVarStr.ParField{N}(i) = []; % no need to eliminate an absent field
                L=L-1;
            else
                break;
            end
        end
    end
    if LL>L0
        ComVarStr.ParField{N}(L0+2:LL+1) = ComVarStr.ParField{N}(L0+1:LL);
    end
    ComVarStr.ParField{N}{L0+1} = paname;
    set(findobj('Tag','lstProFitMod','Parent',M_figMod),'String',ComVarStr.ParField{N});
    set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',L0+1);
end
if K<K0
    try
        ComVarStr.ParStep(K+kVal+1:K0+kVal) = ComVarStr.ParStep(K+1:K0);
    catch
    end
    try
        ComVarStr.ParCnstr(K+kVal+1:K0+kVal) = ComVarStr.ParCnstr(K+1:K0);
    catch
    end
end
ComVarStr.ParStep(K+1:K+kVal) = 0;
ComVarStr.ParCnstr(K+1:K+kVal) = {[]};
set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
catch
end
 %
 % refresh the Optimizer window if it is open
 try
    global O_figFit;
    if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
        Optimizer('refrOptimizer');
        figure(M_figMod);
    else
        clear global O_figFit;
    end
catch
end
lstProFitMod_Callback; % "click" the list
return

function pbProFitDel_Callback(NNN) % no input is needed in the visual regime of excluding a single input variable; an input indicates that an entire (list of) block(s) NNN is deleted
global M_figMod  % main figure handle
global ComVarStr
try
    %
    % collect data
    if nargin==0 || isempty(NNN) || all(all(~isreal(NNN))) % excluding a single input variable
        NNN = getNM; % gets current index of the procedure
        L1 = get (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value');
        L2 = L1;
        kN = 1;
    else % entire (list of) block(s) NNN is deleted
        L1 = 1;
        L2 = length(ComVarStr.ParField{NNN(1)});
        kN = length(NNN);
    end
    fna = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
    for k=1:kN
        N = NNN(k);
        if kN>1
            L2 = length(ComVarStr.ParField{N});
        end
        try
            fname = ComVarStr.ParField{N};
        catch
            return;
        end
        for L0=L2:-1:L1
            K1 = NordPa(N,L0)+1; % total number of elements below the current variable parameter +1
            K2 = NordPa(N,L0+1); % total number of elements up (including) to the current variable parameter
            %
            % modify data
            fname(L0) = [];
            if isempty(fname)
                fname=[];
            end
            ComVarStr.ParField{N} = fname;
            try
                ComVarStr.ParStep(K1:K2) = [];
            catch
            end
            try
                ComVarStr.ParCnstr(K1:K2) = [];
            catch
            end
            L = length(fname);
            if ~isempty(M_figMod)
                if ~isempty(fname)
                    set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String',fname);
                else
                    set (findobj('Tag','lstProFitMod','Parent',M_figMod),'String','-');
                end
                set (findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',1);
                %
                try
                    fn = fname{1};
                catch
                    fn = fname(1);
                end
%                fname = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
%                L = findCellTxt(fname,fn);
                L = findCellTxt(fna,fn);
                if L>0
                    set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',L);
                end
            end
        end
    end
catch
end
 %
 % refresh the Optimizer window if it is open
 try
    global O_figFit;
    if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
        Optimizer('refrOptimizer');
        figure(M_figMod);
    else
        clear global O_figFit;
    end
catch
end
lstProFitMod_Callback; % "click" the list
return

function edProModNew_Callback
%
% check for invalid names
global M_figMod  % main figure handle
try
    Name = get(findobj('Tag','edProModNew','Parent',M_figMod),'String');
    np = strfind(Name,'.');
    if ~isempty(np)
        set(findobj('Tag','edProModNew','Parent',M_figMod),'String','No ''.''!');
        pause(1);
        if np(1)==1
            try
                while ~isempty(np) && np(1)==1
                    Name(1)=[];
                    np = strfind(Name,'.');
                end
            catch
            end
        end
        if ~isempty(np)
            Name(np(1):length(Name)) = [];
        end
    end
    lN = length(Name);
    if lN>0
        for i=lN:-1:1
            ch = Name(i);
            if ~(i~=1 && (ch>='0' && ch<='9')) && ~(ch>='A' && ch<='Z') && ~(ch>='a' && ch<='z')
                set(findobj('Tag','edProModNew','Parent',M_figMod),'String','Invalid character!');
                pause(0.2);
                Name(i) = [];
            end
        end
    end
    while ~isempty(Name) && (Name(1)>='0' && Name(1)<='9')
        Name(1)=[];
    end
    set(findobj('Tag','edProModNew','Parent',M_figMod),'String',Name);
catch
    set(findobj('Tag','edProModNew','Parent',M_figMod),'String','');
end
return

function pbProResAd_Callback
%
% add a parameter to the results field
global M_figMod  % main figure handle
global ComVarStr;
try
 [N,M,paname] = getNM;
 try
    fname = ComVarStr.ResField{N};
 catch
    fname=[];
 end
 L = length(fname);
 if ~L
     ComVarStr.ResField{N}{1} = paname;
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'String',paname);
     set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
     set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
     lstProResMod_Callback; % the same as the click at the results list
     try
         if M<length(ComVarStr.Proc(N).Par)
             set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',M+1);
         end
     catch
     end
     return
 end
 %
 L0 = findCellTxt(fname,paname);
 if L0>0
     set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',L0);
     return;
 end
 %
 L0 = get (findobj('Tag','lstProResMod','Parent',M_figMod),'Value');
 if L>L0
     ComVarStr.ResField{N}(L0+2:L+1) = ComVarStr.ResField{N}(L0+1:L);
 end
 ComVarStr.ResField{N}{L0+1} = paname;
 set(findobj('Tag','lstProResMod','Parent',M_figMod),'String',ComVarStr.ResField{N});
 set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',L0+1);
 set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
 set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
catch
end
lstProResMod_Callback; % the same as the click at the results list
try
    if M<length(ComVarStr.Proc(N).Par)
        set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',M+1);
    end
catch
end
return

function pbProResDel_Callback
global M_figMod  % main figure handle
global ComVarStr
try
    N = getNM;
    L0 = get (findobj('Tag','lstProResMod','Parent',M_figMod),'Value');
    try
        fname = ComVarStr.ResField{N};
    catch
        return;
    end
    fname(L0) = [];
    ComVarStr.ResField{N} = fname;
    if ~isempty(fname)
        set (findobj('Tag','lstProResMod','Parent',M_figMod),'String',fname);
    else
        set (findobj('Tag','lstProResMod','Parent',M_figMod),'String','-');
    end
    set (findobj('Tag','lstProResMod','Parent',M_figMod),'Value',1);
    %
    try
        fn = fname{1};
    catch
        fn = fname(1);
    end
    fname = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
    L = findCellTxt(fname,fn);
    if L
        set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',L);
    end
catch
end
lstProResMod_Callback; % the same as the click at the results list
return

function lstProFitMod_Callback
global M_figMod  % main figure handle
try
    if isempty(M_figMod)
        return;
    end
catch
    return;
end
try
    %
    fname = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'String');
    L = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value');
    try
        paname = fname{L};
    catch
        paname = fname;
    end
    if ~strcmp('-',paname)
        set (findobj('Tag','pbProModDelNew','Parent',M_figMod),'enable','off'); % turn off the "delete parameter" button
    end
    %
    fname = get(findobj('Tag','lstProResMod','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    if L>0
        set(findobj('Tag','lstProResMod','Parent',M_figMod),'Value',L);
    end
    %
    fname = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    if L>0
        set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',L);
    end
    %
    set (findobj('Tag','txtProResMod','Parent',M_figMod),'FontWeight','normal');
    set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','normal');
    if strcmp(paname,'-')
        set (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable','off');
        set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'Enable','off');
    else
        set (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable','on');
        set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'Enable','on');
    end
    set (findobj('Tag','txtProFitMod','Parent',M_figMod),'FontWeight','bold');
    set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
    set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
    %
    [N,M] = getNM;
    refrDetail(N,M);
catch
end
return

function lstProResMod_Callback
global M_figMod  % main figure handle
try
    %
    fname = get(findobj('Tag','lstProResMod','Parent',M_figMod),'String');
    L = get(findobj('Tag','lstProResMod','Parent',M_figMod),'Value');
    try
        paname = fname{L};
    catch
        paname = fname;
    end
    if ~strcmp('-',paname)
        set (findobj('Tag','pbProModDelNew','Parent',M_figMod),'enable','off'); % turn off the "delete parameter" button
    end
    %
    fname = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    if L>0
        set(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value',L);
        lstProFitMod_Callback; % let the input parameters list be active
        return
    end
    %
    fname = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
    L = findCellTxt(fname,paname);% finds text paname within a cell array fname
    if L>0
        set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',L);
    end
    %
    set (findobj('Tag','txtProResMod','Parent',M_figMod),'FontWeight','bold');
    set (findobj('Tag','txtProFitMod','Parent',M_figMod),'FontWeight','normal');
    set (findobj('Tag','txtProMod','Parent',M_figMod),'FontWeight','normal');
    set (findobj('Tag','edProFitModStep','Parent',M_figMod),'Enable','off');
    set (findobj('Tag','edProFitModConstr','Parent',M_figMod),'Enable','off');
    set (findobj('Tag','edProModDim1','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
    set (findobj('Tag','edProModDim2','Parent',M_figMod),'Enable','off'); % no way to change the structure of the variable in this regime
    %
    [N,M] = getNM;
    refrDetail(N,M);
catch
end
return

function edProFitModStep_Callback
global M_figMod  % main figure handle
try
    global ComVarStr;
    N = getNM; % current number of the procedure
    [I,J] = getij; % current indexes of the current variable
    M1 = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value'); % current number of the parameter in the input parameters list
    K = NordPa(N,M1,I,J,'ParField'); % total number of 1-D parameters before (including) the current one
    C = myGenRead('edProFitModStep');
    if isfield(ComVarStr,'ParStep') && length(ComVarStr.ParStep)>=max(K) && ~isempty(C) && (    (all(size(C)==1) && all(ComVarStr.ParStep(K)==C)) || (   size(C,1)*size(C,2)==size(K,1)*size(K,2) && all(  ComVarStr.ParStep(K)==reshape( C,size(ComVarStr.ParStep(K)) )  )   )    )
        return
    elseif ~isempty(C)
        K1 = NordPa(N,M1+1); % total number of 1-D parameters before M1-th including the whole of it
        if ~isfield(ComVarStr,'ParStep')
            KP=0;
        else
            KP=length(ComVarStr.ParStep);
        end
        if KP<K1
            ComVarStr.ParStep(KP+1:K1)=0;
        end
        try
            if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ComVarStr.ifDer.ifDer(1)
                if any(ComVarStr.ParStep(K)~=C);
                    ComVarStr.ifChange=true;
                end
            end
            ComVarStr.ParStep(K) = C;
        catch
            C=reshape(C,size(ComVarStr.ParStep(K)));
            if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ComVarStr.ifDer.ifDer(1)
                if any(ComVarStr.ParStep(K)~=C);
                    ComVarStr.ifChange=true;
                end
            end
            ComVarStr.ParStep(K) = C;
        end
        ComVarStr.Der1 = []; % the problem is changed, so the older design matrix (if exists) has no meaning further
        ComVarStr.Df = []; % the problem is changed, so the older covariance matrix has no meaning further
        %
        % refresh the Optimizer window if it is open
        global O_figFit;
        if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
            Optimizer('refrOptimizer');
            figure(M_figMod);
        else
            clear global O_figFit;
        end
    elseif ~isfield(ComVarStr,'ParStep') || length(ComVarStr.ParStep)<K
        ComVarStr.ParStep(K) = 0;
        C = 0;
        ComVarStr.Der1 = []; % the problem is changed, so the older design matrix (if exists) has no meaning further
        ComVarStr.Df = []; % the problem is changed, so the older covariance matrix has no meaning further
    end
    myGenWrite('edProFitModStep',C,':');
catch
    myGenWrite('edProFitModStep','-','-');
end
return

function edProFitModConstr_Callback
global M_figMod  % main figure handle
try
    global ComVarStr;
    N = getNM;
    [I,J] = getij;
    M1 = get(findobj('Tag','lstProFitMod','Parent',M_figMod),'Value');
    K = NordPa(N,M1,I,J,'ParField');
    K = reshape(K,size(K,1)*size(K,2),1);
    NK = length(K);
    C = myGenRead('edProFitModConstr');
    C0 = reshape(C,size(C,1)*size(C,2),1);
    NC = length(C0);
    if NC==0
        ComVarStr.ParCnstr(K) = {[]}; % any non-numerical input is considered as deleting
    elseif NC==1
            try
                ComVarStr.ParCnstr(K) = {C0};
            catch
                ComVarStr.ParCnstr{K} = C0;
            end
    elseif NK==NC
        for n=1:NK
            try
                ComVarStr.ParCnstr(K(n)) = {C0(n)};
            catch
                ComVarStr.ParCnstr{K(n)} = C0(n);
            end
        end
    end
    if ~isempty(C) && all(all(isnumeric(C)))
        myGenWrite('edProFitModConstr',C,':');
    else
        myGenWrite('edProFitModConstr',C,'-');
    end
 %
 % refresh the Optimizer window if it is open to activate the new constraints
 global O_figFit;
 if ~isempty(O_figFit) && ishandle(O_figFit) && ishandle(figure(O_figFit))
     Optimizer('refrOptimizer');
     figure(M_figMod);
 else
     clear global O_figFit;
 end
catch
    myGenWrite('edProFitModConstr','-','-');
end
return

function pbProModRun_Callback
%
% executes the current procedure
    global M_figMod  % main figure handle
    global ComVarStr;
    [N,M] = getNM;
    if ComVarStr.Proc(N).ifExec
        set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','off','String','WAIT'); % turn off the "Run All" button
        set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','off','String','WAIT'); % turn off the "Run" button
        try
            drawnow; % to refresh controls
        catch
            pause(0.01); % to refresh controls
        end
        [pname,pathname] = getProName(N);
        try
            if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                feval(pname); % in a case a procedure with the output to the screen is used (e.g., "clock" for the time control)
            else
                feval(pname);
            end
        catch
            feval(@cd,pathname); % changes directory to the procedure one
            try
                feval(pname);
            catch
                errordlg(strcat('The procedure No.',num2str(N),'[',pname,'] is not found in the path or erroneous'),'Path or procedure name error');
            end
            feval(@cd,ComVarStr.IniPath); % changes directory to the initial one
        end
        refrDetail(N,M);
        set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on','String','Run All'); % turn off the "Run All" button
        set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on','String','Run'); % turn off the "Run" button
    end
return

function pbProModSav_Callback
 OuModel;
 uiwait;
return

function pbProModLoad_Callback
 InModel;
 uiwait;
 global M_figMod  % main figure handle
 global ComVarStr
 %change the path to the current path
 C=what;
 C=C.path;
 ComVarStr.IniPath = C;
 clear C;
 %
 N = get (findobj('Tag','popPron','Parent',M_figMod),'Value');
 N0 = length(ComVarStr.Proc);
 C = {'-'};
 for i=1:N0
     try
         C0 = ComVarStr.Proc(i).Name;
     catch % for Octave in a case of the MAT file incompatability
         C0 = [];
         if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
             beep;
             disp('INPUT FILE ERROR: perhaps, the file format is incompatable with the current version of the software');
         end
     end
     if isempty(C0) || (iscell(C0) && isempty(C0{1}))
         break;
     end
     try
         C(i+1,1) = C0;
     catch
         C(i+1,1) = {C0};
     end
 end
 if length(C)>N
    set (findobj('Tag','popPron','Parent',M_figMod),'Value',N+1);
 else
    set (findobj('Tag','popPron','Parent',M_figMod),'Value',length(C));
 end
 set (findobj('Tag','popPron','Parent',M_figMod),'String',C);
 popPron_Callback;
 refrParaPlan; % refreshes ParaPlan window if needed
return

function pbProModRunAll_Callback
 global ComVarStr
 global M_figMod  % main figure handle
 set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','off','String','WAIT'); % turn off the "Run All" button
 set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','off','String','WAIT'); % turn off the "Run" button
 try
     drawnow; % to refresh controls
 catch
     pause(0.01); % to refresh controls
 end
 funval;
 [N,M]=getNM;
 refrDetail(N,M);
 set (findobj('Tag','pbProModRunAll','Parent',M_figMod),'Enable','on','String','Run All'); % turn on the "Run All" button
 if N>0 && ComVarStr.Proc(N).ifExec
    set (findobj('Tag','pbProModRun','Parent',M_figMod),'Enable','on','String','Run'); % turn on the "Run" button
 else
    set (findobj('Tag','pbProModRun','Parent',M_figMod),'String','Run'); % switch the "Run" button caption
 end
 if isfield(ComVarStr,'ifVref') && ~isempty(ComVarStr.ifVref) && ComVarStr.ifVref(1)
    try
        Viewer;
        feval('Viewer','pbInRefr_Callback');
    catch
    end
 end
 Optimizer('refrOptimRes');
return

function L = findCellTxt(fname,paname)
% Finds a text paname within a cell of the array fname.
% Output L is an index of the 1-st cell containing paname.
% If no cell contains paname, then output L=0.
% if fname is not a cell but just a string coinsiding with paname, then
% L=1
 if iscell(fname)
    L0 = length(fname);
    if L0>0
        for L=1:L0
            try
                fn = fname{L};
            catch
                fn = fname(L);
            end
            if strcmp (paname,fn);
                return;
            end
        end
        L=0;
    else
        L=0;
    end
    return
elseif ischar(fname) && strcmp(fname,paname)
    L = 1;
else
    L = 0;
end
return

    

function Val=getVal(N,M,i,j)
% gets value of the (i,j) element of the M-th papameter belonging to the N-th procedure
% an absent input parameter N or M is implied to be equal 1
% an absent input parameter i or j is implied to be equal the total set of indexes of the parameter
global ComVarStr;
%
if nargin<2 || isempty(M) || any(any(~isreal(M)))
    M=1;
end
if nargin==0 || isempty(N) || any(any(~isreal(N)))
    N=1;
end
%
try
    pname   = getProName(N);
    parname = ComVarStr.Proc(N).Par(M).Name{1};
    Val = ComVarStr.(pname).(parname);
    if ischar(Val)
        return;
    end
%    Val = getfield(ComVarStr,pname,parname);
    %
    if nargin<4 || isempty(j) || any(any(~isreal(j)))
        j=1:size(Val,2);
    end
    if nargin<3 || isempty(i) || any(any(~isreal(i)))
        i=1:size(Val,1);
    end
    %
    Val = Val(i,j);
catch
    Val='-';
end
return

function setVal(Val,N,M,i,j)
% sets value of the (i,j) element of the M-th papameter belonging to the N-th procedure
% i=0 and/or j=0 mean that an entire subarray is to be set to Val
% an absent input Val is implied to be equal []
% an absent input N or M is implied to be equal 1
% an absent input i or j is implied to be equal 0
global M_figMod  % main figure handle
global ComVarStr;
%
if nargin<5 || isempty(j) || any(any(~isnumeric(j)))
    j=0;
end
if nargin<4 || isempty(i) || any(any(~isnumeric(i)))
    i=0;
end
if nargin<3 || isempty(M) || any(any(~isnumeric(M)))
    M=1;
end
if nargin<2 || isempty(M) || any(any(~isnumeric(M)))
    N=1;
end
if nargin==0
    Val=[];
end
if ~isempty(Val) && ~isscalar(Val) && numel(Val)~=numel(i)*numel(j) && all(i~=0) && all(j~=0)
    beep;
    errordlg('The indices range and the values range do not coincide!','INCORRECT INPUT');
    set(findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
    return
end
%
if isfield(ComVarStr,'Proc') && length(ComVarStr.Proc)>=N && isfield(ComVarStr.Proc(N),'Par') && length(ComVarStr.Proc(N).Par)>=M
    try
        pname   = getProName(N);
        try
            paname = ComVarStr.Proc(N).Par(M).Name{1};
        catch
            paname = ComVarStr.Proc(N).Par(M).Name;
        end
        if ~isempty(Val)
            D1 =str2num(get(findobj('Tag','edProModDim1','Parent',M_figMod),'String'));
            D2 =str2num(get(findobj('Tag','edProModDim2','Parent',M_figMod),'String'));
            try
                Val0 = double(ComVarStr.(pname).(paname));
%                Val0 = double(getfield(ComVarStr,pname,paname));
                if size(Val0,1)>D1
                    Val0(D1+1:end,:)=[];
                end
                if size(Val0,2)>D2
                    Val0(:,D2+1:end)=[];
                end
            catch
                try
                    Val0 = zeros(D1,D2);
                catch
                    Val0=[];
                end
            end
            %
            % reshape Val if it is a vector and the vector input is expected
            if all(i~=0)
                li=length(i);
            else
                li=D1;
            end
            if all(j~=0)
                lj=length(j);
            else
                lj=D2;
            end
            if size(Val,1)==lj && size(Val,2)==li && li~=lj
                Val=Val';
            end
            %
            %try to get a current value of the parameter
            if all(i>0) && all(j>0) && ~isempty(Val)
                Val0(i,j) = Val;
            elseif  all(i>0) && all(j>0)
                if all(i==1) && size(Val0,1) ==1
                    Val0(:,j)=[];
                elseif all(j==1) && size(Val0,2) ==1
                    Val0(i,:)=[];
                end
            elseif all(i>0)
                Val0(i,:) = Val;
            elseif all(j>0)
                Val0(:,j) = Val;
            else
                Val0 = Val;
            end
         else
             Val0=[];
         end
        ComVarStr.(pname).(paname)=Val0;
%        ComVarStr = setfield (ComVarStr,pname,paname,Val0);
    catch
        beep;
        errordlg('Perhaps, the indices range and the values range do not coincide!','INCORRECT INPUT');
        set(findobj('Tag','edProModVal','Parent',M_figMod),'String','-');
    end
end
return

function [ModNames,D1,D2] = findModName(ifAdd,N)
% finds parameters for the N-th procedure
% within the global structure ComVarStr
% and adds them into the structure if ifAdd
% optional output D1 and D2 are vectors of 1-st and 2-nd matrix dimensions
% of the corresponding parameters
 global ComVarStr;
 ModNames = [];
 try
    if nargin<2 || any(any(~isnumeric(N)))
        N=1;
        if nargin==0 || isempty(ifAdd)
            ifAdd=false;
        end
    end
    pname = getProName(N);
    C = ComVarStr.(pname);
%    C = getfield(ComVarStr,pname);
%    B = fields(C)
    try
        B = fieldnames(C);
    catch
        B = fields(C); % older version
    end
    m = length(B);
    if m>0
        D1=zeros(m,1); % initialize dimensions
        D2=zeros(m,1);
        for i=1:m
            C = B{i};
            if ~ischar(C)
                break;
            end
            ModNames{i} = C;
            if ifAdd || nargout>1
                try
                    A = ComVarStr.(pname).(C);
%                    A = getfield(ComVarStr,pname,C);
                    D1(i) = size(A,1);
                    if isempty(D1(i))
                        D1(i)=0;
                    end
                    D2(i) = size(A,2);
                    if isempty(D2(i))
                        D2(i)=0;
                    end
                catch
                    D1(i)=-1;
                    D2(i)=-1;
                end
            end
        end
        if i<=m
            m=i;
        end
    end
    if ifAdd && ~isempty(ModNames)
        try
            N1 = length(ComVarStr.Proc(N).Par);
        catch
            N1 = 0;
        end
        l = N1; % current index of the global parameter
        for k=1:m
            nn = 0;
            if N1>0
                for i=1:N1
                    try
                        if strcmp(ComVarStr.Proc(N).Par(i).Name,ModNames{k});
                            nn=i;
                            break;
                        end
                    catch
                    end
                end
            end
            if nn==0
                l=l+1;
                ComVarStr.Proc(N).Par(l).Name=ModNames(k);
                ComVarStr.Proc(N).Par(l).Dim1=D1(k);
                ComVarStr.Proc(N).Par(l).Dim2=D2(k);
            end
        end
    end
 catch
 end
return

function [N,M,paname] = getNM
% gets current indexes of the procedure and of the parameter
% and (optionally) the name of the parameter
     global M_figMod  % main figure handle
     N = get(findobj('Tag','popPron','Parent',M_figMod),'Value') - 1;
     if isempty(N)
         N=0;
         set(findobj('Tag','popPron','Parent',M_figMod),'Value',1);
     end
     if nargout<=1
         return
     end
     M = get(findobj('Tag','lstProMods','Parent',M_figMod),'Value');
     if isempty(M)
         M=0;
         set(findobj('Tag','lstProMods','Parent',M_figMod),'Value',1);
     end
     paname = get(findobj('Tag','lstProMods','Parent',M_figMod),'String');
     try
        paname = paname{M};
     catch
%        paname = paname(M);
     end
     if strcmp(paname,'-')
        M=0;
     end
return

function [i,j] = getij
% gets current indexes
% the case of the ':' in the uicontrol produces output array of entire Dim;
% any other non-numeric input produces []
    global M_figMod  % main figure handle
    i = get(findobj('Tag','edProModInd1','Parent',M_figMod),'String');
    j = get(findobj('Tag','edProModInd2','Parent',M_figMod),'String');
    if strcmp (i,':')
        D = myGenRead('edProModDim1');
        i=1:D;
    else
        i=str2num(i);
    end
    if strcmp (j,':')
        D = myGenRead('edProModDim2');
        j=1:D;
    else
        j=str2num(j);
    end
return

function K = NordPa(N,M,I,J,Fin)
% Finds ordinal number of the (I,J)-th element of the M-th variable parameter of the N-th procedure
% in ComVarStr.ParField or ComVarStr.ResField, when Fin is 'ParField' or 'ResField'.
% If only N and M present at the input, the result is the total number of
% 1-D variable elements below (excluding) the M-th one of the N-th
% procedure
try
    global ComVarStr;
    if nargin<5 || isempty(Fin)
        Fin = 'ParField';
    end
    if nargin<4 || isempty(J)
        J=1;
    end
    if nargin<3 || isempty(I)
        I=0;
    end
    pname = getProName(N);
    if strcmp(Fin,'ParField')
        K = length(getpara(N,M-1));
        fname = ComVarStr.ParField{N}{M};
    elseif strcmp(Fin,'ResField')
        K = length(getresult(N,M-1));
        fname = ComVarStr.ResField{N}{M};
    end
    C = ComVarStr.(pname).(fname);
%    C = getfield(ComVarStr,pname,fname);
    D1 = size(C,1);
    D2 = size(C,2);
    k = 1;
    K0 = K;
    for j=1:length(J)
        for i=1:length(I)
            K(k) = K0 + D1*(J(j)-1) + I(i);
            k = k+1;
        end
    end
catch
end
return

function [pname,pathname] = getProName(N)
% gets the short name "pname" of the N-th procedure in the popup list
% optionally gets the path to the procedure as a "pathname"
global M_figMod  % main figure handle
if nargin==0
    N=get(findobj('Tag','popPron','Parent',M_figMod),'Value')-1;
end
if N==0
    pname='';
    return
end
try
 pname = get(findobj('Tag','popPron','Parent',M_figMod),'String');
 n1 = max(strfind(pname{N+1},'\'));
 if isempty(n1)
     n1=0;
 end
 n1=n1+1;
 n2 = max(strfind(pname{N+1},'.'));
 if isempty(n2)
     n2=length(pname{N+1})+1;
 end
 n2=n2-1;
 if n1>1
     pathname = pname{N+1}(1:n1-1);
 else
     pathname='.';
 end
 pname = pname{N+1}(n1:n2);
catch
    pname='';
    pathname='';
end
return


function clearglMod
 global M_figMod     % main figure handle
 clear global M_figMod;
return

function varargout = Mod_ResizeFcn(h, varargin)
 pause(0.1);
 pofigMod = get(h,'Position');
 if ~isempty(find(pofigMod(3:4)<=0, 1))
    return;
 end

 set (findobj('Tag','lstProFitMod','Parent',h),       'Position',[pofigMod(3)*.05 pofigMod(4)*.3 pofigMod(3)*.13 pofigMod(4)*.45]);
 set (findobj('Tag','lstProResMod','Parent',h),       'Position',[pofigMod(3)*.82 pofigMod(4)*.14 pofigMod(3)*.13 pofigMod(4)*.61]);
 set (findobj('Tag','lstProMods','Parent',h),         'Position',[pofigMod(3)*.27 pofigMod(4)*.14 pofigMod(3)*.21 pofigMod(4)*.61]);
 set (findobj('Tag','popPron','Parent',h),            'Position',[pofigMod(3)*.05 pofigMod(4)*.86 pofigMod(3)*.9 pofigMod(4)*.1]);
 set (findobj('Tag','edPron','Parent',h),             'Position',[pofigMod(3)*.05 pofigMod(4)*.85 pofigMod(3)*.3 pofigMod(4)*.05]);
 set (findobj('Tag','pbPronAd','Parent',h),           'Position',[pofigMod(3)*.37 pofigMod(4)*.85 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','pbPronDel','Parent',h),          'Position',[pofigMod(3)*.43 pofigMod(4)*.85 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','pbPronBro','Parent',h),          'Position',[pofigMod(3)*.51 pofigMod(4)*.85 pofigMod(3)*.15 pofigMod(4)*.05]);
 set (findobj('Tag','edPronInf','Parent',h),          'Position',[pofigMod(3)*.7 pofigMod(4)*.85 pofigMod(3)*.25 pofigMod(4)*.05]);
 set (findobj('Tag','edProModDscr','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.71 pofigMod(3)*.23 pofigMod(4)*.04]);
 set (findobj('Tag','txtProModDim','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.65 pofigMod(3)*.23 pofigMod(4)*.04]);
 set (findobj('Tag','edProModDim1','Parent',h),       'Position',[pofigMod(3)*.503 pofigMod(4)*.61 pofigMod(3)*.1 pofigMod(4)*.04]);
 set (findobj('Tag','edProModDim2','Parent',h),       'Position',[pofigMod(3)*.627 pofigMod(4)*.61 pofigMod(3)*.1 pofigMod(4)*.04]);
 set (findobj('Tag','txtProModInd','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.55 pofigMod(3)*.23 pofigMod(4)*.04]);
 set (findobj('Tag','edProModInd1','Parent',h),       'Position',[pofigMod(3)*.503 pofigMod(4)*.51 pofigMod(3)*.1 pofigMod(4)*.04]);
 set (findobj('Tag','edProModInd2','Parent',h),       'Position',[pofigMod(3)*.627 pofigMod(4)*.51 pofigMod(3)*.1 pofigMod(4)*.04]);
 set (findobj('Tag','txtProModVal','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.45 pofigMod(3)*.23 pofigMod(4)*.04]);
 set (findobj('Tag','edProModVal','Parent',h),        'Position',[pofigMod(3)*.501 pofigMod(4)*.41 pofigMod(3)*.23 pofigMod(4)*.04]);
 set (findobj('Tag','ckbProModGet','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.35 pofigMod(3)*.1 pofigMod(4)*.04]);
 set (findobj('Tag','pbProModGet','Parent',h),        'Position',[pofigMod(3)*.6 pofigMod(4)*.36 pofigMod(3)*.05 pofigMod(4)*.04]);
 set (findobj('Tag','pbProModPut','Parent',h),        'Position',[pofigMod(3)*.68 pofigMod(4)*.36 pofigMod(3)*.05 pofigMod(4)*.04]);
 set (findobj('Tag','txtProModValGlo','Parent',h),    'Position',[pofigMod(3)*.501 pofigMod(4)*.3 pofigMod(3)*.115 pofigMod(4)*.05]);
 set (findobj('Tag','edProModValGlo','Parent',h),     'Position',[pofigMod(3)*.62 pofigMod(4)*.31 pofigMod(3)*.11 pofigMod(4)*.04]);
 set (findobj('Tag','pbProModDelNew','Parent',h),     'Position',[pofigMod(3)*.501 pofigMod(4)*.21 pofigMod(3)*.11 pofigMod(4)*.04]);
 set (findobj('Tag','pbProModAdNew','Parent',h),      'Position',[pofigMod(3)*.62 pofigMod(4)*.21 pofigMod(3)*.11 pofigMod(4)*.04]);
 set (findobj('Tag','txtProModNew','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.14 pofigMod(3)*.115 pofigMod(4)*.05]);
 set (findobj('Tag','edProModNew','Parent',h),        'Position',[pofigMod(3)*.62 pofigMod(4)*.14 pofigMod(3)*.11 pofigMod(4)*.05]);
 set (findobj('Tag','txtProMod','Parent',h),          'Position',[pofigMod(3)*.27 pofigMod(4)*.75 pofigMod(3)*.21 pofigMod(4)*.03]);
 set (findobj('Tag','txtProFitMod','Parent',h),       'Position',[pofigMod(3)*.05 pofigMod(4)*.75 pofigMod(3)*.13 pofigMod(4)*.03]);
 set (findobj('Tag','txtProResMod','Parent',h),       'Position',[pofigMod(3)*.82 pofigMod(4)*.75 pofigMod(3)*.13 pofigMod(4)*.03]);
 set (findobj('Tag','txtProDetMod','Parent',h),       'Position',[pofigMod(3)*.501 pofigMod(4)*.75 pofigMod(3)*.23 pofigMod(4)*.03]);
 set (findobj('Tag','ckbExeProMod','Parent',h),       'Position',[pofigMod(3)*.05 pofigMod(4)*.8 pofigMod(3)*.23 pofigMod(4)*.03]);
 set (findobj('Tag','pbProFitAd','Parent',h),         'Position',[pofigMod(3)*.2 pofigMod(4)*.5 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','pbProFitDel','Parent',h),        'Position',[pofigMod(3)*.2 pofigMod(4)*.4 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','pbProResAd','Parent',h),         'Position',[pofigMod(3)*.75 pofigMod(4)*.5 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','pbProResDel','Parent',h),        'Position',[pofigMod(3)*.75 pofigMod(4)*.4 pofigMod(3)*.05 pofigMod(4)*.05]);
 set (findobj('Tag','edProFitModStep','Parent',h),    'Position',[pofigMod(3)*.05 pofigMod(4)*.2 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','edProFitModConstr','Parent',h),  'Position',[pofigMod(3)*.05 pofigMod(4)*.14 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','txtProFitModStep','Parent',h),   'Position',[pofigMod(3)*.185 pofigMod(4)*.2 pofigMod(3)*.08 pofigMod(4)*.04]);
 set (findobj('Tag','txtProFitModConstr','Parent',h), 'Position',[pofigMod(3)*.185 pofigMod(4)*.14 pofigMod(3)*.08 pofigMod(4)*.04]);
 set (findobj('Tag','pbProModRunAll','Parent',h),     'Position',[pofigMod(3)*.05 pofigMod(4)*.05 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','pbProModRun','Parent',h),        'Position',[pofigMod(3)*.27 pofigMod(4)*.05 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','pbProModSav','Parent',h),        'Position',[pofigMod(3)*.47 pofigMod(4)*.05 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','pbProModLoad','Parent',h),       'Position',[pofigMod(3)*.62 pofigMod(4)*.05 pofigMod(3)*.13 pofigMod(4)*.05]);
 set (findobj('Tag','pbProModOK','Parent',h),         'Position',[pofigMod(3)*.82 pofigMod(4)*.05 pofigMod(3)*.13 pofigMod(4)*.05]);
 
% set (findobj('Tag',''),      'Position',[]);

 return