function y=collectparam(NBl1,NBl2)
% Puts the contents of the parameters fields into a single- or double-indexed cell y
%
% USAGE: y=collectparam(NBl1,NBl2)
%
% Uses global structure ComVarStr.
%     INPUT
% NBl1 - the starting block of the model to be considered; default NBl1=1;
% NBl2 - the final block of the model to be computed; default:
%        in a case NBl1 is the last argument in the input list and is correct, NBl2=NBl1;
%        otherwise NBl2=total number of the model blocks;
%     OUTPUT
% y    - single- or double-indexed cell containing parameter values of the blocks from NBl1 to NBl2.
global ComVarStr;
try
%
    y=[];
    k0=length(ComVarStr.Proc);
    if nargin>0
        if nargin==1 && ~isempty(NBl1) && isreal(NBl1) && NBl1>=1
            NBl2=round(NBl1(1));
        elseif nargin==1 || isempty(NBl2) || ~isreal(NBl2) || NBl2>k0
            NBl2=k0;
        else
            NBl2=round(NBl2(1));
        end
        if isempty(NBl1) || ~isreal(NBl1) || NBl1<1
            NBl1=1;
        else
            NBl1=round(NBl1(1));
        end
        k0=NBl2-NBl1+1;
    else
        NBl1=1;
%        NBl2=k0;
    end
    %
    y=cell(k0,1);
    for k=1:k0
        kk=k+NBl1-1;
        if isempty(ComVarStr.ParField{kk})
            continue;
        end
        fn = getProNm(kk);
        if iscell(ComVarStr.ParField{kk})
            n0=length(ComVarStr.ParField{kk});
            y{k}=cell(n0,1);
            for n=1:n0
                try
                    y0 = ComVarStr.(fn).(ComVarStr.ParField{kk}{n});
%                    y0 = getfield(ComVarStr,fn,ComVarStr.ParField{kk}{n});
                catch
                    continue;
                end
                y{k}{n}=y0; % cell to collect initial values of the parameters
            end
        else
            try
                y0 = ComVarStr.(fn).(ComVarStr.ParField{kk});
%                y0 = getfield(ComVarStr,fn,ComVarStr.ParField{kk});
            catch
                continue;
            end
            y{k}=y0; % cell to collect initial values of the parameters
        end
    end
catch
    y=[];
end
return