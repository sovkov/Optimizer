function [pname,pathname] = getProNm(N)
% Gets the short name "pname" of the N-th procedure in the ComVarStr global structure; optionally gets the path to the procedure as a "pathname"
%
% USAGE: [pname,pathname] = getProNm(N)
%
global ComVarStr;
if nargin==0
    N = length(ComVarStr.Proc);
end
if N==0
    pname='';
    try
        pathname = ComVarStr.IniPath;
    catch
        pathname = '.';
    end
    return
end
try
    try
        pname = ComVarStr.Proc(N).Name;
    catch
        pname = '';
        try
            pathname = ComVarStr.IniPath;
        catch
            pathname = '.';
        end
        return
    end
    while iscell(pname)
        pname=pname{1};
    end
 n1 = max(strfind(pname,'\'));
 if isempty(n1)
     n1=0;
 end
 n1=n1+1;
 n2 = max(strfind(pname,'.'));
 if isempty(n2)
     n2=length(pname)+1;
 end
 n2=n2-1;
 if nargout>1
    if n1>1
         pathname = pname(1:n1-1);
    else
        try
            pathname = ComVarStr.IniPath;
        catch
            pathname = '.';
        end
    end
 end
 pname = pname(n1:n2);
catch
    pname='';
    try
        pathname = ComVarStr.IniPath;
    catch
        pathname = '.';
    end
end
return
