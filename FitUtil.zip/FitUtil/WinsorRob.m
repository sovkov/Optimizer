function phi=WinsorRob(x,s)
% Robust estimator by Winsor
% phi = x^2, x<=s
% phi = s^2, x>s
%
% USAGE: phi=WinsorRob(x,s)
%
% INPUT
% x   - argument of the function
% s   - an absolute value of point coordinates where the function is
%       switched from the quadratic dependence to the constant dependence;
%       the less lambda the stronger is the robustness;
%       the default value is s=2;
%       if s does not exist at the input then the default value is used
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(s) || any(any(~isnumeric(s)))
    s=2; % default value
end
if s<0
    phi=[];
    return
end
%
phi=abs(x);
isg=find(phi>=s);
isl=find(phi<s);
if ~isempty(isl) phi(isl)=phi(isl).^2; end
if ~isempty(isg) phi(isg)=s^2; end
return
