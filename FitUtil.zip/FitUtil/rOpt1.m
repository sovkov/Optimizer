% Install Optimizer as described in the manual, add it to path.

clc;

disp('------------------------------------------------------------------------- ');
disp(' ');
disp('              M O D E L I N G  A N D   O P T I M I Z I N G ');
disp(' ');
disp(' ');
disp('                         Optimizer version 1.0');
disp(' ');
disp(' ');
disp('                         by Vladimir B. Sovkov');
disp(' ');
disp('         St. Petersburg State University, St. Petersburg, Russia,');
disp('                     Shanxi University, Taiyuan, China');
disp(' ');
disp(' ');
disp('The manuals: /DOC/FitutilEN.pdf (English) and /DOC/FitutilRU.pdf (Russian)');
disp(' ');
disp(' ');
disp('                      St. Petersburg, Taiyuan - 2019');
disp(' ');
disp('------------------------------------------------------------------------- ');
disp(' ');
disp(' ');

try
    load LinAp.MOT -MAT;
    load gong.mat;
    sound(y(round(end/6):-1:1));
    disp('The windows ''Optimizer,'' ''Modeler,'' and ''Viewer'' are going to be shown');
    disp('with the results of the linear approximation of a sample ''experimental'' dependence.');
    disp(' ');
    disp('The user can alter the parameters randomly by pressing ''Shake'' in the ''Optimizer'' window,');
    disp('recompute the model by pressing ''Run All'' in the ''Modeler'' window,');
    disp('then return to the optimized parameters by pressing ''Iterations'' in the ''Optimizer'' window.');
    disp(' ');
    disp('Any other check of the package functionality is encouraged!');
    disp(' ');
    disp('Press any key to continue');
    pause;
    Modeler;
    Optimizer;
    Optimizer('refrOptimizer');
    Viewer;
    Viewer('pbInRefr_Callback');
    sound(y);
    disp(' ');
    disp('ENJOY!');
catch
    beep;
    disp('The code is not executed');
    disp('Install ''Optimizer'' as described in the manual, add it to path');
end