function phi=WelschRob(x,c2)
% Robust estimator by Welsch
% phi = c2(1-exp(-z^2/c2))
%
% USAGE: phi=WelschRob(x,c2)
%
% INPUT
% x      - argument of the function
% c2     - parameter of the function;
%          the less c2 the stronger is the robustness;
%          default value is 18;
%          if c2 does not exist at the input then the default value is
%          adopted
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(c2) || any(any(~isnumeric(c2)))
    c2=18; % default value
end
if c2<=0
    phi=[];
    return
end
%
phi=c2 .* ( 1 - exp(-x.^2./c2) );
%
return