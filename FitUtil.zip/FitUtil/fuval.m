function [ierr,x,y0]=fuval(NBl,CVS,Prc)
% Computes the value of the multidimensional function
%
% USAGE: [ierr,x,y0]=fuval(ifNames,NBl,CVS,Prc)
%
% All input parameters are taken from the global structure ComVarStr
% (see comments in the "initialization" section below for structure field descriptions)
%  INPUT
% NBl(1)  - the starting block of the model to be computed; default NBl(1)=1;
% NBl(2)  - the final block of the model to be computed; default:
%           in a case NBl(1) is the last argument in the input list and is correct, NBl(2)=NBl(1);
%           otherwise NBl(2)=total number of the model blocks;
% CVS     - structure replacing ComVarStr if needed; default CVS-ComVarStr;
% Prc     - a vector of structures with the short names of all the blocks of the model
%           (can be constructed with getProNm function---see a call from funval as a sample);
%  OUTPUT
% y0   - a column array of the function values;
% x    - single- or double-indexed cell containing parameter values of
%        the blocks from NBl(1) to NBl(2) after their execution.
% ierr - error flag
%        =0   everything is OK
%        >0   non-critical error flag of the last call of the procedure for computing
%             function values; the computations are proceeded
%        =100 no ierr flag is produced by the procedure for computing the
%             function to be differentiated; the computations are done
%        <0   something was wrong; the computations are seized

%
% initialization
%
global ComVarStr

ierr=0;
y0=[];
x=[];

% if isfield(ComVarStr,'ifError') && ~~isempty(ComVarStr.ifError) && ComVarStr.ifError(1)
%     ierr=-2000;
%     return
% end

if nargin>=2 && ~isempty(CVS)
    ComVarStr=CVS;
end

if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
    ifDisp = true;
else
    ifDisp = false;
end

try
    k = length(ComVarStr.Proc);
    if k==0
        ierr = 2;
        return
    end
catch
    ierr = 3;
    return
end
if nargin==0 || isempty(NBl)
    NBl=[1 k];
end
if isscalar(NBl)
    if ~isreal(NBl) || NBl<1
        NBl=[1 k];
    else
        NBl=[round(NBl) round(NBl)];
    end
else
    if ~isreal(NBl(1)) || NBl(1)<1
        NBl(1)=1;
    else
        NBl(1)=round(NBl(1));
    end
    if ~isreal(NBl(2)) || NBl(2)>k
        NBl(2)=k;
    else
        NBl(2)=round(NBl(2));
    end
end
%
path0 = ComVarStr.IniPath;
if NBl(1)==1
    ComVarStr.Der1=[]; % in a case there were non-empty values within it before running any procedure
    ComVarStr.inpCov=[]; % in a case there were non-empty values within it before running any procedure
    if ~isfield(ComVarStr,'ifClear')|| isempty(ComVarStr.ifClear) || ComVarStr.ifClear(1)
        putresults([],Prc); % to clear all the result fields
    end
end
for i=NBl(1):NBl(2)
    % From!
    n = length(ComVarStr.Proc(i).Par);
    for j=1:n
        try
            FromF = ComVarStr.Proc(i).Par(j).From;
            if ~isempty(FromF)
                if (length(FromF)==1 && FromF=='-')
                    Val=[];
                else
%                    Val = str2num(FromF); % This one does not work correctly in Octave! So, it is reconstructed into a more elaborated route.
%                    if isempty(Val)
                        np = strfind(FromF,'.');
                        if isempty(np)
                            if length(FromF)==1 && FromF=='-'
                                Val=[];
                            else
                              if isfield(ComVarStr,FromF) && isnumeric(ComVarStr.(FromF))
                                Val = ComVarStr.(FromF);
%                                Val = getfield(ComVarStr,FromF);
                              elseif ~exist(FromF,'file')
                                Val = str2num(FromF);
                                if isempty(Val)
                                  Val=NaN;
                                end
                              else
                                Val = NaN;
                              end
                            end
                        elseif length(np)==1 && np~=1 && np~=length(FromF)
                          if isfield(ComVarStr,FromF(1:np(1)-1)) && isfield(ComVarStr.(FromF(1:np(1)-1)),FromF(np(1)+1:length(FromF))) && isnumeric(ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:length(FromF))))
                            Val = ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:length(FromF)));
%                            Val = getfield(ComVarStr,FromF(1:np(1)-1),FromF(np(1)+1:length(FromF)));
                          elseif ~exist(FromF(1:np(1)-1),'file')
                            Val = str2num(FromF);
                            if isempty(Val)
                              Val=NaN;
                            end
                          else
                            Val = NaN;
                          end
                        elseif length(np)==2 && np(1)~=1 && np(2)~=length(FromF)
                          if isfield(ComVarStr,FromF(1:np(1)-1)) && isfield(ComVarStr.(FromF(1:np(1)-1)),FromF(np(1)+1:np(2)+1)) && isfield(ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:np(2)+1)),(FromF(np(2)+1:length(FromF)))) && isnumeric(ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:np(2)+1)).(FromF(np(2)+1:length(FromF))))
                            Val = ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:np(2)+1)).(FromF(np(2)+1:length(FromF)));
%                            Val = getfield(ComVarStr,FromF(1:np(1)-1),FromF(np(1)+1:np(2)+1),FromF(np(2)+1:length(FromF)));
                          elseif ~exist(FromF(1:np(1)-1),'file')
                            Val = str2num(FromF);
                            if isempty(Val)
                              Val=NaN;
                            end
                          else
                            Val = NaN;
                          end
                        elseif ~exist(FromF(1:np(1)-1),'file')
                            Val = str2num(FromF);
                            if isempty(Val)
                              Val=NaN;
                            end
                        else
                          Val = NaN;
                        end
%                    end
                end
                if isempty(Val) || any(any(~isnan(Val)))
                  try
                      parname = ComVarStr.Proc(i).Par(j).Name{1}; % parameter name
                  catch
                      parname = ComVarStr.Proc(i).Par(j).Name; % parameter name
                  end
                  D1 = ComVarStr.Proc(i).Par(j).Dim1;
%                  D1 = getfield(ComVarStr.Proc(i).Par(j),'Dim1');
                  D2 = ComVarStr.Proc(i).Par(j).Dim2;
%                  D2 = getfield(ComVarStr.Proc(i).Par(j),'Dim2');
                  if all(size(Val)==1) && (D1>1 || D2>1)
                      Val = Val*ones(D1,D2);
                  end
                  ComVarStr.(Prc(i).Name).(parname)=Val;
%                  ComVarStr = setfield(ComVarStr,Prc(i).Name,parname,Val);
                elseif ifDisp
                  beep;
                  disp('-');
                  disp(strcat('fuval WARNING: incorrect ''FROM'' field ''',FromF,''' in the procedure No.',num2str(i),' ''',ComVarStr.Proc(i).Name,''', parameter ''',ComVarStr.Proc(i).Par(j).Name,'''; no data transfer is done'));
                  disp('-');
                end
            end
        catch
        end
    end
    %
    % execute
    if isfield(ComVarStr.Proc(i),'ifExec') && ~isempty(ComVarStr.Proc(i).ifExec) && ComVarStr.Proc(i).ifExec(1)
        ifDer = isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && ComVarStr.ifDer.ifDer(1); % can change between calls of different blocks
        try
            if ifDisp % in a case a procedure with the output to the screen is used (e.g., "clock" for the time control)
                feval(Prc(i).Name) % will not work if Prc(i).Name is not in the matlab path or the current directory
            else
                feval(Prc(i).Name); % will not work if Prc(i).Name is not in the matlab path or the current directory
            end
        catch
            if ~strcmp(path0,Prc(i).path) % change directory is a slow command, so its use should be avoided if possible
                if ~strcmp(path0,ComVarStr.IniPath)
                    feval(@cd,ComVarStr.IniPath); % changes directory to the initial one
                end
                feval(@cd,Prc(i).path); % changes directory to the procedure one
                path0 = Prc(i).path;
            end
            try
                feval(Prc(i).Name); % execute the current procedure
            catch
%                 button = questdlg(strcat('procedure No.',num2str(i),' [',Prc(i).Name,']',' is not found in the paths or erroneous. Continue computing?'),'Path or procedure name error','Yes','No','No');
%                 if isequal(button,'No')
%                     if ~strcmp(path0,ComVarStr.IniPath)
%                         feval(@cd,ComVarStr.IniPath); % changes directory to the initial one
%                     end
%                     ierr=i;
%                     return;
%                 end
                %%%%%%%%%%%%%%
                beep;
                disp(strcat('procedure No.',num2str(i),' [',Prc(i).Name,']',' is not found in the paths or erroneous. Computation is terminated.'));
                if ~strcmp(path0,ComVarStr.IniPath)
                    feval(@cd,ComVarStr.IniPath); % changes directory to the initial one
                end
                ierr=-i;
%                return
                %%%%%%%%%%%%%%
            end
        end
        if isfield(ComVarStr,'ifError') && ~isempty(ComVarStr.ifError) && ComVarStr.ifError(1)
            ierr=-1000;
            if ifDisp
                beep;
                disp(strcat('FUVAL: the computation is broken due to an error of a modeling program No.',num2str(i),' [',Prc(i).Name,']'));
                beep;
            end
            if ~isfield(ComVarStr,'ifClear') || isempty(ComVarStr.ifClear) || ComVarStr.ifClear(1)
                putresults(Inf);
            end
            if ifDer
                ComVarStr.Der1=[];
                ComVarStr.locDer=[];
            end
            break;
        end
        %%%
        if ifDer
            try
                IERR = makeDer(i);
            catch
                IERR=-2;
            end
            if IERR<0
                ComVarStr.Der1=[];
                ComVarStr.locDer=[];
                ComVarStr.ifDer.ifDer=false;
                if ifDisp
                    beep;
                    disp(strcat('FUVAL WARNING: incorrect Der constructed from a modeling program No.',num2str(i),' [',Prc(i).Name,']'));
                    disp('switch to the finite-difference scheme');
                    beep;
                end
            end
        end
        %%%
    end
    if nargout>=2
        try
            x.(Prc(i).Name)=ComVarStr.(Prc(i).Name);
%            x = setfield(x,Prc(i).Name,getfield(ComVarStr,Prc(i).Name));
        catch
        end
   end
end
if ~strcmp(path0,ComVarStr.IniPath)
    feval(@cd,ComVarStr.IniPath); % changes directory to the initial one
end
%
if nargout>=3
    y0=getresults(NBl(2));
    if NBl(1)>1
        k1=length(getresults(NBl(1)-1));
        if k1>0
            y0(1:k1)=0;
        end
    end
    %
end
return
