function fuget(NBl1,NBl2,Prc)
% Executes "GET FROM" data transfer without executing model blocks themselves for the blocks from NBl1 to NBL2
%
% USAGE: fuget(NBl1,NBl2,CVS,Prc)
%
% Addresses the global structure ComVarStr
%     INPUT
% NBl1    - the starting block of the model to be computed; default NBl1=1;
% NBl2    - the final block of the model to be computed; default:
%           in a case NBl1 is the last argument in the input list and is correct, NBl2=NBl1;
%           otherwise NBl2=total number of the model blocks;
% Prc     - a vector of structures with the short names of all the blocks of the model;

global ComVarStr

k = length(ComVarStr.Proc);
if nargin==1 && ~isempty(NBl1) && isreal(NBl1) && NBl1>=1
    NBl2=round(NBl1(1));
elseif nargin<=1 || isempty(NBl2) || ~isreal(NBl2) || NBl2>k
    NBl2=k;
else
    NBl2=round(NBl2(1));
end
if nargin==0 || isempty(NBl1) || ~isreal(NBl1) || NBl1<1
    NBl1=1;
else
    NBl1=round(NBl1(1));
end
%
for i=NBl1:NBl2
    %
    % From!
    n = length(ComVarStr.Proc(i).Par);
    for j=1:n
        try
            FromF = ComVarStr.Proc(i).Par(j).From;
            if ~isempty(FromF)
                np = strfind(FromF,'.');
                if isempty(np)
                    if length(FromF)==1 && FromF=='-'
                        Val=[];
                    else
                        Val = ComVarStr.(FromF);
%                        Val = getfield(ComVarStr,FromF);
                    end
                elseif length(np)==1
                    Val = ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:length(FromF)));
%                    Val = getfield(ComVarStr,FromF(1:np(1)-1),FromF(np(1)+1:length(FromF)));
                elseif length(np)==2
                    Val = ComVarStr.(FromF(1:np(1)-1)).(FromF(np(1)+1:np(2)+1)).(FromF(np(2)+1:length(FromF)));
%                    Val = getfield(ComVarStr,FromF(1:np(1)-1),FromF(np(1)+1:np(2)+1),FromF(np(2)+1:length(FromF)));
                else
%                    ierr=-1;
                    return
                end
                try
                    parname = ComVarStr.Proc(i).Par(j).Name{1}; % parameter name
                catch
                    parname = ComVarStr.Proc(i).Par(j).Name; % parameter name
                end
                D1 = ComVarStr.Proc(i).Par(j).Dim1;
%                D1 = getfield(ComVarStr.Proc(i).Par(j),'Dim1');
                D2 = ComVarStr.Proc(i).Par(j).Dim2;
%                D2 = getfield(ComVarStr.Proc(i).Par(j),'Dim2');
                if all(size(Val)==1) && (D1>1 || D2>1)
                    Val = Val*ones(D1,D2);
                end
                ComVarStr.(Prc(i).Name).(parname)=Val;
%                ComVarStr = setfield(ComVarStr,Prc(i).Name,parname,Val);
            end
        catch
        end
    end
end
return
