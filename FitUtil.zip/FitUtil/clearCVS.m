function CVS=clearCVS
% Clears the global structure ComVarStr and (optionally) keeps its contents in the structure CVS
%
% USAGE: clearCVS; CVS=clearCVS
%
global ComVarStr
if nargout>0
    CVS=ComVarStr;
end
clear global ComVarStr
return
