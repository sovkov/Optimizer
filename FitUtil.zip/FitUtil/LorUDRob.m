function phi=LorUDRob(x,c2)
% Robust estimator in a form of an upside-down Lorenzian
% phi = c2(1-(1+x^2/c^2)^(-1))
%
% USAGE: phi=LorUDRob(x,c2)
%
% INPUT
% x      - argument of the function
% c2     - parameter of the function;
%          the less c2 the stronger is the robustness;
%          default value is 27;
%          if c2 does not exist at the input then the default value is
%          adopted
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(c2) || any(any(~isnumeric(c2)))
    c2=27; % default value
end
if c2<=0
    phi=[];
    return
end
%
phi=c2 .* ( 1 - 1 ./ (1+x.^2./c2) );
%
return