function [f,sigma2,Df,Ierr,eps,It,k0,S] = RobIter(A,g,hRob,c,eps0,MaxIt,VPAlim)
% Robust iterations
%
% USAGE: f = RobIter(A,g,hRob)
%  or: [f,sigma2,Df,Ierr,eps,It,k0,S] = RobIter(A,g,hRob,c,eps0,MaxIt,VPAlim)
%
% INPUT
% A      - construction matrix of the LSF system in a representation
%          corresponding to the representation of the right-hand vector g
%          (statistically independent with weight of all its elements =1)
% g      - right-hand vector of  the LSF system prepaired so that all its
%          elements are to be statistically independent with weights equal 1
% hRob   - handle of a robust estimation function; some of the available
%          functions are (see their description in the corresponding m-files):
%          @HuberRob; @WinsorRob; @AndrewsRob; @TukeyRob; @RamseyRob;@LorUDRob
% c      - parameter of the robust estimation function to be used;
%          if c does not exist at the input or is empty, than a default value
%          is adopted (see m-files for the corresponding robust estimation functions
%          for the default values and for how the parameter influences the
%          robustness);
% eps0   - desired relative accuracy of the norm of the solution;
%          if does not exist at the input or is empty, the default value 1E-6
%          is adopted
% MaxIt  - maximum allowed number of iterations;
%          if does not exist at the input or is empty, the default value
%          10000 is adopted
% VPAlim - decimal digit accuracy of computations of the SVD decomposition
%          of the construction matrix in the LSF computations;
%          influences only some of the computations but not the result
%          representation;
%          values different from 16 slow down the process;
%          if does not exist at the input or is empty, the default value
%          16 is adopted;
%
% OUTPUT
% f      - solution vector;
% sigma2 - estimate of the variance (sigma^2) of the right-hand values g;
%          so, the estimate of the f covariance matrix can be
%          computed as sigma2*Df; standard deviations of the solution can
%          be computed as sqrt(sigma2*diag(Df)); the residual sum of squares
%          R0 = sigma2*(n-k0(1)) (see k0 below);
% Df     - covariance matrix of the solution f implying that the g values
%          standard deviation is indeed 1; otherwise the actual covariance
%          matrix can be computed by multiplying this one by the actual
%          standard deviation of g;
% Ierr   - error flag:
%          0 - everything is OK and the desired norm accuracy eps0 is
%              achieved with the number of iterations less or equal MaxIt;
%          1 - everything is OK but the desired norm accuracy eps0 is not
%              achieved with the number of iterations equal MaxIt;
%          2 - insufficient input;
%              all the output values are returned as the empty variables;
%          3 - something is wrong with the robust estimation function;
%              all the output values are returned as the empty variables;
%          4 - something is wrong with the LSF-MNK procedure
%              all the output values are returned as the empty variables;
% eps    - actually achieved accuracy of the solution norm;
% It     - actual number of the iterations;
% k0     - vector:
%          k0(1) is always actual number of 1-D singular subspaces contributed into the solution
%                (higher subspaces were ignored due to an input truncation condition
%                 or due to zero singular values);
%          k0(2) is recommended number of 1-D singular subspaces to be used 
%                for the reason the unstability crashes numerical
%                precision
% S      - singular values of the final construction matrix of robust
%          iterations
Ierr=0;
if nargin<7 || isempty(VPAlim) || any(any(~isnumeric(VPAlim)))
    VPAlim=16; % default value
end
if nargin<6 || isempty(MaxIt) || any(any(~isnumeric(MaxIt)))
    MaxIt=10000; % default value
end
if nargin<5 || isempty(eps0) || any(any(~isnumeric(eps0)))
    eps0=1.0e-6; % default value
end
if nargin<4
    c=[]; % so that the default value of the parameter to be used
end
if nargin<3
    Ierr=2; % error 2 - insufficient input
    Df=[];
end
%
[f,sigma2] = MNK (A,g,0,0,VPAlim); % zero-th approximation
% main iteration
It=0; % current number of iterations
eps=realmax;
n=size(A,1); % dimension of the observation space
m=size(A,2); % dimension of the parameter space
w = ones(n,1);
while eps>=eps0 && It<=MaxIt && sigma2>realmin
    f0=f;
    It=It+1;
    y  = A*f0-g;
    if ~isempty(sigma2) && isnumeric(sigma2) && sigma2>realmin
        y = y/sqrt(sigma2);
    end
    i0 = find(y==0);
    i1 = find(y~=0); % in robust estimates values of robust functions either equal values of the quadratic function or less than them, so only strict zeros can be dangerous
    if ~isempty(i1)
        try
            w(i1) = sqrt(feval(hRob,y(i1),c))./abs(y(i1)); % square root of current weghts
        catch
            Ierr=3; % error 3 - something is wrong with the robust estimation function
            f=[];
            sigma2=[];
            Df=[];
            return
        end
        if isempty(w)
            Ierr=3; % error 3 - something is wrong with the robust estimation function
            f=[];
            sigma2=[];
            Df=[];
            return
        end
    end
    if ~isempty(i0)
        w(i0)=1;
    end
    g = w.*g; % weight correction of g values
    for i=1:m
        A(:,i)=w.*A(:,i); % weight correction of A matrix
    end
    [f,sigma2]=MNK (A,g,0,0,VPAlim);
    if isempty(f)
        Ierr=4; % error 4 - something is wrong with the LSF-MNK procedure
        sigma2=[];
        Df=[];
        return
    end
    eps = norm(f-f0)/norm(f);
end
% final
if eps>eps0 && sigma2>realmin
    Ierr=1; % error 1 - maximum number of iteration is achieved but relative error of the solution norm is still less then eps0
end
    if nargout>=5
        [f,sigma2,Df,k0,S] = MNK (A,g,0,0,VPAlim);
    elseif nargout==4
        [f,sigma2,Df,k0] = MNK (A,g,0,0,VPAlim);
    elseif nargout==3
        [f,sigma2,Df] = MNK (A,g,0,0,VPAlim);
    end
return;
