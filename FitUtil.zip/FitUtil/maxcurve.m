function [lambda0,lcur]=maxcurve(lnR0,lnN,lambda)
% Finds the coordinate lambda0 of the maximum curvature of a curve
%
% USAGE: 
% [lambda0,lcur]=maxcurve(lnR0,lnN,lambda)
%   or
% lambda0=maxcurve(lnR0,lnN,lambda)
%
% PURPOSE
% finds coordinate lambda0 of the maximum curvature lcur
% of a (table) curve lnN depending on lnR0 if both values lnN and lnR0 are known
% as a function of an (equidistant vector of) parameter lambda
%

    Nlam    = max(size(lambda));
    dlam    = (lambda(Nlam)-lambda(1))/(Nlam-1);
%
    d1lnR0  = diff(lnR0);   % 1-st differential [d lnR0](i)   at points (lambda(i)+lambda(i+1))/2
    d1lnN   = diff(lnN);    % 1-st differential [d lnN](i)    at points (lambda(i)+lambda(i+1))/2
    d2lnR0  = diff(d1lnR0); % 2-nd differential [d^2 lnR0](i) at points  lambda(i+1)
    d2lnN   = diff(d1lnN);  % 2-nd differential [d^2 lnN](i)  at points  lambda(i+1)
%
    d1lnR0(1:Nlam-2) = (d1lnR0(1:Nlam-2)+d1lnR0(2:Nlam-1))/2; % 1-st differential [d lnR0](i) at points lambda(i+1)
    d1lnR0(Nlam-1)=[];
    d1lnN(1:Nlam-2) = (d1lnN(1:Nlam-2)+d1lnN(2:Nlam-1))/2;    % 1-st differential [d lnN](i)  at points lambda(i+1)
    d1lnN(Nlam-1)=[];
%
    lcur  = abs(d1lnR0.*d2lnN-d2lnR0.*d1lnN)./(d1lnR0.^2+d1lnN.^2).^1.5;
    i0    = find(lcur==max(lcur));
    i00   = length(i0);
    lambda0 = zeros(i00,1);
    for i = 1:i00
        if (i0(i) == 1)
            lambda0(i) = lambda(1);
        elseif (i0(i) == Nlam-2)
            lambda0(i) = lambda(Nlam);
        else
            f0   = lcur(i0(i));
            fmin = lcur(i0(i)-1);
            fmax = lcur(i0(i)+1);
            lambda0(i) = lambda(i0(i)+1) + (fmax-fmin)/((f0-fmax)+(f0-fmin)).*dlam/2;
        end
    end
    return