function [ifmin,x0,y0]=locParExtr(x1,x2,x3,y1,y2,y3)
% Finds the position of the local extremum of a parabola constructed from 3 points.
%
% USAGE: [ifmin,x0,y0]=locParExtr(x1,x2,x3,y1,y2,y3)
%
%     INPUT
% x1, x2, x3 - input points;
% y1, y2, y3 - input values at the points x1, x2, x3;
%     OUTPUT
% ifmin      - flag if the extremum is maximum, false otherwise;
% x0         - extremum coordinate;
% y0         - extremum value.
z2=x2-x1;
z3=x3-x1;
z0=z2*z3*(z2-z3);
R2=y2-y1;
R3=y3-y1;
a2 = (-z2*R3+z3*R2) / z0;
if ~isinf(a2) && ~isnan(a2) && a2>0
    ifmin=true;
else
    ifmin=false;
end
if nargout>1
    a1 = (z2^2*R3-z3^2*R2) / z0;
    x0 = -a1/a2/2;
    if nargout>2
        y0 = y1 + a1*x0 + a2*x0^2;
    end
    x0 = x0+x1;
end
return