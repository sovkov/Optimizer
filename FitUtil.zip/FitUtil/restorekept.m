function restorekept
% Restores parameter fields and Der1 field of the global structure ComVarStr from the values kept in ComVarStr.Parkeep and ComVarStr.Derkeep
%
global ComVarStr
try
    if isfield(ComVarStr,'Parkeep') && ~isempty(ComVarStr.Parkeep) && isfield(ComVarStr,'Derkeep') && ~isempty(ComVarStr.Derkeep)
        putpara(ComVarStr.Parkeep);
        ComVarStr.Der1 = ComVarStr.Derkeep;
        if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
            disp('RESTOREKEPT: The parameters and derivatives beeing kept are restored');
        end
    end
end
return