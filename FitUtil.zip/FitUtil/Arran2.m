function [i1,i2,ind0] = Arran2 (j1,j2)
% Simultaneous sorting of two input vectors
% so that i1 becomes an acsending-order version of j1,
% and i2 is resorted so that elements of j2 corresponding
% to equal elements of i1 becomes an ascending-order subvectors as well;
% ind0  is a permutation vector.
%
% USAGE: [i1,i2,ind0] = Arran2 (j1,j2)
%
try
  k1=length(j1);
  i1=j1;
  if nargin>2
    k2=length(j2);
    i2=j2;
  else
    k2=k1;
    i2=[];
  end
 %
  [i1,ind0] = sort(j1);
  if nargin<=1 || nargout<2 || isempty(k2) || k1~=k2 return; end
 %
  i2=j2(ind0);
 %
  if  k2>1
     ic  = i1(1);
     kc1 = 1;
     kc2 = 1;
     for i=2:k2
         if i1(i)==ic
             kc2=kc2+1;
         else
             [i2(kc1:kc2),ind1] =sort (i2(kc1:kc2));
             ind1 = ind1+kc1-1;
             ind0(kc1:kc2) = ind0(ind1);
             kc1=i;
             kc2=i;
             ic=i1(i);
         end
     end
     [i2(kc1:kc2),ind1] =sort (i2(kc1:kc2));
     ind1 = ind1+kc1-1;
     ind0(kc1:kc2) = ind0(ind1);
  end
catch
end
return