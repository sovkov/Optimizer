% SCRIPT for the LSF step adaptation
%
%%%%%%% exit if the minimum is found or the maximum of iterations is achieved
%
        if ~isempty(R) && ~isnan(R) && R>=0 && (R==0 || ((iter==1 && k==1 || ~isempty(st)) && R<=RCmin && ierr0>=0)) % the Gauss prediction worked fine or the LM "optimal step" prediction worked fine!
            break;
        end
        if ~isempty(st) || iter>=StopIterLM % we have attempted to find the "optimal" step, check if it was good or not
            if (~isempty(R) && ~isnan(R) && R<R0 || iter>=StopIterLM) && RCmin<R0 % return to the current minimum if only we have found the LM "optimal step" prediction is good, but is worse than the "current minimum"
                iCm=-iCm;
                if ifDisp
                    disp(strcat('LSF: return to the minimum R=',num2str(RCmin)));
                end
                break;
            elseif iter>=StopIterLM % allowed maximum number of the LM steps is achieved without a solution - break with an error flag
                if ifDisp
                    disp('LSF: no convergence');
                end
                break;
            else % otherwise continue...
                st=[];
            end
        end
%
%%%%%%% correct LM parameters otherwise
%
        ifDone=false; % flag to indicate if the half-step computation has been already done in a multiprocess case
        stepLeft0=stepLeft; % to check if stepLeft is corrected or not
        if isinf(step)
            step=LMstep0; % the only use of LMstep0
        end
        if isempty(R1) && k>1 && ierr0Mmp(k-1)>=0
            R1=RMmp(k-1);
            step1=stepMmp(k-1);
        end
        %
        % adapt the step if needed - bad situations,
        %
        if (ierr0<0 || isempty(R) || ~isreal(R) || isinf(R) || isnan(R) || R<0) % decrease step and repeat the computation if something is wrong
            ierr0=-1;
            R1=-1; % to indicate that the step was reduced
            if ~isinf(step) && (isempty(stepRight) || stepRight>step)
                stepRight = step;
                RRight=R;
            end
            step=step/10;
            try
                f = MNKlin([],g,D,kkk,1/step,false,VPALim);
            catch
                f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
            end
            continue;
        end
        %
        if R/R0>10 % decrease step and repeat the computation if the result is highly unreliable
            ierr0=-1;
            R1=-1; % to indicate that the step was reduced
            step=step/10;
            try
                f = MNKlin([],g,D,kkk,1/step,false,VPALim);
            catch
                f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
            end
            continue;
        end
        %
        if R>=R0 && ~isinf(step) 
            if isempty(stepRight) || stepRight>step
                stepRight = step; % maximum allowed step further
                RRight=R;
            end
        end
        %
        if R<RCmin && R>=0
            if ifDisp
                disp(strcat('LSF: current minimum is changed from R=',num2str(RCmin),' to R=',num2str(R)));
            end
            RCmin = R;
            fCmin = f;
            yCmin = y;
			stepCmin=step;
            iCm=-2;
            if k>1 && (isempty(stepRight) || stepRight>stepMmp(k-1))
                stepRight=stepMmp(k-1);
                RRight=RMmp(k-1);
            end
            if k<Mmp && stepLeft<stepMmp(k+1)
                stepLeft=stepMmp(k+1);
                RLeft=RMmp(k+1);
            end
            if ~isempty(R1) && R1>0
                if step1>step && (isempty(stepRight) || stepRight>step1)
                    stepRight=step1;
                elseif step1<step && stepLeft<step1
                    stepLeft=step1;
                end
            end
        end
        if ((isempty(R1) && R>R0) || R1<0) % find the "optimal" step if needed;
            ierr0=-1;
            if ~isinf(step)
                step1=step;
                R1 = R;
                step=stepLeft + (step-stepLeft)/2;
            end
            if k<Mmp && stepLeft==stepLeft0;
                ifDone=true;
                k=k+1;
                R=RMmp(k);
                y=yMmp(:,k);
                f=fMmp(:,k);
            else
                try
                    f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                catch
                    f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                end
            end
            continue;
        end
        if ~isempty(R1)
            rel = abs((R1-R)/(R-R0));
            if R1>R0 && rel <= 1 % we are too far from the local solution and far from the zero approximation
                step1=step;
                if step<=10^(-VPALim)
                    break;
                end
                if rel<0.01
                    R1=-1;
                    step=step/10;
                else
                    R1=R;
                    step=stepLeft + (step-stepLeft)/2;
                    if k<Mmp && stepLeft==stepLeft0
                        ifDone=true;
                        k=k+1;
                        R=RMmp(k);
                        y=yMmp(:,k);
                        f=fMmp(:,k);
                    end
                end
            elseif R1<R0 && rel >= 1 %  we are too close to the zero approximation (less probable situation, so it is treated less carefully)
                step = step*10;
                R1=-1;
            else
%%%%%%%%%%%%%%%%%%%%%%%%%
                if k==Mmp || stepLeft>stepMmp(k+1) || ierr0Mmp(k+1)<0
                    sL=stepLeft;
                    RL=RLeft;
                else
                    sL=stepMmp(k+1);
                    RL=RMmp(k+1);
                end
                if k==1 || ierr0Mmp(k-1)<0
                    if ~isempty(stepRight) && ~isinf(stepRight)
                        sR=stepRight;
                        RR=RRight;
                    else
                        sR=[];
                    end
                else
                    sR=stepMmp(k-1);
                    RR=RMmp(k-1);
                end
                if R1>0
                    if (isempty(sR) || step1>step && step1<sR) && step1~=sL
                        sR=step1;
                        RR=R1;
                    elseif step1<step && step1>sL
                        sL=step1;
                        RL=R1;
                    end
                end
                if isempty(sR)
                    if k<Mmp-1
                        k0=find(ierr0Mmp(k+2:Mmp)>=0,1,'first');
                        if ~isempty(k0)
                            sR=stepMmp(k+1+k0);
                            RR=RMmp(k+1+k0);
                        end
                    elseif sL>0
                        sR=0;
                        RR=R0;
                    end
                end
                [ifmin,st]=locParExtr(sL,step,sR,RL,R,RR);
                R1=R;
                step1=step;
                if ifmin
                    if Mmp>1 && ~isempty(stepRight) && 2*st<stepRight
                        step = st*2;
                    else
                        step = st;
                    end
                elseif R<R0 % we have probably underestimated the LM step
                    step=step*3;
                    st=[];
                else % we have probably overestimated the LM step
                    st=[];
                    step=stepLeft + (step-stepLeft)/2;
                    if k<Mmp && stepLeft==stepLeft0
                        ifDone=true;
                        k=k+1;
                        R=RMmp(k);
                        y=yMmp(:,k);
                        f=fMmp(:,k);
                    end
                end
            end
            if ~isempty(stepRight) && step>=stepRight
                step = 0.5*stepRight * (1+rand);
                R1 = -1;
            end
            ierr0 = -1;
            if ~ifDone
                try
                    f = MNKlin([],g,D,kkk,1/step,false,VPALim);
                catch
                    f = MNKlin(Der,g,D,kkk,1/step,false,VPALim);
                end
            end
            continue;
        end
