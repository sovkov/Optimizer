function fixDat
% Forms an output vector f from an input array a, taking input indices arrays n1, n2, so that f=a(n1,n2) vectorized in a column vector;
%
% All the input and output is done via the fields of the global structure ComVarStr.fixDat
%    INPUT
% a  - an input numerical array;
% n1 - a subset of the first indeces of the input a to be included into the output f;
% n2 - a subset of the second indeces of the input a to be included into the output f;
%    OUTPUT
% f  - an output vector as a vectorized sub-array of the input a(n1,n2) with n1 and n2 indeces.
%    REMARKS
% if n1 and/or n2 are empty, the total subarray of a
% in the corresponing dimension is taken;
% any non-positive elements of n1 and/or n2 are ignored.
%
% In a case ComVarStr.ifDer.ifDer exists and =true (=1),
% the local design matrix df/da is computed in accordance
% to the rules of the package Optimizer.
%
global ComVarStr
try
    %
    if ~isfield(ComVarStr.fixDat,'a') || isempty(ComVarStr.fixDat.a)
        ComVarStr.fixDat.f=[];
        return
    end
    %
    ifDer=isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && ComVarStr.ifDer.ifDer(1);
    [la1,la2]=size(ComVarStr.fixDat.a);
    if ifDer
        ComVarStr.locDerNames={'a'};
    end
    if isfield(ComVarStr.fixDat,'n1')
        n1=ComVarStr.fixDat.n1;
        n1(n1>la1)=[];
    else
        n1=[];
    end
    if isfield(ComVarStr.fixDat,'n2')
        n2=ComVarStr.fixDat.n2;
        n2(n2>la2)=[];
    else
        n2=[];
    end
    ifF=0;
    if ~isempty(n1)
        n1(n1<=0)=[];
        n1=sort(n1);
        ln1=length(n1);
        if length(n1)==la1 && (la1==1 || all(diff(n1)==1))
            ifF=-1;
        end
    else
        n1=1:la1;
        ln1=la1;
        ifF=-1;
    end
    if ~isempty(n2)
        n2(n2<=0)=[];
        n2=sort(n2);
        ln2=length(n2);
        if length(n2)==la2 && (la2==1 || all(diff(n2)==1))
            ifF=-ifF;
        else
            ifF=0;
        end
    else
        n2=1:la2;
        ln2=la2;
        ifF=-ifF;
    end
    if isempty(n1) || isempty(n2)
        ComVarStr.fixDat.f=[];
        return
    end
    if ifF
        ComVarStr.fixDat.f=reshape(ComVarStr.fixDat.a,numel(ComVarStr.fixDat.a),1);
        if ifDer
            if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
                ComVarStr.locDer=eye(numel(ComVarStr.fixDat.a));
            else
                ComVarStr.locDer=speye(numel(ComVarStr.fixDat.a));
            end
        end
        return
    end
    ComVarStr.fixDat.f=reshape(ComVarStr.fixDat.a(n1,n2),numel(ComVarStr.fixDat.a(n1,n2)),1);
    if ifDer
        ComVarStr.locDerNames={'a'};
        if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
            ComVarStr.locDer=zeros(length(ComVarStr.fixDat.f),numel(ComVarStr.fixDat.a));
        else
            ComVarStr.locDer=sparse(length(ComVarStr.fixDat.f),numel(ComVarStr.fixDat.a));
        end
        k0=0;
        for k=1:ln2
            for l=1:ln1
                k0=k0+1;
                ComVarStr.locDer(k0,n1(l)+(n2(k)-1)*ln1)=1;
            end
        end
    end
catch mectc
    ComVarStr.fixDat.f=0;
    if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && ComVarStr.ifDer.ifDer(1)
        ComVarStr.locDerNames={'a'};
        ComVarStr.locDer=zeros(length(ComVarStr.fixDat.f));
    end
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('fixDat uncertified ERROR');
        disp(mectc.message);
        beep;
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError=true;
    end
end
return