function [f,sigma2,Df,Dfi,k0,S0,V0,U0] = MNK (A,g,k,lambda,VPAlim)
% Least-square fit and (optionally) Tikhonov regularization of a linear equation
%
% USAGE
% [f,sigma2,Df,k0,S,V,U] = MNK (A,g,k,lambda,VPAlim)
%       in a simplest case:
% f = MNK(A,g)
%       or any other combination of more input and output parameters
%
% PURPOSE
% Least-square fit and (optionally) Tikhonov regularization of a linear equation Af=g
% for statistically independent components of the g vector with equal errors
% i. e., implying the covariance matrix of g is diagonal with equal diagonal elements
%
% INPUT     (any number of input variables between 2 and 4)
% A       - matrix of the equation to be solved
%           if A=[] at the input then the SVD decomposition of the matrix A computed at
%           the previous call of the routine is used for the computations
% g       - right-hand vector of the equation to be solved
% k       - if exists and is scalar value >0, a parameter of a "rough" regularization, namely
%                             if 1<=k<m - number of first singular 1-D
%                                         subspaces to contribute into the
%                                         solution vector (higher subspaces
%                                         to be ignored);
%                             if 0<=k<1 - level of reliability, so that the
%                                         number of first singular 1-D
%                                         subspaces contributing into the
%                                         solution vector is found as a
%                                         lower boundary at which the relation
%                                         of the current singular value to
%                                         the first one becomes less or equal than k
%           if exists and is a matrix than it is treated as a matrix of linear
%           constraints k*f=lambda playing the role of the null hypothesis
%           to be checked according the Fisher criterium.
%           NOTE: the matrix k should not be singular. Some singularities
%           (presence of zero rows or of equal rows) are checked and
%           corrected, and, if the rank of the corrected k matrix becomes zero,
%           it is treated as if k=size(A,1), lambda=0 at the input;
%           if some inconsistences in the matrix k and vector lambda are
%           found, then it is treated as if k=size(A,1), lambda=0 at the
%           input and the output k0(2)=0.
% lambda  - if exists and ~=0 when k is a scalar value, parameter of the Tikhonov regularization
%           (implied to be chosen so that to minimize the solution norm
%           without effecting the residual sum of squares significantly)
%           measured in values of the maximum singular number sigma(1);
%           when k is a matrix, lambda plays a role of the right-hand vector
%           of linear constraints to be checked (see the k description above);
%           if does not exist than is treated as lambda=0 for any regime
% VPAlim  - if exists and not equal 16, than a regime of computations with
%           a high precision is used. This case VPAlim significant digits
%           are traced.
%           REMARKS: (1) this regime slows down the computations.
%                    (2) this value only effects intermediate computations;
%                        all the results are returned as usual double
%                        precision MATLAB variables
%
% OUTPUT    (any number of output variables between 1 and 7 is allowed)
% f       - the least-square solution of the equation;
%           the length of f is determined by the second dimension of the
%           matrix A or (in a case when input k is a matrix) by the minimum
%           of the second dimensions of A and k if they differ;
% sigma2  - estimate of the variance (sigma^2) of the right-hand values g
%            so, the estimate of the f covariance matrix can be
%            computed as sigma2*Df; standard deviations of the solution can
%            be computed as sqrt(sigma2*diag(Df)); the residual sum of
%            squares R0 = sigma2*(n-k0(1)) (see k0 below).
% Df      - covariance matrix of the solution f implying that the g values
%           standard deviation is indeed 1; otherwise the actual covariance
%           matrix can be computed by multiplying this one by the actual
%           standard deviation of g
% k0      - vector:
%           k0(1) is always actual number of 1-D singular subspaces contributed into the solution
%                 (higher subspaces were ignored due to an input truncation condition
%                  or due to zero singular values);
%           k0(2) is recommended number of 1-D singular subspaces to be used 
%                 for the reason the unstability crashes numerical
%                 precision
%           k0(3) is only outputted if input k is a matrix; this case
%                 it contains the p-level of the null hypothesis checked based on
%                 the Fisher criterium
%           k0(4) is only outputted if input k is a matrix; this case
%                 it contains actual number of the constraints which were considered
% S0, V0, U0 - elements of the singular value decomposition
%                A(1:n,1:m) = U0(1:n,1:m) * [diag(S0(1:m))] * V0'(1:m,1:m)
%            so, S0 is a vector containing singular values
% Dfi     - diagonal part of the inverse of Df intended to compute the conditional standard deviations
%
% NOTICE: in a regime with the Fisher test (when input k is a matrix),
%         the LSF solution without constrains is only computed.
%
%
persistent S
persistent V
persistent U
try
    if ~isempty (A)
        n = size(A,1); % number of equations
        m = size(A,2); % number of unknown parameters
    elseif ~isempty(U) && ~isempty(V) && size(U,2)==numel(S) && size(V,2)==numel(S)
        n = size(U,1);
        m = size(V,1);
    else
        f=[];
        Df=[];
        Dfi=[];
        sigma2=[];
        k0=[];
        S0=[];
        V0=[];
        U0=[];
        return
    end
catch
    f=[];
    Df=[];
    Dfi=[];
    sigma2=[];
    k0=[];
    S0=[];
    V0=[];
    U0=[];
    return
end
if nargin<5 || isempty(VPAlim) || ~isnumeric(VPAlim) || abs(round(VPAlim))==16
    VPAlim=16;
    ifVPA = false;
else
    ifVPA = true;
    DIGITS0=digits;
    digits(abs(round(VPAlim)));
end
%
% check is there a need in the Fisher test
%
if nargin < 3 || all(size(k)<m) % so in a case of one variable k is treated as a matrix of the constraint
    ifFish = false; % no need in the Fisher test
else
    ifFish=true; % Fisher test is to be done
    p = size(k,1);
    if (p==0)
        ifFish=false;
        k=0;
        lambda=0;
    end
end
%
if (ifFish && m~=size(k,2)) % correct dimensions of k one if needed
    if (m<size(k,2))
        k = k(:,1:m);
    else
        k(:,size(k,2)+1:m) = 0;
    end
end
%
if (ifFish) % check and correct some possible singularities in the k matrix
    if (nargin <4 || isempty(lambda) || ~isnumeric(lambda))
        lambda = zeros(p,1);
    end
    p0 = p;
    for i=p0:-1:1
        if (k(i,:)==zeros(1,m))
            if (lambda(i)~=0) % the constraints are inconsistent
                p=0;
                k0(3)=0;
                break;
            end
            k(i,:) = [];
            lambda(i)=[];
            p = p-1;
            if p==0 k0(3)=1; end
        end
        k0(4) = p;
    end
    if (p>1)
        p0 = p;
        for j=p0:-1:2
            for i=j-1:-1:1
                if (k(i,:)==k(j,:))
                    if (lambda(i)~=lambda(j)) % the constraints are inconsistent
                        p=0;
                        k0(3)=0;
                        break;
                    end
                    k(j,:) = [];
                    lambda(j)=[];
                    p = p-1;
                    break;
                end
            end
            if (p==0)
                break;
            end
        end
    end
    if (p==0)
        ifFish=false;
        k = m;
        lambda=0;
    end
end
% correction of an inconsistent input k and introducing nss as minimum
% dimension at all
if nargin < 3 || ~isnumeric(k) || isempty(k) || (~ifFish && (any(size(k)~=1) || k<=0) )
    k=min(m,n);
    nss = k;
elseif isscalar(k) && round(k)>0
    nss = min([n m round(k)]);
else
    nss = min([n m]);
end
%
% Singular Value Decomposition of the A matrix
%
if ~isempty(A)
    try
        if ~ifVPA
            if issparse(A)
                [U,S,V] = svds(A,nss);
            else
                [U,S,V] = svd(A,'econ');
            end
        else
            [U,S,V] = svd(vpa(full(A)),'econ');
        end
%         if ~issparse(A)
%             if ~ifVPA
%                 [U,S,V] = svd(A,'econ');
%             else
%                 [U,S,V] = svd(vpa(A),'econ');
%             end
%         else
%             if ~ifVPA
%                 [U,S,V] = svds(A,nss);
%             else
%                 [U,S,V] = svd(vpa(full(A)),'econ');
%             end
%         end
    catch
        beep;
        disp('SVD could not be completed. Your computer is probably out of memory.');
        disp('Try to use sparse format if it is not done yet;');
        disp('it can be turned on by the command ''global ComVarStr; ComVarStr.ifSparse=true;''');
        f=[];
        sigma2=[];
        Df=[];
        k0=[];
        S0=[];
        V0=[];
        U0=[];
        return;
    end
    S=diag(S);
end
nss = min(nss, numel(S)); % sometimes less number of singular values is found!
if S(1)==0 % erroneous singular values
    f=[];
    Df=[];
    sigma2=[];
    k0=[];
    S0=[];
    V0=[];
    U0=[];
    return
end
mmp = find(S>0,1,'last');
l = find (-log10(double(S(1:mmp)/S(1))) >= VPAlim-2)-1;
if ~isempty(l)
    k0(2) = l(1);
else
    k0(2)=mmp;
end
%
% determining k0(1) - the number of the 1-D singular subspaces to be taken into account
%
if (~ifFish && k>=0 && k<1)
    l = find (double(S/S(1)) <= k);
else
    l = find (double(S/S(1)) == 0);
end
if (isempty(l))
    l = nss+1;
end
k0(1)=l(1)-1;
% if (~ifFish && k >= 1)
%     k0(1)=min(k0(1),k);
% end
k0(1)=min(k0(1),nss);
%
if (nargin<4 || ifFish || isempty(lambda) || all(lambda==0))
    s1 = 1./S(1:k0(1));
else
    s1 = S(1:k0(1))./(S(1:k0(1)).^2+lambda.*S(1)^2);
end
%
% compute the solution
%
f=zeros(m,1);
for i=1:k0(1)
    f0 = (U(1:n,i))'*g .* s1(i);
    f = f + f0 * V(1:m,i);
end
if (nargout>2 || ifFish)
    Df = V(1:m,1:k0(1)) * diag(s1(1:k0(1)).^2) * (V(1:m,1:k0(1)))';
    if nargout>3
        Dfi = diag(V(1:m,1:k0(1)) * diag(1./s1(1:k0(1)).^2) * (V(1:m,1:k0(1)))');
    end
%         Df=zeros(m);
%         for i=1:k0(1)
%             Df = Df + V(1:m,i)*(V(1:m,i))' .* (s1(i).^2);
%         end
%         if k0(1)>1 && (any(diag(Df)<0) || any(eig(Df)<0))
%             k0(1)=k0(1)-1;
%         else
%             break;
%         end
end
%
% compute the residual sum of squares R0 and the standard deviation of the
% input data sigma2
%
if (nargout>1 || ifFish)
    if ~isempty(A)
        R0 = sum((A*f-g).^2);
    else
        R0=sum((U*diag(S)*V'*f-g).^2);
    end
    if (n ~= k0(1))
        sigma2 = R0/(n-k0(1));
    else
        sigma2 = 0;
    end
end
%
% find p-level of the the null hypothesis
%
if (ifFish)
    try
        RH = (lambda-k*f)'*inv(k*Df*k')*(lambda-k*f); % difference of the residual sum of squares with the constraints and without the constraints
    catch
        RH = (lambda'-k*f)'*inv(k*Df*k')*(lambda'-k*f);
    end
    try
%       F  = double(RH/R0*(n-k0(1))/p);
%       k0(3) = 1 - fcdf(F,n-k0(1),p); % p-level of the null hypothesis
        F  = double(R0/RH*p/(n-k0(1)));
        k0(3) = fcdf(F,p,n-k0(1)); % p-level of the null hypothesis
    catch
        k0(3)=1;
    end
end
%
% correct number of the degrees of freedom if Tikhonov regularization has
% been applied
%
if ~ifFish && nargin>=4 && all(size(lambda)==1) && isnumeric(lambda) && lambda~=0
    k0(1)=k0(1)-1; % Tikhonov regularization is treated as an additional constrain
end
%
if nargout > 5
    S0 = S;
    if nargout > 6 
        V0 = V;
        if nargout > 7
            U0 = U;
        end
    end
end
%
if ifVPA
    switch nargout % [f,sigma2,Df,k0,S,V,U] = ...
        case 1
            f = double(f);
        case 2
            f = double(f);
            sigma2 = double(sigma2);
        case 3
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
        case 4
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            Dfi = double(Dfi);
        case 5 % k0 is already double
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            Dfi = double(Dfi);
        case 6
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            Dfi = double(Dfi);
            S = double(S);
        case 7
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            Dfi = double(Dfi);
            S = double(S);
            V = double(V);
        otherwise
            f = double(f);
            sigma2 = double(sigma2);
            Df = double(Df);
            Dfi = double(Dfi);
            S = double(S);
            V = double(V);
            U = double(U);
    end
    digits(DIGITS0); % return to the initial value
end
%
return