function myGenWrite(u,x,dText,s)
% Writes numeric content into a control (listbox, edit, or text)
%
% USAGE: myGenWrite(u,x,dText,s)
%
% INPUT
% u     - either a handle (numeric) or a Tag (character string) of a control;
% x     - vector containing numeric contents to be written into a control;
%         if the control is edit or text, x must be of the unit length (i.e.,
%         just a number);
% dText - if exists and is a character string than its contents replaces
%         the current contents of the control in a case the input x is not
%         a numeric vector; if dText does not exist or is not a character string
%         and x is not numeric, the control contents is unchanged.
% s     - if exists and is a string it is treated as a format for
%         transforming numeric values into a string;
%         if s does not exist at the input it is treated as ,'%26.16g'
%         if input s=[], then a fast write with 6 significant digits is done
%
if nargin<4
    if nargin<2
        return;
    end
    s='%26.16g';
end
%
try
%
    while iscell(x)
        x=x{1};
    end
    % find a handle of the object
    if ischar(u)
        try
            u0=findobj('Tag',u,'Parent',gcf);
            if isempty(u0)
                u0=findobj('Tag',u);
                u0 = u0(1);
            end
        catch
            u0=findobj('Tag',u);
            u0 = u0(1);
        end
    else
        u0=u;
    end
    %
    % find out if the object the "edit" or "listbox" style
    uStyle=get(u0,'Style');
    %
    if strcmp(uStyle,'edit') || strcmp(uStyle,'text')
        try
            if isnumeric(x) && any(size(x) ~= 1)
                if all (x==x(1))
                    x = x(1);
                else
                    if nargin>=3 && ischar(dText)
                        set(u0,'String',dText);
                    end
                    return
                end
            end
            %
            % write a short format version
            if isempty(s)
                try
                    set(u0,'String',x);
                    return
                catch
                    s='%16.6g'; % for Octave
                end
            end
            %
            % write a full format version
            if ischar(x)
                set(u0,'String',x);
            else
                set(u0,'String',strtrim(num2str(x,s)));
            end
        catch
            if nargin>=3 && ischar(dText)
                set(u0,'String',dText);
            end
        end
    elseif strcmp(uStyle,'listbox') || strcmp(uStyle,'popupmenu')
        try
            if all(size(x) ~= 1) || isempty(x)
                if nargin>=3 && ischar(dText)
                    set(u0,'String',dText);
                end
                return
            end
            %
            % write a short format version
            if isempty(s)
                try
                    set(u0,'String',x);
                    return
                catch
                    s='%16.6g'; % for Octave
                end
            end
            %
            % write a full format version
            try
                if size(x,1) ~= 1
                    set(u0,'String',strtrim(num2str(x,s)));
                else
                    set(u0,'String',strtrim(num2str(x',s)));
                end
            catch
                set(u0,'String',x);
            end
        catch
            if nargin>=3 && ischar(dText)
                set(u0,'String',dText);
            end
        end
    end
catch
end
return