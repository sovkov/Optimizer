function [R,y,ierr]=runMoS(x,f,CVS,iter,R0,st,ifCal,y0)
% Model computation at a shifted point
%
% USAGE: [R,y,ierr,x0]=runMoS(x,f,CVS)
%
% Addresses the global structure ComVarStr
%     INPUT
% x    - 2D cell array containing all the coordinates of the reference
%        point; by default it is produced by the "collectparam" routine;
% f    - a vector of shifts for all variable arguments (those with the
%        nonzero ParStep); default f=0;
% CVS  - a current replica of ComVarStr, needed if the ComVarStr itself is
%        empty;
% iter, R0, st -
%      - the only use of these scalar values  (whatever they mean...)
%        is to be displayed at the terminal in a case ComVarStr.ifDisp=true;
% ifCal- flag: = false means that no model results calculations are needed;
%        default ifCal=true.
% y0   - a vector to be put into the output y in a case of error.
%     OUTPUT
% R    - evaluation function value at a shifted point x0;
% y    - results vector at a shifted point;
% ierr - error flag:
%        =0      OK,
%        =-10000 unclassified error
%        otherwise ierr reproduces the error flag from "funval".
global ComVarStr
try
    if nargin>2 && ~isempty(CVS)
        if isempty(ComVarStr)
            ComVarStr=CVS;
        end
    %    CVS=[];
    end
    ierr=0;
    % R=Inf;
    % y=y0;
    if nargin==0
        x=collectparam;
    %    [y,Npanz,Npat]=getpara([],[],false,true);
        f=[];
    end
    % correct parameters
    if nargin>0 % && ~isempty(f) && isnumeric(f)
        i0 = 0; % current index of the 1-D parameter to be considered
        j  = 0; % current number of the 1-D parameter over which the derivative is computed; can differ from i0 as for zero steps the derivatives are not computed
        %
        % reset the parameters
        for k=1:length(ComVarStr.Proc)
         kPar=length(ComVarStr.ParField{k});
         if kPar>0
          for i=1:kPar  % i can differ from both i0 and j as some parameters can be multidimensional
            if iscell(x{k})
                x0 = x{k}{i};
            else
                x0 = x{k};
            end
            [kx,ky] = size(x0);
            if nargin>1 && ~isempty(f) && isnumeric(f)
                for iy=1:ky
                for ix=1:kx
                    if length(ComVarStr.ParStep)>i0 && isnumeric(ComVarStr.ParStep(i0+1)) && ~isempty(ComVarStr.ParStep(i0+1))
                        i0 = i0+1;
                        if ComVarStr.ParStep(i0)==0
                            continue;
                        end
                        j = j+1;
                        x0(ix,iy) = x0(ix,iy) + f(j);
                    end
                end
                end
            end
            %
            % puts new parameters into ComVarStr
            if iscell (ComVarStr.ParField{k})
                ComVarStr.(getProNm(k)).(ComVarStr.ParField{k}{i}) = x0; % set i-th parameter to the new value
    %            ComVarStr = setfield(ComVarStr,getProNm(k),ComVarStr.ParField{k}{i},x0); % set i-th parameter to the new value
            else
                ComVarStr.(getProNm(k)).(ComVarStr.ParField{k}) = x0; % set i-th parameter to the new value
    %            ComVarStr = setfield(ComVarStr,getProNm(k),ComVarStr.ParField{k},x0); % set i-th parameter to the new value
            end
          end
         end
        end
    end
    %
    if nargin>=7 && ~isempty(ifCal) && ~ifCal(1)
        return
    end
    %
    % compute model values with the new parameters
    [ierr,y]=funval;
    if ierr<0
        if nargin>=8 && nargout>=2
            y=y0;
        else
            y=[];
        end
        R=Inf;
        if isfield(ComVarStr,'ifError')
            ComVarStr.ifError=true;
        end
        if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1) && nargin>4
            try
                if R-R0>0
                    sp=strcat(num2str(R),' (+',num2str(R-R0),')');
                else
                    sp=strcat(num2str(R),' (',num2str(R-R0),')');
                end
                if iter<1 || nargin<6 || isempty(st)
                    disp(strcat(num2str(iter),': R=',sp));
                else
                    disp(strcat(num2str(iter),': R=',sp,' [LM parameter=',num2str(st),']'));
                end
            catch
                disp('runMoS WARNING: cannot display the current R');
            end
        end
        return
    end
    if nargin>7 && numel(y)<numel(y0)
        y=y0;
    end
    %
    % compute evaluation function
    try
        if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isreal(ComVarStr.inpCov))) && ( size(ComVarStr.inpCov,1)==length(ComVarStr.input) && (size(ComVarStr.inpCov,2)==length(ComVarStr.input) || size(ComVarStr.inpCov,2)==1) ) && ~all(all(ComVarStr.inpCov==0))
            try
                R = resi(ComVarStr.input,y,ComVarStr.inpCov);
            catch
                try
                    R=resi(ComVarStr.input,y,ComVarStr.inpCovar);
                catch
                    try
                        R = resi(ComVarStr.input,y);
                    catch
                        R=Inf;
                    end
                end
            end
        elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar) && all(all(isreal(ComVarStr.inpCovar))) && ( size(ComVarStr.inpCovar,1)==length(ComVarStr.input) && (size(ComVarStr.inpCovar,2)==length(ComVarStr.input) || size(ComVarStr.inpCovar,2)==1) ) && ~all(all(ComVarStr.inpCovar==0))
            try
                R = resi(ComVarStr.input,y,ComVarStr.inpCovar);
            catch
                try
                    R = resi(ComVarStr.input,y);
                catch
                    R=Inf;
                end
            end
        else
            try
                R = resi(ComVarStr.input,y);
            catch
                R=Inf;
            end
        end
        if isempty(R) || isnan(R) || R<0
            R=Inf;
        end
    catch mectc
        if isfield(ComVarStr,'ifError')
            ComVarStr.ifError=true;
        end
        if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
            beep;
            disp('runMoS: unclassified ERROR');
            beep;
        end
        ierr=-10000;
        R = Inf;
    end
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1) && nargin>4
        try
            if iter<1 || nargin<6 || isempty(st)
                disp(strcat(num2str(iter),': R0=',num2str(R0),' current R=',num2str(R),', R-R0=',num2str(R-R0)));
            else
                disp(strcat(num2str(iter),': R0=',num2str(R0),' current R=',num2str(R),', R-R0=',num2str(R-R0),' [LM parameter=',num2str(st),']'));
            end
        catch
            disp('runMoS WARNING: cannot display the current R');
        end
    end
catch mectc
    disp(mectc);
end
return