function roundF(Nround,nam0,nam,NN)
% Makes the file "nam" of the rounded values read from the file "nam0" with a column-wise numerical table
%
% USAGE: roundF(Nround,nam0,nam)
%
% Nround  - the numerical order of digits to be kept (e.g. Nround=-3 means that 3 digits after "." must be kept); 
%           array with the number of elements equal to or less than the number of columns in the input file;
%           default Nround=0 (rounding to the closest integer)
% NN      - [N00 N01] (default =[]), where:
%  N00    - maximum permitted number of zeros after '.' in the resulting string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%  N01    - maximum permitted number of digits before '.' in the resulting string;
%           default=[] means that the number of digits depends on the
%           num2str inbuilt MatLab function
try
    if nargin<1 || isempty(Nround) || any(any(~isreal(Nround)))
        Nround=0;
    else
        Nround=round(Nround);
    end
    if nargin<=1 || ~ischar(nam0)
        [nam0,pnam0] = uigetfile('*.*','Input file name');
        nam0=strcat(pnam0,nam0);
    end
    if nargin<=2 || ~ischar(nam)
        [nam,pnam] = uiputfile('*.*','Output file name');
        nam=strcat(pnam,nam);
    end
    if strcmp(nam,nam0)
        disp('roundF ERROR: the input and output file names must differ');
        return
    end
    if nargin<4 || any(any(~isreal(NN)))
        NN=[];
    end
    fid0 = fopen(nam0,'r');
    if fid0==-1
        disp('roundF ERROR: the wrong input file');
        return
    end
    fid = fopen(nam,'w');
    if fid==-1
        disp('roundF ERROR: the wrong output file');
        return
    end
    nN=numel(Nround);
    n0 = 0;
    while true
     try
        a = fgetl(fid0);
        if isequal(a,-1)
            break;
        end
        a = str2num(a);
        b = '';
        for k=1:numel(a)
            if nN>=k
                n0 = Nround(k);
            end
            if a(k)
                n = ceil(log10(abs(a(k)))+5*eps(a(k)))-n0;
            else
                n=-n0;
            end
            if n<=0
                n=0;
            end
            c = padzer(num2str(a(k),n),n,NN);
            if k==1
                b = c;
            else
                b = strcat(b,'\t',c);
            end
        end
        b = strcat(b,'\r\n');
        count = fprintf(fid,b);
     catch
         disp('roundF ERROR');
     end
    end
    status=fclose('all');
catch  mectc
    disp('roundF ERROR');
    disp(mectc.message);
end
return

function c = padzer(b,N,NN)
% Pads the stringed real number b with ending zeros so that to be presented with N signicant digits
%
% USAGE: c = padzer(b,N)
%
%  NN      - [N00 N01] (default =[]), where:
%  N00    - maximum permitted number of zeros after '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%  N01    - maximum permitted number of digits before '.' in the "c" string;
%           default=[] means that the number of zeros depends on the
%           num2str inbuilt MatLab function
%
if nargin<3 || isempty(NN) || any(any(~isreal(NN)))
    N00=[];
    N01=[];
elseif all(size(NN)==1)
    N00=NN;
    N01=[];
else
    N00=NN(1);
    N01=NN(2);
end
c = b;
indC = findstr(c,'.');
indF = findstr(c,'e');
if isempty(indF)
    indF = findstr(c,'E');
    if isempty(indF)
        indF=length(c)+1;
    end
end
if isempty(indC)
    K = N - (indF-1);
else
    K = N - (indF-2);
end
n0=[]; % counts the number of zeros after the dot
for k=1:length(c)
    if strcmp(c(k),'-') || strcmp(c(k),'+') || strcmp(c(k),'0')
        K=K+1;
        if ~isempty(n0) && strcmp(c(k),'0')
            n0=n0+1;
        end
    elseif ~strcmp(c(k),'.')
        break;
    else
        n0=0; % start to count the number of zeros after the dot
    end
end
if K>0
    if isempty(indC)
        K=K+1;
    end
    if indF<=length(c)
        c((indF+K):(end+K)) = c(indF:end);
    end
    if isempty(indC)
        c(indF)='.';
        indF=indF+1;
        K=K-1;
    end
    for k=0:(K-1)
        c(indF+k)='0';
    end
end
%
if ~isempty(n0) && ~isempty(N00) && n0>N00
    c(indC:(indC+n0))=[];
    n=length(c);
    if indC<n
        c((indC+2):(n+1)) = c((indC+1):n);
        c(indC+1)='.';
    end
    if indC>1
        k = findstr(c(1:(indC-1)),'0');
        c(k)=[];
    end
    n0=n0+1;
    if ~isempty(N01) && N01<=0
        indC=findstr(c,'.');
        if ~(isempty(indC) || indC<=1 || strcmp(c(indC-1),'0') || strcmp(c(indC-1),'-') || strcmp(c(indC-1),'+'))
            c((indC+2):(length(c)+1)) = c((indC+1):length(c));
            c(indC+1)=c(indC-1);
            c(indC-1)='0';
            n0=n0-1;
        end
    end
elseif ~isempty(N01)
    if ~isempty(indC)
        kk=indC;
    else
        kk=indF;
    end
    k0=0;
    kp=[];
    for k=1:kk
        if k==kk
            break;
        end
        if strcmp(c(k),'-') || strcmp(c(k),'+')
            continue;
        else
            if isempty(kp)
                kp=k+1;
            end
            k0=k0+1;
            if k0>N01
                break;
            end
        end
    end
    if k<kk
        if isempty(indC)
            kk0=length(c)+1;
        else
            kk0=kk;
        end
        if N01>0
            c((kp+1):kk0) = c(kp:(kk0-1));
            c(kp)='.';
            n0=kp-kk;
        elseif  ~(strcmp(c(k),'0') || strcmp(c(k),'-') || strcmp(c(k),'+'))
            c(indC)=[];
            c((k+2):(length(c)+2)) = c(k:length(c));
            c(k)='0';
            c(k+1)='.';
            n0=k-kk;
        else
            n0=0;
        end
    else
        n0=0;
    end
else
    n0=0;
end
if isempty(n0)
    n0=0;
end
%
%
n=length(c);
indF = findstr(c,'e');
if isempty(indF)
    indF = findstr(c,'E');
end
if ~isempty(indF) && indF<n
    k=str2num(c((indF+1):n))-n0;
    if k~=0
        a=num2str(k);
        c((indF+1):n)=[];
        c = strcat(c,a);
    else
        c(indC:n)=[];
    end
else
    k=-n0;
    if k~=0
        c = strcat(c,'e',num2str(k));
    end
end
return
