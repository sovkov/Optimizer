function [ierr,Der,fCmin,yCmin,RCmin,iCmin] = Deriv1(R0,y)
% Computes the first derivatives of the multidimentional function with respect to a set of its arguments
%
% USAGE: [ierr,Der,fCmin,yCmin,RCmin,iCmin] = Deriv1(R0,y)
%
% All input parameters are taken from the global structure ComVarStr
% (see comments in the "initialization" section below for structure field descriptions)
% R0 - if exists then it a residual sum of squares of the 0-th approximation; default R0=[].
%      if R0>0, it prescribes to adapt the steps based on the current "R" values with
%      the "stepped" variable
% y  - if exists, the 0-th approximation results; default y=0.
% OUTPUT
% Der (j,i) is the first derivative of the j-th component of the function over the i-th argument
% ierr   - error flag
%          =0   everything is OK
%          >0   non-critical error flag of the last call of the procedure for computing
%               function values; the computations are proceeded
%          =100 no ierr flag is produced by the procedure for computing the
%               function to be diffirentiated; the computations are done
%          <0   something was wrong; the computations are seized
% fCmin  - vector with only one non-zero component, which produced
%          the minimum value of the residual sum of squares
% yCmin  - results vector corresponding to the minimum value of the residual
%          sum of squares
% RCmin  - the value of the minimum value of the residual sum of squares
%          corresponding fCmin
% iCmin  - the ordinal number of the parameter resulting in iCmin
%
% initialization
%
global ComVarStr
ierr=0;
[CN,~,~]=Optimizer('getOpVal');        % get the parameter names in the original order
nPS=numel(find(ComVarStr.ParStep~=0));
ifDisp = ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1); % if the current state of the program to be displayed in the Matlab command window
ifStAd = ~isfield(ComVarStr,'ifStAd') || isempty(ComVarStr.ifStAd) || ComVarStr.ifStAd(1); % should we adapt or not differentiation steps?
if1Step = ~isfield (ComVarStr,'if1Step') || isempty(ComVarStr.if1Step) || ComVarStr.if1Step(1); % if the current state of the program to be displayed in the Matlab command window
%if1Step = isfield (ComVarStr,'if1Step') && ~isempty(ComVarStr.if1Step) && ComVarStr.if1Step(1); % if the current state of the program to be displayed in the Matlab command window
if if1Step && (nargin<2 || isempty(y) || ~isnumeric(y))
    y=0;
end
%
% loop over the parameters and computing derivatives
%
i0 = 0; % current index of the 1-D parameter to be considered
j  = 0; % current number of the 1-D parameter over which the derivative is computed; can differ from i0 as for zero steps the derivatives are not computed
iCmin = 0; % to be the number of the parameter resulted in the minimum residual sum of squares after doing corresponding steps
if nargin==0 || isempty(R0) || ~isreal(R0)
    R0=[];
end
lp = length(getpara([],[],false));
lr = length(getresults);
if ~isfield(ComVarStr,'ifSparse') || isempty(ComVarStr.ifSparse) || ~ComVarStr.ifSparse(1)
    Der = zeros(lr,lp);
else
    Der = sparse(lr,lp);
end
if nargout>2
    fCmin=zeros(lp,1);
    yCmin=getresults;
    if ~isempty(R0)
        RCmin=R0;
    else
        if isempty(yCmin)
            [ierr,yCmin]=funval(true);
        end
        if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
            RCmin = resi(yCmin,ComVarStr.input,ComVarStr.inpCov);
        elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
            RCmin = resi(yCmin,ComVarStr.input,ComVarStr.inpCovar);
        else
            RCmin = resi(yCmin,ComVarStr.input);
        end
    end
else
    RCmin=-1;
end
for k=1:length(ComVarStr.Proc)
 kPar = length(ComVarStr.ParField{k});
 Nm = getProNm(k);
 if kPar>0
  for i=1:kPar % i can differ from both i0 and j as some parameters can be multidimensional
    if iscell(ComVarStr.ParField{k})
        x0 = ComVarStr.(Nm).(ComVarStr.ParField{k}{i});
%        x0 = getfield(ComVarStr,Nm,ComVarStr.ParField{k}{i});
    else
        x0 = ComVarStr.(Nm).(ComVarStr.ParField{k});
%        x0 = getfield(ComVarStr,Nm,ComVarStr.ParField{k});
    end
    [kx,ky] = size(x0);
    for iy=1:ky
    for ix=1:kx
        if length(ComVarStr.ParStep)>i0 && isnumeric(ComVarStr.ParStep(i0+1)) && ~isempty(ComVarStr.ParStep(i0+1))
            i0 = i0+1;
            if ComVarStr.ParStep(i0)==0
                continue;
            end
            j = j+1;
            ierr0 = -1;
            x = x0;
            while ierr0 <0
%
% positive step
%
%                 if ifDisp
%                     disp(strcat('Deriv1: Positive step of the parameter No. ',num2str(j),'/',num2str(nPS),'--',CN{j}));
%                 end
                x(ix,iy) = x0(ix,iy) + ComVarStr.ParStep(i0);
                if iscell(ComVarStr.ParField{k})
                    ComVarStr.(Nm).(ComVarStr.ParField{k}{i})=x; % increase i-th parameter
%                    ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x); % increase i-th parameter
                else
                    ComVarStr.(Nm).(ComVarStr.ParField{k})=x; % increase i-th parameter
%                    ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x); % increase i-th parameter
                end
                    [ierr0,yp]=funval(true);
                if ierr0 >0
                    ierr = -ierr0;
                    return
                elseif ierr0<0 || isempty (yp) || any(any(~isreal (yp))) || any(any(isinf(yp))) || any(any(isnan(yp)))
                    ierr0 = -1; % wrong result
                    ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
                    continue;
                end
%
% negative step
%
                if ~if1Step
%                     if ifDisp
%                         disp(strcat('Deriv1: Negative step of the parameter No. ',num2str(j),'/',num2str(nPS),'--',CN{j}));
%                     end
                    x(ix,iy) = x0(ix,iy) - ComVarStr.ParStep(i0);
                    if iscell(ComVarStr.ParField{k})
                        ComVarStr.(Nm).(ComVarStr.ParField{k}{i})=x; % decrease i-th parameter
%                        ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x); % decrease i-th parameter
                    else
                        ComVarStr.(Nm).(ComVarStr.ParField{k})=x; % decrease i-th parameter
%                        ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x); % decrease i-th parameter
                    end
                    % try
                    %     [ierr0,ym]=funval0; % works if all the procedures are in the matlab path or in the current directory
                    % catch
                        [ierr0,ym]=funval(true);
                    % end
                    if ierr0 < 0 || isempty (ym) || any(any(~isreal (ym))) || any(any(isinf(ym))) || any(any(isnan(ym)))
                        ierr0 = -1; % wrong result
                        ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
                        continue;
                    end
                end
            end
            %
            if iscell(ComVarStr.ParField{k})
                ComVarStr.(Nm).(ComVarStr.ParField{k}{i})=x0; % return to the initial value
%                ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k}{i},x0); % return to the initial value
            else
                ComVarStr.(Nm).(ComVarStr.ParField{k})=x0; % return to the initial value
%                ComVarStr = setfield(ComVarStr,Nm,ComVarStr.ParField{k},x0); % return to the initial value
            end
            try
                if ~if1Step
                    Der(:,j) = (yp(:)-ym(:))/2/ComVarStr.ParStep(i0); % compute the derivatives
                    if RCmin>0 || ~isempty(R0) % && R0>0 % adapt a current step if it is too small or too big or adopt the coordinate-wise minimum
                        try
                            if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
                                Rm = resi(ym,ComVarStr.input,ComVarStr.inpCov);
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCov);
                            elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
                                Rm = resi(ym,ComVarStr.input,ComVarStr.inpCovar);
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                            else
                                Rm = resi(ym,ComVarStr.input);
                                Rp = resi(yp,ComVarStr.input);
                            end
                        catch
                            try
                                Rm = resi(ym,ComVarStr.input,ComVarStr.inpCovar);
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                            catch
                                Rm = resi(ym,ComVarStr.input);
                                Rp = resi(yp,ComVarStr.input);
                            end
                        end
                        if ifDisp
                            try
                                if isempty(R0)
                                    disp(strcat('Deriv1: Rneg=',num2str(Rm),' Rpos=',num2str(Rp),' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                                else
                                    if Rm-R0>0
                                        sm=strcat(num2str(Rm),' (+',num2str(Rm-R0),')');
                                    else
                                        sm=strcat(num2str(Rm),' (',num2str(Rm-R0),')');
                                    end
                                    if Rp-R0>0
                                        sp=strcat(num2str(Rp),' (+',num2str(Rp-R0),')');
                                    else
                                        sp=strcat(num2str(Rp),' (',num2str(Rp-R0),')');
                                    end
                                    disp(strcat('Deriv1: Rneg=',sm,', Rpos=',sp,' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                                end
                            catch
                                disp(strcat('Deriv1: Rneg=',num2str(Rm),' Rpos=',num2str(Rp),' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                            end
    %                        disp('--------------------------------------------------');
                        end
                        if RCmin>0
                            if Rm<=Rp && Rm<=RCmin
                                RCmin=Rm;
                                fCmin=zeros(size(fCmin));
                                fCmin(j)=-ComVarStr.ParStep(i0);
                                iCmin=j;
                                yCmin=ym;
                            elseif Rp<=RCmin
                                RCmin=Rp;
                                fCmin=zeros(size(fCmin));
                                fCmin(j)=ComVarStr.ParStep(i0);
                                iCmin=j;
                                yCmin=yp;
                            end
                        end
                        % ADAPTATION OF THE PARAMETER STEPS if needed
                        if ifStAd && ~isempty(R0)
                            Rmax = max(abs((Rp-R0))/R0,abs((Rm-R0))/R0);
                            Rmin = min(abs((Rp-R0))/R0,abs((Rm-R0))/R0);
                            if Rp>R0 && Rm>R0 && (Rmax>10 || Rmin<1e-8)
                                if Rmax>10
                                    if Rm<Rp
                                        ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/5;
                                    else
                                        ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/5;
                                    end
                                elseif Rmin<1.0E-8
                                    if Rm<Rp
                                        ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*3;
                                    else
                                        ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                                    end
                                end
                            elseif Rmin<1.0E-8
                                if Rm<Rp
                                    ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*3;
                                else
                                    ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*3;
                                end
                            elseif Rp<=R0 && Rm<=R0
                                if Rm<Rp
                                    ComVarStr.ParStep(i0)=-ComVarStr.ParStep(i0)*2.1;
                                else
                                    ComVarStr.ParStep(i0)=ComVarStr.ParStep(i0)*2.1;
                                end
                            else
                                [ifmin,st,yst]=locParExtr(-ComVarStr.ParStep(i0),0,ComVarStr.ParStep(i0),Rm,R0,Rp);
                                rt=abs(st/ComVarStr.ParStep(i0));
                                if ifmin && rt<10 && rt>0.01 && abs((yst-R0)/R0)>1e-8
                                    if Rm>=R0 && Rp>=R0 || st>ComVarStr.ParStep(i0)
                                        ComVarStr.ParStep(i0)=st;
                                    else
                                        if Rm<Rp
                                            ComVarStr.ParStep(i0)=-ComVarStr.ParStep(i0)*1.3;
                                        else
                                            ComVarStr.ParStep(i0)=ComVarStr.ParStep(i0)*1.3;
                                        end
                                    end
                                else
                                    if Rp>=R0 && Rm>=R0
                                        if Rm<Rp
                                            ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/2;
                                        else
                                            ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/2;
                                        end
                                    else
                                        if Rm<Rp
                                            ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)*1.5;
                                        else
                                            ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*1.5;
                                        end
                                    end
                                end
                            end
                        end
                    end
                else
                    Der(:,j) = (yp(:)-y(:))/ComVarStr.ParStep(i0); % compute the derivatives
                    if RCmin>0 || ~isempty(R0) % && R0>0 % adapt a current step if it is too small or too big or adopt the coordinate-wise minimum
                        try
                            if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov)
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCov);
                            elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar)
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                            else
                                Rp = resi(yp,ComVarStr.input);
                            end
                        catch
                            try
                                Rp = resi(yp,ComVarStr.input,ComVarStr.inpCovar);
                            catch
                                Rp = resi(yp,ComVarStr.input);
                            end
                        end
                        if ifDisp
                            try
                                if isempty(R0)
                                    disp(strcat('Deriv1: Rpos=',num2str(Rp),' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                                else
                                    if Rp-R0>0
                                        sp=strcat(num2str(Rp),' (+',num2str(Rp-R0),')');
                                    else
                                        sp=strcat(num2str(Rp),' (',num2str(Rp-R0),')');
                                    end
                                    disp(strcat('Deriv1: R=',sp,' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                                end
                            catch
                                disp(strcat('Deriv1: Rpos=',num2str(Rp),' [',num2str(j),'/',num2str(nPS),'--',CN{j},']'));
                            end
    %                        disp('--------------------------------------------------');
                        end
                        if RCmin>0
                            if Rp<=RCmin
                                RCmin=Rp;
                                fCmin=zeros(size(fCmin));
                                fCmin(j)=ComVarStr.ParStep(i0);
                                iCmin=j;
                                yCmin=yp;
                            end
                        end
                        % ADAPTATION OF THE PARAMETER STEPS if needed
                        if ifStAd && ~isempty(R0) && R0>0
                            Rmax = abs((Rp-R0))/R0;
                            Rmin = abs((Rp-R0))/R0;
                            if Rp>R0 && (Rmax>10 || Rmin<1e-8)
                                if Rmax>10
                                    ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)/5;
                                elseif Rmin<1.0E-8
                                    ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*2;
                                end
                            elseif Rmin<1.0E-8
                                ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*5;
                            elseif Rp>=R0
                                ComVarStr.ParStep(i0) = -ComVarStr.ParStep(i0)/2;
                            else
                                ComVarStr.ParStep(i0) = ComVarStr.ParStep(i0)*1.5;
                            end
                        end
                    end
                end
            catch
                ierr=-i0; % something is wrong with the i0-th parameter
                return
            end
        end
    end
    end
  end
 end
end
%
if isfield(ComVarStr,'ifSparse') && ~isempty(ComVarStr.ifSparse) && ComVarStr.ifSparse(1) && nnz(Der)~=nzmax(Der)
    Der=Der*1; % reduces allocation spase
end
return