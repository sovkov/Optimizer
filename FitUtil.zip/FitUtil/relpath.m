function pth = relpath(path0,path1)
% Gets the "path" of the input full "path0" relative the input full "path1".
% Example: relpath('C:\Dir1\Dir2','C:\Dir1\Dir3\') -> '..\Dir2\'.
%
% USAGE: pth = relpath(path0,path1)
%
% If path0==path1, then pth=''.
% If any of the paths is absent at the input or empty or is not a string,
% it is considered to be the current directory path
if nargin<2 || isempty(path1) || ~ischar(path1)
    C=what;
    path1=C.path;
    clear C;
end
if nargin==0 || isempty(path0) || ~ischar(path0)
    C=what;
    path0=C.path;
    clear C;
end
%
lp0 = length(path0);
lp1 = length(path1);
if ~strcmp(path0(lp0),'\')
    lp0=lp0+1;
    path0 = strcat(path0,'\');
end
if ~strcmp(path1(lp1),'\')
%    lp1=lp1+1;
    path1 = strcat(path1,'\');
end
if strcmpi(path0,path1)
    pth='';
    return
end
%
slash0 = strfind(path0,'\');
slash1 = strfind(path1,'\');
if ~strcmpi(path0(1:slash0(1)),path1(1:slash1(1))) % it means different drivers; full path0 is to be the relative path
    pth=path0;
    return
end
n0 = length(slash0);
n1 = length(slash1);
k = min(n0,n1);
pathup = '';
pathdown = '';
if n0>n1
    pathdown=path0(slash0(n1)+1:lp0);
elseif n0<n1
    for i=1:n1-n0
        pathup = strcat('..\',pathup);
    end
else
end
for i=k:-1:1
    try
        k0 = slash0(i)-1;
        k1 = slash1(i)-1;
        if ~strcmpi(path0(1:k0),path1(1:k1))
            pathup = strcat('..\',pathup);
        else
            break;
        end
    catch
        break;
    end
end
k0 = k0+2;
k1 = slash0(k);
if k0<k1
    pathdown = strcat(path0(k0:k1),pathdown);
end
pth = strcat(pathup,pathdown);
return