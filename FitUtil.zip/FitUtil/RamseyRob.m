function phi=RamseyRob(x,lambda)
% Robust estimator by Ramsey
% phi= ( 1 - (1+lambda*|x|) .* exp(-lambda.*|x|) ) * 2.0 ./ lambda^2
%
% USAGE: phi=RamseyRob(x,lambda)
%
% INPUT
% x      - argument of the function
% lambda - parameter of the Ramsey function;
%          the greater lambda the stronger is the robustness;
%          default value is 1/3;
%          if lambda does not exist at the input then the default value is
%          adopted
%
% OUTPUT
% phi - value of the function at the point x
if nargin==0 || isempty(x) || any(any(~isnumeric(x)))
    phi=0;
    return
end
if nargin==1 || isempty(lambda) || any(any(~isnumeric(lambda)))
    lambda=1.0/3.0; % default value
end
if lambda<=0
    phi=[];
    return
end
%
phi=abs(x);
phi=(1-(1+lambda.*phi).*exp(-lambda.*phi))*2.0 ./ lambda.^2;
return