function y = modfunVec(x)
% Computes a vector y of the model output at a point predefined by the vector x for a model constructed with a Modeler program and "experimental" data defined in the Viewer program.
%
% USAGE: y = modfunVec(x)
%
% The vector x should have a dimension not less than the total number of 1-D parameters with non-zero ParStep values of the current model
% In a case of any inconsistence y=[];
% At the exit all the parameters are restored to their initial values.
%
% The intention of this function was to allow a use of standard Matlab and
% Matlab packages (e.g., Optimization toolbox) functions for an analysys of
% a model prepared with the Modeler-Viewer-Optimizer tool
%
global ComVarStr
try
 z = ComVarStr.input;
 x0 = getpara;
 if nargin>0
    ierr = setpara(x,false);
 end
 funval;
 y = getresults;
 ierr = setpara(x0);
catch
 y=[];
 if isfield(ComVarStr,'ifError')
     ComVarStr.ifError=true;
 end
 if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
     beep;
     disp('modfunVec ERROR!');
 end
 ierr = setpara(x0);
end
return