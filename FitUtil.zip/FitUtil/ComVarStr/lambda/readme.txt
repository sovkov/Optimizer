ComVarStr.lambda
==============================
RU Win 1251
������� �������� (lambda) ��������� LSF.m.
��. ���������� � ���������.
===============================
EN
Input parameter (lambda) of the procedure LSF.m.
See comments to the procedure.

% lambda  - (1) if exists and ~=0 when kkk is a scalar value
%               (or kkk does not exist) and ifplot does not exist:
%               parameter of the Tikhonov regularization
%               (implied to be chosen so that to minimize the solution norm
%               without effecting the residual sum of squares significantly);
%           (2) if exists when kkk is a matrix and ifplot does not exist:
%               lambda plays a role of the right-hand vector
%               of linear constraints to be checked (see the kkk description above);
%           (3) if exists when ifplot exists and length(lambda)==3, its
%               elements are treated as lower boundary, upper boundary and
%               number of point of a grid at which the L-curve method is
%               applied to find the optimal regularization parameter
%           (4) if does not exist than is treated as lambda=0 for any regime;
