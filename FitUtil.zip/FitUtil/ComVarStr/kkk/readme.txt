ComVarStr.kkk
==============================
RU Win 11251
������� �������� (kkk) ��������� LSF.m.
��. ����������� � ���������.
====================================
EN
Input parameter (kkk) of the procedure LSF.m.
See comments to the procedure.

% kkk     - if exists and is scalar value >0, a parameter of a "rough" regularization, namely
%                           if 1<=kkk<m - number of first singular 1-D
%                                         subspaces to contribute into the
%                                         solution vector (higher subspaces
%                                         to be ignored);
%                           if 0<=kkk<1 - level of reliability, so that the
%                                         number of first singular 1-D
%                                         subspaces contributing into the
%                                         solution vector is found as a
%                                         lower boundary at which the relation
%                                         of the current singular value to
%                                         the first one becomes less or
%                                         equal than kkk
%           if exists and is a matrix than it is treated as a matrix of linear
%           constraints kkk*f=lambda playing the role of the null hypothesis
%           to be checked according the Fisher criterium.
%           NOTE: the matrix kkk should not be singular. Some singularities
%           (presence of zero rows or of equal rows) are checked and
%           corrected, and, if the rank of the corrected kkk matrix becomes zero,
%           it is treated as if kkk=size(A,1), lambda=0 at the input;
%           if some inconsistences in the matrix kkk and vector lambda are
%           found, then it is treated as if kkk=size(A,1), lambda=0 at the
%           input and the output k0(2)=0.
