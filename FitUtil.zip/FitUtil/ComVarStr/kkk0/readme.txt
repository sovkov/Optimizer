ComVarStr.kkk0
==============================
RU Win 11251
�������� �������� (kkk0) ��������� LSF.m.
��. ���������� � ���������.
====================================
EN
Output parameter (kkk0) of the procedure LSF.m.
See comments to the procedure.

% kkk0    - vector:
%           kkk0(1) is always actual number of 1-D singular subspaces contributed into the solution
%                   (higher subspaces were ignored due to an input truncation condition
%                    or due to zero singular values);
%                   it does not include number of constraints if there are some and beeing adopted,
%                   so real number of degrees of freedom this case is kkk0(1) - size(kkk,1)
%           kkk0(2) is recommended number of 1-D singular subspaces to be used 
%                   for the reason the unstability crashes numerical
%                   precision
%           kkk0(3) is only outputted if input kkk is a matrix; this case
%                   it contains the p-level of the null hypothesis checked based on
%                   the Fisher criterium
%           kkk0(4) is only outputted if input kkk is a matrix; this case
%                   it contains actual number of the constraints which were considered
