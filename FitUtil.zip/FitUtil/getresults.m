function y=getresults (k0,n0)
% Puts the contents of the results fields into a column vector y.
%
% USAGE: y=getresults (k0,n0) or y=getresults (k0) or getresults
%
% with 2 input arguments: up to n0-th parameter of the k0-th procedure;
% with 1 input argument: the results field elements with the ordinal numbers listed in k0;
% with no input arguments: all the result fields, i.e.
% if input parameters are absent or empty, the entire set is considered.
% Uses the global structure ComVarStr.
global ComVarStr;
try
    y=[];
    y1=[];
    if nargin<=1 || isempty(k0) || ~isnumeric(k0) || ~isreal(k0) || k0<0
        if nargin==1
            if ~isempty(k0) && isnumeric(k0) && isreal(k0)
                k00=round(k0);
                k00(k00<=0)=[];
            else
                k00=[];
            end
            if isempty(k00)
                y=[];
                return;
            end
        end
        k0=length(ComVarStr.Proc);
    elseif k0(1)==0
        y=[];
        return;
    else
        k0=k0(1);
    end
    %
    % correct ResField if needed
    try
        k = length(ComVarStr.ResField);
    catch
        k=0;
    end
    if k0>k
        ComVarStr.ResField(k+1:k0) = {[]};
    end
    %
    for k=1:k0
        if iscell(ComVarStr.ResField{k})
            if k==k0 && nargin>=2 && ~isempty(n0) && isnumeric(n0) && isreal(n0) && round(n0(1))>=0
                n1=round(n0(1));
            else
                n1=length(ComVarStr.ResField{k});
            end
            if n1==0
                continue;
            end
            fn = getProNm(k);
            for n=1:n1
                if ~isempty(ComVarStr.ResField{k}{n})
                 try
                    y0 = ComVarStr.(fn).(ComVarStr.ResField{k}{n});
%                    y0 = getfield (ComVarStr,fn,ComVarStr.ResField{k}{n});
                 catch
                    continue;
                 end
                 if isempty(y0)
                     continue;
                 end
                 %
                 % reshape
                 for M=1:length(ComVarStr.Proc(k).Par)
                    try
                        pn1 = ComVarStr.Proc(k).Par(M).Name{1};
                    catch
                        pn1 = ComVarStr.Proc(k).Par(M).Name(1);
                    end
                    if strcmp(ComVarStr.ResField{k}{n},pn1)
                        break;
                    end
                 end
                 Dim1 = ComVarStr.Proc(k).Par(M).Dim1;
                 if isempty(Dim1) || ~isreal(Dim1) || Dim1<=0
                    Dim1 = 1;
                 end
                 Dim2 = ComVarStr.Proc(k).Par(M).Dim2;
                 if isempty(Dim2) || ~isreal(Dim2) || Dim2<=0
                    Dim2 = 1;
                 end
                 D1 = size(y0,1);
                 D2 = size(y0,2);
                 if Dim1*Dim2~=D1*D2
                     if Dim1<D1
                        y0((Dim1+1):D1,:) = [];
                     elseif Dim1>D1
                        y0((D1+1):Dim1,:) = 0;
                     end
                     if Dim2<D2
                        y0(:,(Dim2+1):D2) = [];
                     elseif Dim2>D2
                        y0(:,(D2+1:Dim2)) = 0;
                     end
                 end
                 y0=reshape(y0,Dim1*Dim2,1);
                 y1 = [y1;y0];
                end
            end
        elseif ~isempty(ComVarStr.ResField{k})
            try
                y1 = ComVarStr.(fn).(ComVarStr.ResField{k});
%                y1 = getfield (ComVarStr,fn,ComVarStr.ResField{k});
            catch
                continue;
            end
            y1=reshape(y1,size(y1,1)*size(y1,2),1);
       end
        y = [y;y1];
        y1=[];
    end
    if exist('k00','var') && ~isempty(k00) && isnumeric(k00) && isreal(k00)
        k0=round(k00);
        k0(k0<1 | k0>numel(y))=[];
        if ~isempty(k0)
            y=y(k0);
        else
            y=[];
        end
    end
catch
    y=[];
end
return