function R=resi(z,y,D)
% Computes residual sum of squares or a corresponding Robust estimate of differences between input vectors z and y
%
% USAGE: R=resi(z,y,D)
%
% Addresses the global structure ComVarStr
% INPUT
% z, y - input vectors (e.g., "measured values" and "simulated values")
% D    - if vector - absolute errors of the "measured values" values considered to be statistically independent
%        if matrix - covariance matrix of the "measured values" values
%        if do not exist at the input or have wrong dimensions -
%        considered as a case of a vector with unit elements
% a flag ifRob (true if a robust estimate is to be applied) along with the
% parameters of the robust estimator are read from the global structure
% ComVarStr (see comments to the code below)
% OUTPUT
% R    - residual sum of squares weighted in a ususal way via D values
%        if something is wrong at the input then R=-1 at the output
%

global ComVarStr
try
    if nargin<2 || any(~isnumeric(z)) || any(~isnumeric(y))
        R=-1;
        return
    end
    ny=numel(y);
    nz=numel(z);
    if ny~=nz
        R=Inf;
        return;
    elseif ~nz
        R=0;
        return;
    end
    z = reshape(z,nz,1);
    y = reshape(y,ny,1);
    z=z-y; % now z is a column vector of residuals
    try
        ifRob=ComVarStr.ifRob; % =true if the robust estimate is needed
    catch
        ifRob=false;
    end
    if ifRob
        try
            hRob=ComVarStr.hRob; % handle of the robust estimator function
            try
                cRob=ComVarStr.cRob; % parameters of the robust estimator function
            catch
                cRob=[];
            end
        catch
            ifRob=false;
        end
    end
    if nargin>2 && ~isempty(D) && (size(D,1)==numel(z) || size(D,2)==numel(z)) && isnumeric(D)
        if ifRob
            ComVarStr.ifRob=false; % so that to exclude a correction of the weights within the preMNK routine
        end
        [R,z,ierr]=preMNK([],z,D);
        ComVarStr.ifRob=ifRob;
    end
    if ifRob
        try
            R=sum(feval(hRob,z,cRob));
        catch
            ifRob=false;
        end
    end
    if ~ifRob
        R=z'*z;
    end
    if isnan(R) || imag(R) || R<0
        R = Inf;
    end
catch
    R=Inf;
end
return