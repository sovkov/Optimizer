function N=NResField(k0)
% Computes total number N of elements of the results fields of the k0-th block
% USAGE: N=NResField(k0)

global ComVarStr
N=0;
try
    if k0<=0 || k0>length(ComVarStr.ResField)
        return
    end
    lRF=length(ComVarStr.ResField{k0});
    lPP=length(ComVarStr.Proc(k0).Par);
    for l=1:lRF
        for k=1:lPP
            if iscell(ComVarStr.Proc(k0).Par(k).Name)
                pn=ComVarStr.Proc(k0).Par(k).Name{1};
            else
                pn=ComVarStr.Proc(k0).Par(k).Name;
            end
            if strcmp(pn,ComVarStr.ResField{k0}{l})
                N=N+ComVarStr.Proc(k0).Par(k).Dim1*ComVarStr.Proc(k0).Par(k).Dim2;
                break;
            end
        end
    end
catch
    return
end
return