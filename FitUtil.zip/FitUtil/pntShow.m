function pntShow(Xr,Xu,Col,Mark,msize,ifDel)
% Shows a point (Xr,Xu) with a colored mark in a current axes
% previously deleting other marks of the same color and type (optionally)
%
% USAGE: pntShow(Xr,Xu,Col,Mark,msize,ifDel)
%
% Col and Mark are strings specifying the color and type of the marker according to the MatLab plotting rules
%   default Col = 'r', Mark = 'o';
% msize is a size of the mark
%   default msize = 6;
% if does not exist or invalid, the red circles are plotted
% ifDel = true means that other marks of the same color and type should be previously deleted;
%       = false - they are kept
% if ifDel does not exist at the input or invalid, it is treated as = true
%
% if input values do not exist or are empty or nonumeric, then all color
% circles are deleted
%
 hold on;
 if nargin<6 || isempty(ifDel)
     ifDel=true;
 end
 if nargin<5 || isempty(msize) || any(~isreal(msize))
     msize = 6;
 end
 if nargin<4 || isempty(Mark) || any(~ischar(Mark))
     Mark='o';
 end
 if nargin<3 || isempty(Col) || any(~ischar(Col))
     Col = 'r';
 end
 if ifDel
     try
        g=findobj('Type','line','Color',Col,'Marker',Mark,'Parent',gca);
     catch % in a case Col and Mark are invalid specifications
        Mark = 'o';
        Col  = 'r';
        g=findobj('Type','line','Color',Col,'Marker',Mark,'Parent',gca);
     end   
     delete(g)
 end
 if nargin >= 2 && ~isempty(Xr) && ~isempty(Xu) && isnumeric(Xr) && isnumeric(Xu)
     xl=xlim;
     k=find(Xr<xl(1) || Xr>xl(2));
     if ~isempty(k)
         Xr(k)=[];
         Xu(k)=[];
     end
     if ~isempty(Xr)
         xl=ylim;
         k=find(Xu<xl(1) || Xu>xl(2));
         if ~isempty(k)
             Xr(k)=[];
             Xu(k)=[];
         end
         if ~isempty(Xr)
            plot(Xr,Xu,strcat(Col,Mark),'markersize',msize);
         end
     end
 end
 hold off;
return
