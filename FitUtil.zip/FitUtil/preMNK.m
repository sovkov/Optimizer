function [A,g,ier] = preMNK(A0,g0,D,if0)
% Transforms the linear equation into a standard representation
%
% USAGE: [A,g,ier] = preMNK(A0,g0,D,if0)
%
% PURPOSE
% Transforms the linear equation A0*f=g0 into A*f=g according the following rules.
%
% If input D is a vector by the same size as g0, than every element of the
% vector g0 is just divided by the corresponding element of D to produce the vector g.
% If D is a matrix than the eigenvalue decomposition of it is done D=V*S*V',
% g0 is rotated with the orthogonal matrix V and then every element
% of it is divided by the squre root of every diagonal element of S to
% produce the vector g.
% Matrix A0 is transformed to A accordingly.
%
% It means that if D is a vector of standard deviations of g0 or D is a covariance matrix of g0,
% than g components become statistically independent with equal standard deviations.
%
% INPUT (at least 3 input variables are obligatory)
% A0, g0, D - see the description above
% if0       - if exists, play a role of the flag determening auxiliary options:
%       =  0: parameters of transfromation are to be stored in global
%             variables Vgg (orthogonal matrix) and Srr (vector of scaling
%             factors) for a further use; all the other computations are
%             the same as if there were only 3 input parameters;
%       = -1: global varibles Vgg and Sgg are to be cleared;
%             if A and/or g are to be produced then A=[] and g=[];
%       =  1: the input matrix A0 is to be transformed into A using the
%             previoucly stored global variables Vgg and Sgg and output
%             vector g=[] if it is to be produced; this regime is useful for
%             iterations in a non-linear least square fit scheme;
%       =  2: both A0 and g0 are to be transformed into A and g using the
%             previously stored global variables Vgg and Sgg.
%       NOTE: for every if0 excepting if0=0 the input argument D is not
%             used at all and can be presented by any value, e. g., by a
%             dummy empty array [].
%
% OUTPUT
% g, A      - see the description above
% ier       - =0 if everything is OK,
%             other value if any kind of an error has occured (this case A=[], g=[] if they are to be produced)
%
%
global ComVarStr
persistent Vgg
persistent Sgg
try
%
% Treating of if0
%
    if (nargin>3)
            if (if0==-1)
                clear Vgg;
                clear Sgg;
                if (nargout>0)
                    A=[];
                    if (nargout>1)
                        g=[];
                        if (nargout>2)
                            ier=0;
                        end
                    end
                end
                return
            end
    else
        if0 = 0; % to treat a general case as if if0=0 but not to store the transform parameters
    end
%
% Find the transform parameters
%
    if (if0==0)
        if all(size(D)==size(g0))
            Vgg = [];
            Sgg = D; % Sgg is a vector of standard deviations
        elseif all(size(D')==size(g0))
            Vgg = [];
            Sgg = D'; % Sgg is a vector of standard deviations
        else
            [Vgg,Sgg] = eig(D); % Sgg=V'*D*V, Sgg - diagonal matrix
            Sgg=sqrt(diag(Sgg)); % now Sgg is a vector of standard deviations
        end
    end
%
% Attempt to correct local weight for a case of the robust estimate
%
    if isfield(ComVarStr,'ifRob') && ~isempty(ComVarStr.ifRob) && ComVarStr.ifRob(1)...
            && isfield(ComVarStr,'hRob') && isfield(ComVarStr,'cRob') && ~isempty(ComVarStr.hRob) && ~isempty(ComVarStr.cRob)...
            && isfield(ComVarStr,'input') && ~isempty(ComVarStr.input)
        y = getresults;
        if isempty(y) || length(y)~=length(ComVarStr.input)
            funval;
            y = getresults;
        end
        if ~isempty(y) && length(y)==length(ComVarStr.input)
            y = ComVarStr.input - y;
            i1 = find(y~=0); % in robust estimates values of robust functions either equal values of the quadratic function or less than them, so only strict zeros can be dangerous
            if ~isempty(i1)
                try
                    Sgg(i1) = Sgg(i1) .* abs(y(i1)) ./ sqrt(feval(ComVarStr.hRob,y(i1),ComVarStr.cRob));
                catch
                end
            end
        end
    end
%
% Transform the A0 matrix into the A matrix
%
    if ~isempty(A0)
        if ~isempty(Vgg)
            A=Vgg'*A0; % rotate
        else
            A = A0; % initialize
        end
        if ~isempty(Sgg)
            for i=1:size(A,2)
                A(:,i) = A(:,i)./Sgg; % scale
            end
        end
    else
        A=[];
    end
%
% Transform the g0 vector into the g vector
%
    if if0~=1 && ~isempty(g0)
        if ~isempty(Vgg)
            g=Vgg'*g0; % rotate
        else
            g=g0;
        end
        if ~isempty(Sgg)
            g=g./Sgg; % scale
        end
    elseif (nargout>1)
        g=[];
    end
%
% Errors catching
%
    if (nargout>2)
        ier=0;
    end
%
catch
    if (nargout>0)
        A=[];
        if (nargout>1)
            g=[];
            if (nargout>2)
                ier=1;
            end
        end
    end
end
    return