function [y,R]=MOpt(x00)
% Solves the optimization problem constructed with "Optimzer/Modeler"
% using the tools provided by the Matlab "Optimization Toolbox" (optimproblem,solve).
% The code below can be edited in order to add constraints, specify the solver, etc.---see Matlab help system for the "Optimization Toolbox"
%   Full call: [y,R]=MOpt(x00);  short call: MOpt;
% To use this routine, the model to be optimized must be constructed preliminary by the means of "Optimzer/Modeler".
% The optimization variables are those having non-zero optimization step in Modeler, though the actual values of these steps are not used here.
% In a case of no or empty input argument x00, the zeroth approximations for the optimization variables are taken as they are defined in "Modeler" and their sizes are estimated from their actual sizes.
% Othewise the zeroth approximations for all the optimization variables in a sequence are taken from the united vector x00 and their individual sizes are estimated from the ones in the Modeler fields (Dim1,Dim2).
% At the output
% y - the structure, whose field y.x contains the vector of the optimized parameters;
% R - the final value of the objective function.
% Remark: The package "Optimizer" must be pre-installed.
% Remark: No constraints prescribed in Modeler are imposed, all the constraints must be specified via editing the code below according to the regulations of the Matlab "Optimization Toolbox"
%%

try
    %% choose the zeroth approximation
    if nargin==0 || isempty(x00) || ~isnumeric(x00)
        [x0.x,nn]=getpara([],[],0);
    else
        x0.x=x00(:);
        nn=numel(x00);
    end

    %% specify and solve the problem
    %
    % EDITABLE PART
    %
    x=optimvar('x',nn,1); % see Matlab help for "optimvar" in "Optimization Toolbox" on how to add constraints on the variables and specify other options
    prob = optimproblem('Objective',fcn2optimexpr(@modfunRes,x)); % see Matlab help for "optimproblem" in "Optimization Toolbox" on how to add constraints on the variables and other options
    [y,R]=solve(prob,x0); % see Matlab help for "solve" in "Optimization Toolbox" on how to specify the solver and other options

    if nargin>0 && ~isempty(x00) && isnumeric(x00)
        y.x = reshape(y.x,size(x00));
    end
    
catch mectc
    beep;
    disp('MOpt ERROR');
    disp(mectc.message);
end

return;
end
