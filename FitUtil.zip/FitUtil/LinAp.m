function LinAp
% SAMPLE OPTIMIZER PROGRAM--LINEAR APPROXIMATION
%
% y = a + b * x
%
global ComVarStr % declarate the global structure
ifDisp = ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1);
try
    %
    % main computation
    %
    ComVarStr.LinAp.y = ComVarStr.LinAp.a + ComVarStr.LinAp.b * ComVarStr.LinAp.x;
    %
    if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer) && ComVarStr.ifDer.ifDer(1)
        %
        % local design matrix
        %
        ComVarStr.locDer=[ones(numel(ComVarStr.LinAp.x),1) reshape(ComVarStr.LinAp.x,numel(ComVarStr.LinAp.x),1)];     % derivatives with respect to a and b
        ComVarStr.locDerNames=[{'a'};{'b'}];    % variable names in design matrix
    end
%
% ERROR processing
%
catch mectc
    if ifDisp
        beep;
        disp('LinAp uncertified ERROR');
        disp(mectc.message);
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError=true;
    end
end
%
return
end
