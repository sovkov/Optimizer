function [f,D] = AdopConstr(f0,D0,Phi,Phi0)
% Applies constraints to a vector f0 of LSF
% i.e., to an unconstrained solution of the linear least-square problem
%
% USAGE: [f,D] = AdopConstr(f0,D0,Phi,Phi0)
%
% INPUT
% f0   - vector of an unconstrained solution of LSF;
% D0   - covariance matrix of f0;
% Phi  - matrix of constraints Phi*f0=Phi0;
% Phi0 - right-hand vector of constraints Phi*f0=Phi0;
%
% OUTPUT
% f    - solution vector with constraints;
% D    - covariance matrix of f.
try
    C = D0*Phi'*inv(Phi*D0*Phi');
    f = f0 + C*(Phi0-Phi*f0);
    if nargout>1
        D = D0 - C*Phi*D0;
    end
catch
    f=[];
    D=[];
end
return