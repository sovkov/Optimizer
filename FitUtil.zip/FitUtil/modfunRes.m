function R = modfunRes(x)
% Computes residual sum of squares (or a robust estimation function prescribed by Optimizer settings) at a point predefined by the vector x for a model constructed with a Modeler program and "experimental" data defined in the Viewer program
%
% USAGE: R = modfunRes(x)
%
% The vector x should have a dimension not less than the total number of 1-D parameters with non-zero ParStep values of the current model
% In a case of any inconsistence R=[];
% If ComVarStr.ifDisp is true, the current value of R is output into Matlab command window
% At the exit all the parameters are restored to their initial values.
%
% The intention of this function was to allow a use of standard Matlab and
% Matlab packages (e.g., Optimization toolbox) functions for an analysys of
% a model prepared with the Modeler-Viewer-Optimizer tool
global ComVarStr
 z = ComVarStr.input;
 x0 = getpara;
 if nargin>0
    ierr = setpara(x,false);
 end
 funval;
 if ~isempty(x0)
     ierr = setpara(x0);
 end
 y = getresults;
 try
    if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isnumeric(ComVarStr.inpCov)))
        D = ComVarStr.inpCov;
    elseif isfield(ComVarStr,'inpCovar') && ~isempty(ComVarStr.inpCovar) && all(all(isnumeric(ComVarStr.inpCovar)))
        D = ComVarStr.inpCovar;
    else
        D = [];
    end
 catch
     D = [];
 end
 R = resi(z,y,D);
 if isempty(R) || ~isnumeric(R) || R<0
     R = Inf;
 end
 try
     if ~isfield (ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
         disp(strcat('modfunRes: R=',num2str(R)));
     end
 catch metc
 end
return