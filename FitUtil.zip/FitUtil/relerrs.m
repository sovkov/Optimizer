function relerrs(ifL,ifS)
% Sorts and displays the Optimizer results in the descending order of the relative error.
%
% USAGE: relerrs(ifL,ifS)
%
% The output is done to the Command window in five columns:
% parameter number, relative uncertainty, absolute unsertainty, value, name
%
% The program has two optional INPUT logical parameters ifL, ifS regulating the output format:
% ifL
%  ifL = true  - the otput format is long  (16 decimal digits)
%  ifL = false - the otput format is short (2 decimal digits)
%  default ifL = false (short output)
% ifS
%  ifS = true  - the parameters are sorted in the descending order of the relative error
%  ifS = false - the parameters are output in their "natural" order
%  default ifS = true (output sorted values)
global ComVarStr
try
    if nargin==0
        ifS=true;
        ifL=false;
        disp('by default the output is done using the short format;');
        disp('switch to the long format using ''relerrs(true)'' or  ''relerrs(1)''');
    elseif nargin==1
        ifS=true;
        if isempty(ifL)
            ifL=false;
        end
    else
        if isempty(ifL)
            ifL=false;
        end
        if isempty(ifS)
            ifS=true;
        end
    end
    CN=Optimizer('getOpVal');        % get the parameter names in the original order
    CN(ComVarStr.ParStep==0)=[];     % exclude parameters not being fitted currently 
    k=length(CN);                    % total number of the parameters being fitted currently
    try
        y=getpara([],[],false);         % get the values of the parameters being fitted currently
        d=sqrt(diag(ComVarStr.Df)*ComVarStr.sigma2);      % absolute uncertainty estimates
        if any(size(d)~=size(y))
            d=[];
        end
    catch
        y=[];
        d=[];
    end
    if ifS && ~isempty(y) && ~isempty(d)
        [Y,I]=sort(abs(d./y),'descend'); % get and sort the relative uncertainty
    else
        I=[1:k]';
        try
            Y=abs(d./y);
        catch
            Y=[];
        end
    end
    %
    if ~isempty(Y)
        if ifL
            s = sprintf('\r\n\r\n  No        rel.err.                 abs.err.                 value              name\r\n'); % form the title of the table
            disp(s);                         % print the title of the table
            for i=1:k                        % start the loop over the parameters
                if i>1 && Y(i)<1 && Y(i-1)>=1 && ifS
                    disp('---------------------------------------------------------------------------------------------------rel.err.=1'); % upper parameters have uncertainties greater than their absolute value, lower - vice versus
                end
                s = sprintf('%4i  %23.15d  %23.15d  %23.15d  %s',I(i),Y(i),d(I(i)),y(I(i)),CN{I(i)}); % the current line of the table
                disp(s);                     % output of the current line to the command window
            end                              % finalize the loop over the parameters
        else
            s = sprintf('\r\n\r\n  No     rel.err.    abs.err.      value  name\r\n'); % form the title of the table
            disp(s);                         % print the title of the table
            for i=1:k                        % start the loop over the parameters
                if i>1 && Y(i)<1 && Y(i-1)>=1 && ifS
                    disp('-----------------------------------------------------------rel.err.=1'); % upper parameters have uncertainties greater than their absolute value, lower - vice versus
                end
                s = sprintf('%4i  %10.2g  %10.2g  %10.2g  %s',I(i),Y(i),d(I(i)),y(I(i)),CN{I(i)}); % the current line of the table
                disp(s);                     % output of the current line to the command window
            end                              % finalize the loop over the parameters
        end
    elseif length(y)==k
        if ifL
            s = sprintf('\r\n\r\n  No        value              name\r\n'); % form the title of the table
            disp(s);                         % print the title of the table
            for i=1:k                        % start the loop over the parameters
                s = sprintf('%4i  %23.15d  %s',I(i),y(I(i)),CN{I(i)}); % the current line of the table
                disp(s);                     % output of the current line to the command window
            end                              % finalize the loop over the parameters
        else
            s = sprintf('\r\n\r\n  No      value    name\r\n'); % form the title of the table
            disp(s);                         % print the title of the table
            for i=1:k                        % start the loop over the parameters
                s = sprintf('%4i  %10.2g  %s',I(i),y(I(i)),CN{I(i)}); % the current line of the table
                disp(s);                     % output of the current line to the command window
            end                              % finalize the loop over the parameters
        end
        disp('The parameter inaccuracies have not probably been computed or incorrect');
    else
        s = sprintf('\r\n\r\n  No     name\r\n'); % form the title of the table
        disp(s);                         % print the title of the table
        for i=1:k                        % start the loop over the parameters
            s = sprintf('%4i  %s',I(i),CN{I(i)}); % the current line of the table
            disp(s);                     % output of the current line to the command window
        end                              % finalize the loop over the parameters
        disp('The parameter values and/or their inaccuracies are incorrect');
    end
    s=sprintf('\r\n Total number of the model parameters is %i',k);
    disp(s);
catch
    disp('relerrs ERROR: check if the correct model is loaded'); % error message
end
return