function varargout = Viewer(varargin)
% The main tool for visualizing the optimization results of Optimizer

global V_figInpFit  % main figure handle
global ComVarStr

if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp)
    ComVarStr.ifDisp=true; % can be turned off in the command window
elseif ~isscalar(ComVarStr.ifDisp)
    ComVarStr.ifDisp=ComVarStr.ifDisp(1);
end
if ~isfield(ComVarStr,'ifPT') || isempty(ComVarStr.ifPT)
    ComVarStr.ifPT=0; % can be turned off in the command window
elseif ~isscalar(ComVarStr.ifPT)
    ComVarStr.ifPT=ComVarStr.ifPT(1);
end

if (nargin==0)
    %
    if isempty(V_figInpFit)
        ViewStart;
    else
        figure (V_figInpFit);
        return
    end
	set(V_figInpFit,'Color',get(0,'defaultUicontrolBackgroundColor'));
    pbInRefr_Callback;
else
    try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
		disp(lasterr);
    end
end
return

function varargout = FitInp_CloseRequestFcn(h,varargin)
 clearglFitInp;
 delete (gcbf);
return

function varargout = FitInp_DeleteFcn(h,varargin)
 clearglFitInp;
return

function varargout = pbInExit_Callback(h, varargin)
%  button = questdlg('Are you sure to exit the Input window?','Exit Confirm','Yes','No','Yes');
%  if (isequal(button,'Yes'))
   delete (gcbf); % this will run RKR_DeleteFcn
%  end
return

function pbIninput_Callback
    global V_figInpFit  % main figure handle
    global ComVarStr; % global structure for keeping all of the values
    %
    global V_style
    global V_Inp
    global V_Cov
    ifX    = false; % if X is in the file?
    ifY    = false; % if Y is in the file?
    ifYerr = false; % if Y errrors are in the file?
    set (findobj('Tag','lstbIn1','Parent',V_figInpFit),'Value',1);
    set (findobj('Tag','lstbIn2','Parent',V_figInpFit),'Value',1);
    set (findobj('Tag','lstbIn3','Parent',V_figInpFit),'Value',1);
    myGenWrite('lstbIn1',[],'-');
    myGenWrite('lstbIn2',[],'-');
    myGenWrite('lstbIn3',[],'-');
    set(findobj('Tag','txtInCovar','Parent',V_figInpFit),'FontWeight','bold','String','WAIT');
    Fitinou;
    if isempty (V_Inp)
        return
    end
    k=1:size(V_Inp,2);
    if ~isempty(V_style)
        for i=1:length(V_style)
            if strcmp ('X',V_style{i})
                ComVarStr.X0=V_Inp(:,i);
                ifX = true;
            elseif strcmp ('Y',V_style{i})
                ComVarStr.input=V_Inp(:,i);
                ifY = true;
            elseif strcmp ('YErr',V_style{i}) && isempty(V_Cov)
                ComVarStr.inpCovar=V_Inp(:,i);
                ifYerr = true;
            end
        end
    else
        if size(V_Inp,2)>=3
            ComVarStr.X0=V_Inp(:,1);
            ifX = true;
            ComVarStr.input=V_Inp(:,2);
            ifY = true;
            if isempty(V_Cov)
                ComVarStr.inpCovar=V_Inp(:,3);
                ifYerr = true;
            end
        elseif size(V_Inp,2)==2
            ComVarStr.input=V_Inp(:,1);
            ifY = true;
            if isempty(V_Cov)
                ComVarStr.inpCovar=V_Inp(:,2);
                ifYerr = true;
            end
        elseif size(V_Inp,2)==1
            ComVarStr.input=V_Inp(:,1);
            ifYerr = true;
        end
    end
    if ~isempty(V_Cov)
        ComVarStr.inpCovar=V_Cov;
        ifYerr = true;
    end
    if ~ifX
        ComVarStr.X0 = [];
    end
    if ~ifY
        ComVarStr.Y = [];
    end
    if ~ifYerr
        ComVarStr.inpCovar = [];
    end
    clear global V_style;
    clear global V_Inp;
    clear global V_Cov;
% update listboxes and plots
    pbInRefr_Callback;
return

function pbInoutput_Callback
 Fitinou('out');
try
catch
end
return

function varargout = pbInPlot_Callback(h,varargin)
  ScalePlotStart;
  uiwait;
  pbInRefr_Callback;
return

function pbInRefr_Callback
 global V_figInpFit  % main figure handle
 global ComVarStr
 %
 % refresh simulation results
 if ~isfield(ComVarStr,'ifPT') || isempty(ComVarStr.ifPT) || ~isnumeric(ComVarStr.ifPT) || ~isreal(ComVarStr.ifPT) || ComVarStr.ifPT(1)>=0
%      if isfield(ComVarStr,'ifPT') && ~isempty(ComVarStr.ifPT) && isnumeric(ComVarStr.ifPT) && isreal(ComVarStr.ifPT) && ~isinf(ComVarStr.ifPT(1)) && ~isnan(ComVarStr.ifPT(1))
%          ifPT = ComVarStr.ifPT(1);
%      else
%          ifPT=0;
%      end
     y0 = getresults;
     set (findobj('Tag','lstbInSim','Parent',V_figInpFit),'Value',1);
     myGenWrite('lstbInSim',y0,'-',[]);
     %
     % refresh independent coordinate list
     set (findobj('Tag','popIn1','Parent',V_figInpFit),'Value',1);
     set (findobj('Tag','lstbIn1','Parent',V_figInpFit),'Value',1);
     if isfield(ComVarStr,'X0') && ~isempty(ComVarStr.X0) && all(isnumeric(ComVarStr.X0)) && ...
      ( (isfield(ComVarStr,'input') && all(isnumeric(ComVarStr.input)) && length(ComVarStr.X0)==length(ComVarStr.input))...
      || length(ComVarStr.X0)==length(y0) )
         myGenWrite('lstbIn1',ComVarStr.X0,'-',[]);
     elseif isfield(ComVarStr,'input') && ~isempty(ComVarStr.input)
         ComVarStr.X0 = [1:length(ComVarStr.input)]';
         myGenWrite('lstbIn1',ComVarStr.X0,'-',[]);
     elseif ~isempty(y0)
         ComVarStr.X0 = [1:length(y0)]';
         myGenWrite('lstbIn1',ComVarStr.X0,'-',[]);
     else
         set (findobj('Tag','popIn1','Parent',V_figInpFit),'Value',4);
         myGenWrite('lstbIn1','-','-');
     end
     %
     % refresh experimental data
     set (findobj('Tag','lstbIn2','Parent',V_figInpFit),'Value',1);
     if isfield(ComVarStr,'input') && all(isnumeric(ComVarStr.input))
         set (findobj('Tag','popIn2','Parent',V_figInpFit),'Value',2);
         myGenWrite('lstbIn2',ComVarStr.input,'-',[]);
     else
         set (findobj('Tag','popIn2','Parent',V_figInpFit),'Value',4);
         myGenWrite('lstbIn2','-','-');
     end
     %
     % refresh errors
     set (findobj('Tag','lstbIn3','Parent',V_figInpFit),'Value',1);
     if ~isfield(ComVarStr,'inpCovar') || isempty(ComVarStr.inpCovar) || any(any(~isnumeric(ComVarStr.inpCovar)))
         ComVarStr.inpCovar = [];
         if isfield(ComVarStr,'input') && ~isempty(ComVarStr.input)
             ComVarStr.inpCovar = ones(size(ComVarStr.input));
         end
     end
     if isfield(ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && any(size(ComVarStr.inpCov)==length(ComVarStr.input))
         inpC=ComVarStr.inpCov;
     else
         ComVarStr.inpCov=[];
         inpC=ComVarStr.inpCovar;
     end
     if ~isempty(inpC) && any(size(inpC)==length(ComVarStr.input))
        set (findobj('Tag','popIn3','Parent',V_figInpFit),'Value',3);
        if any(size(inpC)==1)
            myGenWrite('lstbIn3',inpC,'-',[]);
            C = 'Absolute errors are loaded';
        else
            myGenWrite('lstbIn3',sqrt(diag(inpC)),'-',[]);
            C = 'Covariance matrix is loaded';
        end
     else
        ComVarStr.inpCovar=[];
        set (findobj('Tag','popIn3','Parent',V_figInpFit),'Value',4);
        myGenWrite('lstbIn3','-','-');
        C = 'Covariance matrix is not loaded';
     end
    %  if isfield (ComVarStr,'inpCov') && ~isempty(ComVarStr.inpCov) && all(all(isnumeric(ComVarStr.inpCov))) && (any(size(ComVarStr.inpCov)==length(ComVarStr.input)) || any(size(ComVarStr.inpCov)==1))
    %      C = strcat(C,'; Corrected covariance matrix is loaded and will be used');
    %  else
    %      ComVarStr.inpCov=[];
    %  end
     set(findobj('Tag','txtInCovar','Parent',V_figInpFit),'FontWeight','normal','String',C);
    %
    % list arrays information
     try
        N  = length(ComVarStr.input);
     catch
        N = 0;
     end
     try
        N0 = length(y0);
     catch
        N0 = 0;
     end
     M = get(findobj('Tag','lstbIn1','Parent',V_figInpFit),'Value');
     if N==N0 && N && N0
         set (findobj('Tag','txtInWarn','Parent',V_figInpFit),'String',strcat ('The length of the data arrays = ',num2str(N),'; current number = ', num2str(M)));
     else
         set (findobj('Tag','txtInWarn','Parent',V_figInpFit),'String',strcat ('The length of the Y array = ',num2str(N),' and of the simulation array = ',num2str(N0),'; current number = ', num2str(M))) ;
     end
 end
 %
 % refresh plot
 if ~isfield(ComVarStr,'ifPT') || isempty(ComVarStr.ifPT) || ~isnumeric(ComVarStr.ifPT) || ~isreal(ComVarStr.ifPT) || ComVarStr.ifPT(1)<=0
     plotInp;
 end
return

function varargout = SetXYErr_Callback(h, varargin)
global V_figInpFit  % main figure handle
try
    global ComVarStr
    uic1 = findobj('Tag','popIn1','Parent',V_figInpFit);
    uic2 = findobj('Tag','popIn2','Parent',V_figInpFit);
    uic3 = findobj('Tag','popIn3','Parent',V_figInpFit);
    Val  = get(h,'Value');
    if h==uic1
        if Val==4
            ComVarStr.X0=[];
        elseif Val==3 
            if ~isfield(ComVarStr,'inpCovar') || isempty(ComVarStr.inpCovar) || any(any(~isnumeric(ComVarStr.inpCovar)))
                ComVarStr.inpCovar = ComVarStr.X0;
                ComVarStr.X0       = [];
            elseif any(size(ComVarStr.inpCovar)==1)
                tmp                = ComVarStr.inpCovar;
                ComVarStr.inpCovar = ComVarStr.X0;
                ComVarStr.X0       = tmp;
            else
                set(uic1,'Value',4);
                return
            end
        elseif Val==2
            if ~isfield(ComVarStr,'input') || isempty(ComVarStr.input) || any(~isnumeric(ComVarStr.input))
                ComVarStr.input = ComVarStr.X0;
                ComVarStr.X0    = [];
            else
                tmp             = ComVarStr.input;
                ComVarStr.input = ComVarStr.X0;
                ComVarStr.X0    = tmp;
            end
        end
    elseif h==uic2
        if Val==4
            ComVarStr.input=[];
        elseif Val==3
            if ~isfield(ComVarStr,'inpCovar') || isempty(ComVarStr.inpCovar) || any(any(~isnumeric(ComVarStr.inpCovar)))
                ComVarStr.inpCovar = ComVarStr.input;
                ComVarStr.input    = [];
            elseif any(size(ComVarStr.inpCovar)==1)
                tmp                = ComVarStr.inpCovar;
                ComVarStr.inpCovar = ComVarStr.input;
                ComVarStr.input    = tmp;
            else
                set(uic2,'Value',4);
                return
            end
        elseif Val==1
            if ~isfield(ComVarStr,'X0') || isempty(ComVarStr.X0) || any(~isnumeric(ComVarStr.X0))
                ComVarStr.X0    = ComVarStr.input;
                ComVarStr.input = [];
            else
                tmp                = ComVarStr.X0;
                ComVarStr.X0       = ComVarStr.input;
                ComVarStr.input    = tmp;
            end
        end
    elseif h==uic3
        if Val==4 && isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
            ComVarStr.inpCovar=[];
        elseif Val==2
            if ~isfield(ComVarStr,'input') || isempty(ComVarStr.input) || any(~isnumeric(ComVarStr.input))
                ComVarStr.input = myGenRead('lstbIn3');
                if isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
                    ComVarStr.inpCovar = [];
                end
            else
                if isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
                    ComVarStr.inpCovar = ComVarStr.input;
                end
                ComVarStr.input = myGenRead('lstbIn3');
            end
        elseif Val==1
            if ~isfield(ComVarStr,'X0') || isempty(ComVarStr.X0) || any(~isnumeric(ComVarStr.X0))
                ComVarStr.X0 = myGenRead('lstbIn3');
                if isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
                    ComVarStr.inpCovar = [];
                end
            else
                if isfield(ComVarStr,'inpCovar') && any(size(ComVarStr.inpCovar)==1)
                    ComVarStr.inpCovar = ComVarStr.X0;
                end
                ComVarStr.X0 = myGenRead('lstbIn3');
            end
        end
    end
    pbInRefr_Callback;
catch
end
return

function varargout = lstbInp_Callback(h, varargin)
try
%
global V_figInpFit
global ComVarStr
global V_hAx1In
global V_hAx2In
global V_k1InFit  % to transfer boundaries from the modInput function
global V_k2InFit  % to transfer boundaries from the modInput function
global V_Xmod;    % modified X value
global V_Ymod;    % modified Y value
global V_Yerrmod; % modified Yerr value
global V_ifAdStr; % if to add a new string (true) or replace the current one (false)
global V_ifLgY; % if the scale for Y is logarithm?
global V_ifLgdY; % if the scale for Y residuals is logarithm?
k = get (gcbo,'Value');
%
c=get(V_figInpFit,'SelectionType');
if strcmp(c,'open') || strcmp(c,'alt') % in a case of DblClick or LeftClick
    V_k1InFit=[];
    V_k2InFit=[];
    modInput(k);
    uiwait;
    if ~isempty(V_Xmod) || ~isempty(V_Ymod) || ~isempty(V_Yerrmod)
        if ~isempty(V_Xmod)
            try
                if V_ifAdStr
                    try
                        N = length(ComVarStr.X0);
                    catch
                        N = 0;
                    end
                    if k<N
                        ComVarStr.X0(k+2:N+1) = ComVarStr.X0(k+1:N);
                        N = k;
                    end
                    ComVarStr.X0(N+1) = V_Xmod;
                else
                    ComVarStr.X0(k) = V_Xmod;
                end
                if size(ComVarStr.X0,2)>1
                    ComVarStr.X0 = ComVarStr.X0';
                end
            catch
            end
        end
        if ~isempty(V_Ymod)
            try
                if V_ifAdStr
                    try
                        N = length(ComVarStr.input);
                    catch
                        N = 0;
                    end
                    if k<N
                        ComVarStr.input(k+2:N+1) = ComVarStr.input(k+1:N);
                        N = k;
                    end
                    ComVarStr.input(N+1) = V_Ymod;
                else
                    ComVarStr.input(k) = V_Ymod;
                end
                if size(ComVarStr.input,2)>1
                    ComVarStr.input = ComVarStr.input';
                end
            catch
            end
        end
        if ~isempty(V_Yerrmod) && isfield(ComVarStr,'inpCovar')
            if any(size(ComVarStr.inpCovar)==1)% & any(size(ComVarStr.inpCovar)>=k)
                try
                    if V_ifAdStr
                        try
                            N = length(ComVarStr.inpCovar);
                        catch
                            N = 0;
                        end
                        if k<N
                            ComVarStr.inpCovar(k+2:N+1) = ComVarStr.inpCovar(k+1:N);
                            N = k;
                        end
                        ComVarStr.inpCovar(N+1) = V_Yerrmod;
                    else
                        ComVarStr.inpCovar(k) = V_Yerrmod;
                    end
                if size(ComVarStr.inpCovar,2)>1
                    ComVarStr.inpCovar = ComVarStr.inpCovar';
                end
                catch
                end
            end
        end
        pbInRefr_Callback;
    elseif ~isempty(V_k1InFit) && ~isempty(V_k2InFit) && V_k1InFit<=V_k2InFit
        try
            k2 = max(min(length(ComVarStr.X0),V_k2InFit),1);
            k1 = min(max(1,V_k1InFit),length(ComVarStr.X0));
            ComVarStr.X0(k1:k2)=[];
        catch
        end
        try
            k2 = max(min(length(ComVarStr.input),V_k2InFit),1);
            k1 = min(max(1,V_k1InFit),length(ComVarStr.input));
            ComVarStr.input(k1:k2)=[];
        catch
        end
        try
            k2 = max(min(max(size(ComVarStr.inpCovar)),V_k2InFit),1);
            k1 = min(max(1,V_k1InFit),max(size(ComVarStr.inpCovar)));
            if any(size(ComVarStr.inpCovar)==1)
                ComVarStr.inpCovar(k1:k2)=[];
            else
                ComVarStr.inpCovar(:,k1:k2)=[];
                ComVarStr.inpCovar(k1:k2,:)=[];
            end
        catch
        end
        pbInRefr_Callback;
    end
    clear global V_k1InFit;  % to transfer boundaries from the modInput function
    clear global V_k2InFit;  % to transfer boundaries from the modInput function
    clear global V_Xmod;    % modified X value
    clear global V_Ymod;    % modified Y value
    clear global V_Yerrmod; % modified Yerr value
    clear global V_ifAdStr; % if to add a new string (true) or replace the current one (false)
end
Z0=getresults; % array of results
%
% get length of data arrays
try
    k1 = length(ComVarStr.X0);
catch
    k1 = 0;
end
try
    k2 = length(ComVarStr.input);
catch
    k2 = 0;
end
try
    k3 = max(size(ComVarStr.inpCovar));
catch
    k3 = 0;
end
try
    kSim = length(Z0);
catch
    kSim = 0;
end
uic1=findobj('Tag','lstbIn1','Parent',V_figInpFit);
uic2=findobj('Tag','lstbIn2','Parent',V_figInpFit);
uic3=findobj('Tag','lstbIn3','Parent',V_figInpFit);
uicSim=findobj('Tag','lstbInSim','Parent',V_figInpFit);
if k<=k1
    set (uic1,'Value',k);
end
if k<=k2
    set (uic2,'Value',k);
end
if k<=k3
    set (uic3,'Value',k);
end
if k<=kSim
    set (uicSim,'Value',k);
end
%
% show current point in plots
%
x=k;
y=[];
z=[];
try
    y=ComVarStr.input(k);
catch
    y = [];
end
try
    x=ComVarStr.X0(k);
catch
    x=[];
end
if ~isempty(Z0)
    try
        z=Z0(k);
    catch
        z =[];
    end
    clear Z0;
end
%
if ~isempty(y) && ~isempty(x)
    subplot(V_hAx1In);
    delete(findobj('Type','line','Marker','s','Parent',gca)); % otherwise Octave does not work
    if ~isempty(V_ifLgY) && V_ifLgY(1)
        pntShow(x,abs(y),'r','s'); % mark with red square
    else
        pntShow(x,y,'r','s'); % mark with red square
    end
    if ~isempty(z)
        delete(findobj('Type','line','Marker','o','Parent',gca)); % otherwise Octave does not work
        if ~isempty(V_ifLgY) && V_ifLgY(1)
            pntShow(x,abs(z),'r','o');
        else
            pntShow(x,z,'r','o');
        end
        subplot(V_hAx2In);
        delete(findobj('Type','line','Marker','o','Parent',gca)); % otherwise Octave does not work
        if ~isempty(V_ifLgdY) && V_ifLgdY(1)
            pntShow(x,abs(y-z),'r','o');
        else
            pntShow(x,y-z,'r','o');
        end
    end
elseif ~isempty(z) && ~isempty(x)
    subplot(V_hAx1In);
    delete(findobj('Type','line','Marker','o','Parent',gca)); % otherwise Octave does not work
    if ~isempty(V_ifLgY) && V_ifLgY(1)
        pntShow(x,abs(z),'r','o'); % mark with green square
    else
        pntShow(x,z,'r','o'); % mark with green square
    end
end
 %
 % display arrays information
 try
    N  = length(ComVarStr.input);
 catch
    N = 0;
 end
 try
    N0 = length(getresults);
 catch
     N0 = 0;
 end
 if N==N0 && N && N0
     C = strcat( 'The length of the data arrays = ',num2str(N),'; current number = ', num2str(k) );
 else
     C = strcat( 'The length of the Y array = ',num2str(N),' and of the simulation array = ',num2str(N0),'; current number = ', num2str(k) );
 end
 C1 = '';
 if ~isempty(x)
     C1 = strcat( 'X = ',deblank(strjust(num2str(x,'%26.16g'),'left')) );
 end
 if ~isempty(y)
     C1 = strcat( C1,'; Y = ',deblank(strjust(num2str(y,'%26.16g'),'left')) );
 end
 if ~isempty(z)
     C1 = strcat( C1,'; Ysim = ',deblank(strjust(num2str(z,'%26.16g'),'left')) );
 end
 if ~isempty(z) && ~isempty(y)
     C1 = strcat(C1,'; Y-Ysim = ',num2str(y-z));
     try
         if z~=0
            z = abs((y-z)/z)*100;
            C1 = strcat(C1,' [',num2str(z),'%]');
        end
     catch
     end
 end
 set (findobj('Tag','txtInWarn','Parent',V_figInpFit),'String',{[C];[C1]});
%
catch
end
return

function plotInp
%Updates plots
global V_kPleft;  % left boundry of the plot
global V_kPright; % right boundry of the plot
global V_ifLgY; % if the scale for Y is logarithm?
global V_ifLgdY; % if the scale for Y residuals is logarithm?
global ComVarStr;
global V_hAx1In;
global V_hAx2In;
%
% V_kPright will be found later
s = warning;
s0 = 'on';
for i=1:length(s)
    if strcmp(s(i).identifier,'all')
        s0 = s(i).state;
        break;
    end
end
clear s;
warning off;
try
    if isempty(V_kPleft) || ~isreal(V_kPleft) || isinf(V_kPleft) || isnan(V_kPleft) || V_kPleft<=0
         V_kPleft=1;
    end
    if isempty(V_ifLgY)
        V_ifLgY = false;
    end
    if isempty(V_ifLgdY)
        V_ifLgdY = false;
    end
catch
    V_kPleft=1;
    V_ifLgY = false;
    V_ifLgdY = false;
end
try
    cla(V_hAx1In);
    cla(V_hAx2In);
    % prepair arrays
    try
        X0=ComVarStr.X0;
    catch
        X0=[];
    end
    try
        Y0=ComVarStr.input;
    catch
        Y0=[];
    end
    Z0=getresults;
    if isempty(Y0) && isempty(Z0)
        if strcmp(s0,'on')
            warning on;
        end
        return
    end
    if isempty(X0)
        X0=1:max([length(Y0) length(Z0)]);
    end
    %
    % check kPright & kPright
    V_kPright = min([V_kPright length(X0)]);
    if ~isempty(Y0)
        V_kPright = min([V_kPright length(Y0)]);
    end
    if ~isempty(Z0)
        V_kPright = min([V_kPright length(Z0)]);
    end
    V_kPleft = min([V_kPleft length(X0)]);
    if ~isempty(Y0)
        V_kPleft = min([V_kPleft length(Y0)]);
    end
    if ~isempty(Z0)
        V_kPleft = min([V_kPleft length(Z0)]);
    end
    if V_kPright<V_kPleft % exchange
        V_kP=V_kPleft;
        V_kPleft=V_kPright;
        V_kPright=V_kP;
    end
    %
    % set boundaries
    X0 = X0(V_kPleft:V_kPright);
    if ~isempty(Y0) && length(Y0)>=V_kPright
        Y0 = Y0(V_kPleft:V_kPright);
    end
    if ~isempty(Z0) && length(Z0)>=V_kPright
        Z0 = Z0(V_kPleft:V_kPright);
    end
    % plot
    leg  = {''};
    if ~isempty(Z0) && ~isempty(Y0)
        [X0,Z0,ind0]=Arran2(X0,Z0);
        Y0=Y0(ind0);
        subplot(V_hAx1In);
        legend off;
        if ~V_ifLgY
            plot(X0,Y0,'.k',X0,Z0,'-b');
            leg = [{'experiment'};{'simulation'}];
            set(V_hAx1In,'Yscale','linear');
            ylabel('Y');
        else
            k = find(Y0>0);
            if ~isempty(k)
                plot(X0(k),Y0(k),'.k');
                leg = [leg;{'experiment positive'}];
                hold on;
            end
            k = find(Z0>0);
            if ~isempty(k)
                plot(X0(k),Z0(k),'-b');
                leg = [leg;{'simulation positive'}];
                hold on;
            end
            k = find(Y0<0);
            if ~isempty(k)
                plot(X0(k),-Y0(k),'.c');
                leg = [leg;{'experiment negative'}];
                hold on;
            end
            k = find(Z0<0);
            if ~isempty(k)
                plot(X0(k),-Z0(k),'-g');
                leg = [leg;{'simulation negative'}];
                hold on;
            end
            set(V_hAx1In,'Yscale','log');
            ylabel('Y (logarithmic)');
        end
        if iscell(leg) && isempty(leg{1})
            leg(1)=[];
        end
        if ~isempty(leg) && (~isfield(ComVarStr,'ifLeg') || isempty(ComVarStr.ifLeg) || ComVarStr.ifLeg(1))
            legend(leg);
        end
        axis tight;
        hold off;
        subplot(V_hAx2In);
        legend off;
        if ~V_ifLgdY
            plot(X0,Y0-Z0,'.-b');
            leg = ('residuals');
            set(V_hAx2In,'Yscale','linear');
            ylabel('dY');
        else
            leg = {''};
            k = find(Y0>Z0);
            if ~isempty(k)
                plot(X0(k),Y0(k)-Z0(k),'.-b');
                leg = [leg;{'residuals positive'}];
                hold on;
            end
            k = find(Y0<Z0);
            if ~isempty(k)
                plot(X0(k),Z0(k)-Y0(k),'.-g');
                leg = [leg;{'residuals negative'}];
            end
            set(V_hAx2In,'Yscale','log');
            ylabel('dY (logarithmic)');
        end
        xlabel('X');
        if iscell(leg) && isempty(leg{1})
            leg(1)=[];
        end
        if ~isempty(leg) && (~isfield(ComVarStr,'ifLeg') || isempty(ComVarStr.ifLeg) || ComVarStr.ifLeg(1))
            legend(leg);
        end
        axis tight;
        hold off;
    elseif ~isempty(Y0)
        [X0,Y0]=Arran2(X0,Y0);
        subplot(V_hAx2In);
        legend off;
        subplot(V_hAx1In);
        legend off;
        if ~V_ifLgY
            plot(X0,Y0,'.k');
            leg = 'experiment';
            set(V_hAx1In,'Yscale','linear');
        else
            leg={''};
            k = find(Y0>0);
            if ~isempty(k)
                plot(X0(k),Y0(k),'.k');
                leg = [leg;{'experiment positive'}];
                hold on;
            end
            k = find(Y0<0);
            if ~isempty(k)
                plot(X0(k),-Y0(k),'.c');
                leg = [leg;{'experiment negative'}];
            end
            set(V_hAx1In,'Yscale','log');
        end
        if iscell(leg) && isempty(leg{1})
            leg(1)=[];
        end
        if ~isempty(leg) && (~isfield(ComVarStr,'ifLeg') || isempty(ComVarStr.ifLeg) || ComVarStr.ifLeg(1))
            legend(leg);
        end
        axis tight;
        hold off;
    else
        [X0,Z0]=Arran2(X0,Z0);
        subplot(V_hAx2In);
        legend off;
        subplot(V_hAx1In);
        legend off;
        if ~V_ifLgY
            plot(X0,Z0,'-b');
            leg = 'simulation';
            set(V_hAx1In,'Yscale','linear');
        else
            k = find(Z0>0);
            if ~isempty(k)
                plot(X0(k),Z0(k),'-b');
                leg = [leg;{'simulation positive'}];
                hold on;
            end
            kn = find(Z0<0);
            if ~isempty(kn)
                plot(X0(kn),-Z0(kn),'-g');
                leg = [leg;{'simulation negative'}];
            end
            set(V_hAx1In,'Yscale','log');
        end
        axis tight;
        if iscell(leg) && isempty(leg{1})
            leg(1)=[];
        end
        if ~isempty(leg) && (~isfield(ComVarStr,'ifLeg') || isempty(ComVarStr.ifLeg) || ComVarStr.ifLeg(1))
            legend(leg);
        end
        hold off;
    end
    if ~isfield(ComVarStr,'ifLeg') || isempty(ComVarStr.ifLeg) || ComVarStr.ifLeg(1)
        legend(V_hAx1In,'boxoff');
        legend(V_hAx2In,'boxoff');
    end
catch
end
if strcmp(s0,'on')
    warning on;
end
return

function modInput(k)
%
% modify input data in a case of the DblClick at a list
 global ComVarStr
 if isfield(ComVarStr,'ifPT') && ~isempty(ComVarStr.ifPT) && ComVarStr.ifPT(1)<0
     return;
 end
 k1=k;
 k2=k;
 % 
 f0 = figure('Name','Modify input data','NumberTitle','off','WindowStyle','modal','Resize','off','MenuBar','none');
 set(f0,'Color',get(0,'defaultUicontrolBackgroundColor'));
 pof = get(f0,'Position');
 uicontrol(f0,'Style','checkbox','Position',[pof(3)*.05 pof(4)*.9 pof(3)*.9 pof(4)*.05],'String','Delete input data from k1 to k2','TooltipString','Check to delete entries, uncheck to modify the current entry','FontWeight','bold','Value',0,'Tag','ckbDelStrngs',...
     'Callback','Viewer(''ckbDelStrngs_Callback'')');
 uicontrol(f0,'Style','text','Position',[pof(3)*.05 pof(4)*.8 pof(3)*.15 pof(4)*.04],'String','k1');
 uicontrol(f0,'Style','text','Position',[pof(3)*.05 pof(4)*.6 pof(3)*.15 pof(4)*.04],'String','k2');
 uik1 = uicontrol(f0,'Style','edit','Tag','edk1','Position',[pof(3)*.05 pof(4)*.73 pof(3)*.15 pof(4)*.07],'String',num2str(k),'Enable','off', ...
     'Callback', ...
     'k1=myGenRead(gcbo);try; global ComVarStr; myGenWrite(''txtX1'',ComVarStr.X0(k1),''-''); catch; myGenWrite(''txtX1'',[],''-''); end; try; myGenWrite(''txtY1'',ComVarStr.input(k1),''-''); catch; myGenWrite(''txtY1'',[],''-''); end;' ...
     );
 uik2 = uicontrol(f0,'Style','edit','Tag','edk2','Position',[pof(3)*.05 pof(4)*.53 pof(3)*.15 pof(4)*.07],'String',num2str(k),'Enable','off', ...
     'Callback', ...
     'k2=myGenRead(gcbo);try; global ComVarStr; myGenWrite(''txtX2'',ComVarStr.X0(k2),''-''); catch; myGenWrite(''txtX2'',[],''-''); end; try; myGenWrite(''txtY2'',ComVarStr.input(k2),''-''); catch; myGenWrite(''txtY2'',[],''-''); end;' ...
     );
 uicontrol(f0,'Style','text','Position',[pof(3)*.2 pof(4)*.8 pof(3)*.3 pof(4)*.05],'String','X1');
 uicontrol(f0,'Style','text','Position',[pof(3)*.2 pof(4)*.6 pof(3)*.3 pof(4)*.05],'String','X2');
 uiX1 = uicontrol(f0,'Style','text','Tag','txtX1','Position',[pof(3)*.2 pof(4)*.7 pof(3)*.3 pof(4)*.08]);
 uiX2 = uicontrol(f0,'Style','text','Tag','txtX2','Position',[pof(3)*.2 pof(4)*.5 pof(3)*.3 pof(4)*.08]);
 try; myGenWrite(uiX1,ComVarStr.X0(k1),'-'); catch; myGenWrite(uiX1,[],'-'); end;
 try; myGenWrite(uiX2,ComVarStr.X0(k2),'-'); catch; myGenWrite(uiX2,[],'-'); end;
 uicontrol(f0,'Style','text','Position',[pof(3)*.6 pof(4)*.8 pof(3)*.3 pof(4)*.05],'String','Y1');
 uicontrol(f0,'Style','text','Position',[pof(3)*.6 pof(4)*.6 pof(3)*.3 pof(4)*.05],'String','Y2');
 uiY1 = uicontrol(f0,'Style','text','Tag','txtY1','Position',[pof(3)*.6 pof(4)*.7 pof(3)*.3 pof(4)*.08]);
 uiY2 = uicontrol(f0,'Style','text','Tag','txtY2','Position',[pof(3)*.6 pof(4)*.5 pof(3)*.3 pof(4)*.08]);
 try; myGenWrite(uiY1,ComVarStr.input(k1),'-'); catch; myGenWrite(uiY1,[],'-'); end;
 try; myGenWrite(uiY2,ComVarStr.input(k2),'-'); catch; myGenWrite(uiY2,[],'-'); end;
 
 uicontrol(f0,'Style','text',...
     'Tag','txtXmodI',...
     'Position',[pof(3)*.05 pof(4)*.3 pof(3)*.25 pof(4)*.07],...
     'String','X');
 uicontrol(f0,'Style','text',...
     'Tag','txtYmodI',...
     'Position',[pof(3)*.35 pof(4)*.3 pof(3)*.25 pof(4)*.07],...
     'String','Y');
 uicontrol(f0,'Style','text',...
     'Tag','txtYerrmodI',...
     'Position',[pof(3)*.65 pof(4)*.3 pof(3)*.25 pof(4)*.07],...
     'String','Yerr');
 uicX = uicontrol(f0,'Style','edit',...
     'Tag','edXmodI',...
     'Position',[pof(3)*.05 pof(4)*.2 pof(3)*.25 pof(4)*.07],...
     'Enable','on',...
     'BackgroundColor','white');
 uicY = uicontrol(f0,'Style','edit',...
     'Tag','edYmodI',...
     'Position',[pof(3)*.35 pof(4)*.2 pof(3)*.25 pof(4)*.07],...
     'Enable','on',...
     'BackgroundColor','white');
 uicYerr = uicontrol(f0,'Style','edit',...
     'Tag','edYerrmodI',...
     'Position',[pof(3)*.65 pof(4)*.2 pof(3)*.25 pof(4)*.07],...
     'Enable','on',...
     'BackgroundColor','white');
 uicifAd = uicontrol(f0,'Style','checkbox',...
     'Tag','ckbifAdmod',...
     'Position',[pof(3)*.05 pof(4)*.4 pof(3)*.9 pof(4)*.07],...
     'Value',0,...
     'Callback','Viewer(''ckbifAdmod_Callback'')',...
     'TooltipString','check to add a string below the current one, uncheck to replace the current one; adding is forbidden with a covariance matrix',...
     'String','Add a string');
    if isfield(ComVarStr,'inpCovar') & all(size(ComVarStr.inpCovar)>1)
        set(uicifAd,'Enable','off','String','Adding is turned off due to the covariance matrix');
    end
 global V_Xmod;    % modified X value
 global V_Ymod;    % modified Y value
 global V_Yerrmod; % modified Yerr value
 global V_ifAdStr; % if to add a new string (true) or replace the current one (false)
 V_ifAdStr = false;
 try
     V_Xmod = ComVarStr.X0(k);
     if ~isempty(V_Xmod)
        myGenWrite(uicX,V_Xmod,'-');
     else
        myGenWrite(uicX,'-','-');
%        set(uicX,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
     end
 catch
     myGenWrite(uicX,'-','-');
     V_Xmod = [];
%     set(uicX,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
 end
 try
     V_Ymod = ComVarStr.input(k);
     if ~isempty(V_Ymod)
        myGenWrite(uicY,V_Ymod,'-');
     else
        myGenWrite(uicY,'-','-');
%        set(uicY,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
     end
 catch
     myGenWrite(uicY,'-','-');
%     set(uicY,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
 end
 try
     if any(size(ComVarStr.inpCovar)==1)
        V_Yerrmod = ComVarStr.inpCovar(k);
        myGenWrite(uicYerr,V_Yerrmod,'-');
     elseif any(size(ComVarStr.inpCovar)>1)
        V_Yerrmod = sqrt(ComVarStr.inpCovar(k,k));
        myGenWrite(uicYerr,V_Yerrmod,'-');
        V_Yerrmod = []; % Yerr cannot be modified in this case
%        set(uicYerr,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
     else
        myGenWrite(uicYerr,'-','-');
%        set(uicYerr,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
     end
 catch
     myGenWrite(uicYerr,'-','-');
%     set(uicYerr,'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
 end
 
 uicontrol(f0,'Style','pushbutton','Position',[pof(3)*.2 pof(4)*.1 pof(3)*.2 pof(4)*.05],'String','Cancel', ...
     'Callback','Viewer(''modInpCanc_Callback'')' ...
     );
 uicontrol(f0,'Style','pushbutton','Position',[pof(3)*.6 pof(4)*.1 pof(3)*.2 pof(4)*.05],'String','OK', ...
     'Callback', ...
     'Viewer(''modInpOK_Callback'')' ...
     );
return

function ckbDelStrngs_Callback
if get(gcbo,'Value')==get(gcbo,'Max')
    set(findobj('Tag','edk1','Parent',gcf),'Enable','on','BackgroundColor','white');
    set(findobj('Tag','edk2','Parent',gcf),'Enable','on','BackgroundColor','white');
    set(findobj('Tag','ckbifAdmod','Parent',gcf),'Enable','off');
    set(findobj('Tag','edXmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
    set(findobj('Tag','edYmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
    set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
else
    global ComVarStr;
    set(findobj('Tag','edk1','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
    set(findobj('Tag','edk2','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
    if ~isfield(ComVarStr,'inpCovar') | any(size(ComVarStr.inpCovar)<=1)
        set(findobj('Tag','ckbifAdmod','Parent',gcf),'Enable','on');
    end
%    global V_Xmod;    % modified X value
%    global V_Ymod;    % modified Y value
%    global V_Yerrmod; % modified Yerr value
%    global V_ifAdStr; % if to add a new string (true) or replace the current one (false)
%    if ~isempty(V_Xmod)
        set(findobj('Tag','edXmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%    end
%    if ~isempty(V_Ymod)
        set(findobj('Tag','edYmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%    end
%    if ~isempty(V_Yerrmod)
        set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%    end
%    if V_ifAdStr & isempty(V_Xmod) & isempty(V_Ymod) & isempty(V_Yerrmod)
%        set(findobj('Tag','edXmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        set(findobj('Tag','edYmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%    end
end
return

function ckbifAdmod_Callback
 global V_Xmod;    % modified X value
 global V_Ymod;    % modified Y value
 global V_Yerrmod; % modified Yerr value
 global V_ifAdStr; % if to add a new string (true) or replace the current one (false)
 V_ifAdStr = ~V_ifAdStr;
%    if V_ifAdStr & isempty(V_Xmod) & isempty(V_Ymod) & isempty(V_Yerrmod)
%        set(findobj('Tag','edXmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        set(findobj('Tag','edYmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%    else
%        if ~isempty(V_Xmod)
%            set(findobj('Tag','edXmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        else
%            set(findobj('Tag','edXmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
%        end
%        if ~isempty(V_Ymod)
%            set(findobj('Tag','edYmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        else
%            set(findobj('Tag','edYmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
%        end
%        if ~isempty(V_Yerrmod)
%            set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','on','BackgroundColor','white');
%        else
%            set(findobj('Tag','edYerrmodI','Parent',gcf),'Enable','off','BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
%        end
%    end
return

function modInpCanc_Callback
 global V_k1InFit; % boundaries of the entries to be deleted
 global V_k2InFit;
 global V_Xmod;    % modified X value
 global V_Ymod;    % modified Y value
 global V_Yerrmod; % modified Yerr value
 V_k1InFit=[];
 V_k2InFit=[];
 V_Xmod = [];
 V_Ymod = [];
 V_Yerrmod = [];
 delete(gcf);
return

function modInpOK_Callback
 global V_k1InFit; % boundaries of the entries to be deleted
 global V_k2InFit;
 global V_Xmod;    % modified X value
 global V_Ymod;    % modified Y value
 global V_Yerrmod; % modified Yerr value
 if get(findobj('Tag','ckbDelStrngs','Parent',gcf),'Value') == get(findobj('Tag','ckbDelStrngs','Parent',gcf),'Max')
    V_k1InFit=myGenRead('edk1');
    V_k2InFit=myGenRead('edk2');
    if isempty(V_k1InFit) | isempty(V_k2InFit) | V_k1InFit<=0 | V_k1InFit>V_k2InFit
        V_k1InFit=[];
        V_k2InFit=[];
    end
    V_Xmod = [];
    V_Ymod = [];
    V_Yerrmod = [];
 else
%    ifAll = isempty(V_Xmod) & isempty(V_Ymod) & isempty(V_Yerrmod);
%    if ~isempty(V_Xmod) | ifAll
        V_Xmod = myGenRead('edXmodI');
%    end
%    if ~isempty(V_Ymod) | ifAll
        V_Ymod = myGenRead('edYmodI');
%    end
%    if ~isempty(V_Yerrmod) | ifAll
        V_Yerrmod = myGenRead('edYerrmodI');
%    end
    V_k1InFit=[];
    V_k2InFit=[];
 end
 delete(gcf);
return
 
function varargout = FitInp_ResizeFcn(h, varargin)
 global V_hAx1In
 global V_hAx2In

 pause(0.1);
 pofigInpFit = get(h,'Position');
 if ~isempty(find(pofigInpFit(3:4)<=0, 1))
    return;
 end

 set (findobj('Tag','pbIninput','Parent',h),  'Position',[pofigInpFit(3)*.85 pofigInpFit(4)*.84 pofigInpFit(3)*.10 pofigInpFit(4)*.04]);
 set (findobj('Tag','pbInoutput','Parent',h), 'Position',[pofigInpFit(3)*.85 pofigInpFit(4)*.75 pofigInpFit(3)*.1 pofigInpFit(4)*.04]);
 set (findobj('Tag','pbInPlot','Parent',h),   'Position',[pofigInpFit(3)*.85 pofigInpFit(4)*.66 pofigInpFit(3)*.1 pofigInpFit(4)*.04]);
 set (findobj('Tag','pbInRefr','Parent',h),   'Position',[pofigInpFit(3)*.85 pofigInpFit(4)*.57 pofigInpFit(3)*.1 pofigInpFit(4)*.04]);
 set (findobj('Tag','pbInExit','Parent',h),   'Position',[pofigInpFit(3)*.85 pofigInpFit(4)*.48 pofigInpFit(3)*.10 pofigInpFit(4)*.04]);
 set (findobj('Tag','lstbIn1','Parent',h),    'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.48 pofigInpFit(3)*.15 pofigInpFit(4)*.40]);
 set (findobj('Tag','lstbIn2','Parent',h),    'Position',[pofigInpFit(3)*.28 pofigInpFit(4)*.48 pofigInpFit(3)*.15 pofigInpFit(4)*.40]);
 set (findobj('Tag','lstbIn3','Parent',h),    'Position',[pofigInpFit(3)*.46 pofigInpFit(4)*.48 pofigInpFit(3)*.15 pofigInpFit(4)*.40]);
 set (findobj('Tag','lstbInSim','Parent',h),  'Position',[pofigInpFit(3)*.64 pofigInpFit(4)*.48 pofigInpFit(3)*.15 pofigInpFit(4)*.40]);
 set (findobj('Tag','popIn1','Parent',h),     'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.88 pofigInpFit(3)*.15 pofigInpFit(4)*.05]);
 set (findobj('Tag','popIn2','Parent',h),     'Position',[pofigInpFit(3)*.28 pofigInpFit(4)*.88 pofigInpFit(3)*.15 pofigInpFit(4)*.05]);
 set (findobj('Tag','popIn3','Parent',h),     'Position',[pofigInpFit(3)*.46 pofigInpFit(4)*.88 pofigInpFit(3)*.15 pofigInpFit(4)*.05]);
 set (findobj('Tag','txtInSim','Parent',h),   'Position',[pofigInpFit(3)*.64 pofigInpFit(4)*.88 pofigInpFit(3)*.15 pofigInpFit(4)*.05]);
 set (findobj('Tag','txtInCovar','Parent',h), 'Position',[pofigInpFit(3)*.2 pofigInpFit(4)*.43 pofigInpFit(3)*.7 pofigInpFit(4)*.04]);
 set (findobj('Tag','txtInWarn','Parent',h),  'Position',[pofigInpFit(3)*.05 pofigInpFit(4)*.93 pofigInpFit(3)*.9 pofigInpFit(4)*.07]);

% set (V_hAx1In,                     'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.27 pofigInpFit(3)*.85 pofigInpFit(4)*.15]);
% set (V_hAx2In,                     'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.07 pofigInpFit(3)*.85 pofigInpFit(4)*.15]);
%% xlabel('X','Color','k')
%% ylabel('dY','Color','k')
set(V_hAx1In, ...
    'Units',get(h,'Units'), ...
    'Color','White', ...
    'XColor','Black', ...
    'YColor','Black', ...
    'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.27 pofigInpFit(3)*.85 pofigInpFit(4)*.15] ...
    );
ylabel('Y','Color','k');
set(V_hAx2In, ...
    'Units',get(h,'Units'), ...
    'Color','White', ...
    'XColor','Black', ...
    'YColor','Black', ...
    'Position',[pofigInpFit(3)*.10 pofigInpFit(4)*.07 pofigInpFit(3)*.85 pofigInpFit(4)*.15] ...
    );
ylabel('dY','Color','k');
xlabel('X','Color','k');

return

function clearglFitInp
    global V_figInpFit;  % main figure handle
    global V_kPleft;  % left boundry of the plot
    global V_kPright; % right boundry of the plot
    global V_ifLgY; % if the scale for Y is logarithm?
    global V_ifLgdY; % if the scale for Y residuals is logarithm?
    global V_hAx1In
    global V_hAx2In
    clear global V_figInpFit;
    clear global V_kPleft;
    clear global V_kPright;
    clear global V_ifLgY;
    clear global V_ifLgdY;
    clear global V_hAx1In;
    clear global V_hAx2In;
return
