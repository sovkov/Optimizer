function PolS
% Computation of a polynomial values at a grid
% All the input and output is done via fields of the global structure ComVarStr.PolS.*
%   INPUT
% x     - vector with the grid nodes
% a     - vector with the polynomial coefficients:
%         y = a(1) + a(2)*x + ....
% ifDer - flag defining if the design matrix should be constructed by the current routine analytically or not
%   OUTPUT
% y     - vector with the resulted polynomial values at the grid x
% IERR  - error flag
%         = 0 --everything is OK,
%         = 1 --incorrect input x,
%         = 2 --incorrect input a,
%         = 10--an error in computing the design matrix,
%         =-1 --unclassified error,
%   REMARK:
% besides the field ComVarStr.Gau.ifDer described above, the design matrix computation can be turned on with the parameter
% ComVarStr.ifDer.ifDer. The difference is in how the result is positioned: in the 1-st case it is placed into the field
% ComVarStr.Der1 at once as a full design matrix of the problem; in the 2-nd case it is placed into the field
% ComVarStr.locDer, which can be combined into the full design matrix under the regulations of the package.
% In a case both of the parameters are "true", the computations are done as if only ComVarStr.ifDer.ifDer=true.
%
global ComVarStr % define the global structure
% check of the input data x and a
if ~isfield(ComVarStr,'PolS') || ~isfield(ComVarStr.PolS,'x') || isempty(ComVarStr.PolS.x) || ~isreal(ComVarStr.PolS.x)
    % no real x!
    % if needed, display the error information, and close the program
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('PolS: empty or erroneous input ''x'' ');
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError = true;
    end
    ComVarStr.PolS.IERR=1; % error flag for x
    ComVarStr.PolS.y=[];
    return
end
if ~isfield(ComVarStr.PolS,'a') || isempty(ComVarStr.PolS.a) || ~isreal(ComVarStr.PolS.a)
    % no real a!
    % if needed, display the error information, and close the program
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('PolS: empty or erroneous input ''a'' ');
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError = true;
    end
    ComVarStr.PolS.IERR=2; % error flag for a
    ComVarStr.PolS.y=zeros(size(ComVarStr.Pols.x));
    return
end
%
ComVarStr.PolS.IERR=0; % OK error flag (no errors)
K = length(ComVarStr.PolS.a); % the polynomial power +1
% do we need to compute the design matrix with the general package?
if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer)
    ifDer=ComVarStr.ifDer.ifDer(1);
else
    ifDer=false;
end
% do we need to compute the design matrix with this routine?
if ~ifDer && isfield(ComVarStr.PolS,'ifDer') && ~isempty(ComVarStr.PolS.ifDer)
    ifDer0=ComVarStr.PolS.ifDer(1);
else
    ifDer0=false;
end
% start of the main computation
try
    N=length(ComVarStr.PolS.x); % number of the grid nodes
    % computation of the polynomial values
    ComVarStr.PolS.y = ComVarStr.PolS.a(K) * ones(N,1);
    for m=K-1:-1:1
        ComVarStr.PolS.y = ComVarStr.PolS.y .* ComVarStr.PolS.x + ComVarStr.PolS.a(m);
    end
    % computation of the design matrix block if needed
    if ifDer
       try
          ComVarStr.locDer=ones(N,K); % memory allocation
          for m=2:K % loop over the components of a
              ComVarStr.locDer(:,m) = reshape(ComVarStr.PolS.x,N,1).^(m-1); % the column of the derivatives of y with respect to a(m); "reshape" is in a case when x is a row vector;
          end
          ComVarStr.locDerNames{1}='a';
      catch
          % error of the design matrix computation
          ComVarStr.locDer=[];
          ComVarStr.locDerNames=[];
          ComVarStr.Der1=[];
          ComVarStr.ifDer.ifDer=0;
          if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
              beep;
              disp('PolS WARNING: incorrect design matrix computing');
          end
          ComVarStr.PolS.IERR=10; % error flag
       end
    % computation of the full design matrix if needed
    elseif ifDer0
      ComVarStr.Der1=[];
      try
        jD = 0; % index of the variable parameters forming the design matrix
        try
            NP = length(ComVarStr.ParField); % the total number of the modeling blocks
        catch
            NP=0;
        end
        if NP>0
            for n=1:NP % loop over the modeling blocks
                LP = length(ComVarStr.ParField{n}); % the number of the matrix parameters of the current block
                if LP>0
                    for l=1:LP % loop over the matrix parameters of the current block
                        if strcmp(ComVarStr.ParField{n}(l),'a') % check if it is a indeed
                            ComVarStr.Der1=ones(N,K); % memory allocation
                            for m=1:K % loop over the components of a
                                if ComVarStr.ParStep(m)~=0 % if this parameter is a variable? yes if the step is non-zero.
                                    jD = jD+1; % increase the index of the variable parameters
                                    if m>1
                                        ComVarStr.Der1(:,jD) = reshape(ComVarStr.PolS.x,N,1).^(m-1); % the column of the derivatives of y with respect to a(m); "reshape" is in a case when x is a row vector;
                                    end
                                end
                            end
                            if jD<K
                                ComVarStr.Der1(:,(jD+1):K)=[]; % clear extra columns corresponding to the parameters, which are not variable
                            end
                        end
                    end
                end
            end
        end
        ComVarStr.ifDer=1;
      catch
          % error of the design matrix computation
          ifDer0 = false;
          ComVarStr.Der1=[];
          ComVarStr.PolS.ifDer=0;
          ComVarStr.ifDer=[];
          if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
              beep;
              disp('PolS WARNING: incorrect design matrix computing');
          end
          ComVarStr.PolS.IERR=10; % error flag
      end
    end
catch
    % unclassified error;
    % if needed, display the error information, and close the program
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('PolS: ERROR');
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError = true;
    end
    ComVarStr.PolS.IERR=-1; % error flag
end
return