function sumda
% Adds the vector ComVarStr.sumda.x to the vector ComVarStr.sumda.y
global ComVarStr
try
    ComVarStr.sumda.y = ComVarStr.sumda.y + ComVarStr.sumda.x;
catch % ERROR!
    if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
        beep;
        disp('sumda ERROR: the computations are broken');
    end
    if isfield(ComVarStr,'ifError')
        ComVarStr.ifError = true;
    end
end