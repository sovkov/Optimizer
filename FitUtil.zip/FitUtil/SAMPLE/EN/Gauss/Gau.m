function Gau
% Computation of a Gaussian values at a grid
% All the input and output is done via fields of the global structure ComVarStr.Gau.*
%   INPUT
% x     - vector with the grid nodes
% A     - integral intensity of the Gaussin; default A=1
% xc    - position of the Gaussian maximum; default xc=0
% sigma - half-width of the Gaussian (the square root of the second central normalized moment); default sigma=1
% ifDer - flag defining if the design matrix should be constructed by the current routine analytically or not
%   OUTPUT
% y     - vector with the resulted Gaussian values at the grid x
% IERR  - error flag
%         = 0 --everything is OK,
%         = 1 --an error has occured in computing the Gaussian,
%         = 10--an error in computing the design matrix,
%   REMARK:
% besides the field ComVarStr.Gau.ifDer described above, the design matrix computation can be turned on with the parameter
% ComVarStr.ifDer.ifDer. The difference is in how the result is positioned: in the 1-st case it is placed into the field
% ComVarStr.Der1 at once as a full design matrix of the problem; in the 2-nd case it is placed into the field
% ComVarStr.locDer, which can be combined into the full design matrix under the regulations of the package.
% In a case both of the parameters are "true", the computations are done as if only ComVarStr.ifDer.ifDer=true.
%
global ComVarStr % define the global structure
    ComVarStr.Gau.IERR = 0; % ERROR flag--everything is OK
% INPUT parameters
    if isfield(ComVarStr.Gau,'A') && isreal(ComVarStr.Gau.A)
        A = ComVarStr.Gau.A;
    else
        A = 1;
    end
    if isfield(ComVarStr.Gau,'xc') && isreal(ComVarStr.Gau.xc)
        xc = ComVarStr.Gau.xc;
    else
        xc = 0;
    end
    if isfield(ComVarStr.Gau,'sigma') && isreal(ComVarStr.Gau.sigma)
        sigma = ComVarStr.Gau.sigma;
    else
        sigma = 1;
    end
% do we need to compute the design matrix with the general package?
    if isfield(ComVarStr,'ifDer') && isfield(ComVarStr.ifDer,'ifDer') && ~isempty(ComVarStr.ifDer.ifDer)
        ifDer=ComVarStr.ifDer.ifDer(1);
    else
        ifDer=false;
    end
% do we need to compute the design matrix with this routine?
    if ~ifDer && isfield(ComVarStr.Gau,'ifDer') && ~isempty(ComVarStr.Gau.ifDer)
        ifDer0=ComVarStr.Gau.ifDer(1);
    else
        ifDer0=false;
    end
% compute the Gaussian values
    try
        ComVarStr.Gau.y = A ./ sqrt(2*pi) ./ sigma .* exp ( -( (ComVarStr.Gau.x-xc) ./ sigma ) .^2 / 2 );
    catch
        ComVarStr.Gau.y = [];
        if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) && ComVarStr.ifDisp(1)
            beep;
            disp('Gau ERROR: incorrect input data');
        end
        if isfield(ComVarStr,'ifError')
            ComVarStr.ifError = true;
        end
        ComVarStr.Gau.IERR = 1;
        return
    end
    %
    % computation of the design matrix block if needed
    if ifDer
      try
          ComVarStr.locDer(:,1)=ComVarStr.Gau.y/A; % derivatives with respect to A
          ComVarStr.locDer(:,2)=ComVarStr.Gau.y .* (ComVarStr.Gau.x-xc) ./ sigma.^2; % derivatives with respect to xc
          ComVarStr.locDer(:,3)=ComVarStr.Gau.y .* ( ((ComVarStr.Gau.x-xc)./sigma).^2 - 1) ./ sigma; % derivatives with respect to sigma
          ComVarStr.locDerNames{1}='A'; % derivatives with respect to A
          ComVarStr.locDerNames{2}='xc'; % derivatives with respect to xc
          ComVarStr.locDerNames{3}='sigma'; % derivatives with respect to sigma
      catch
          % ERROR!
          ComVarStr.locDer=[];
          ComVarStr.locDerNames=[];
          ComVarStr.Der1=[];
          ComVarStr.ifDer.ifDer=0;
          if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
              beep;
              disp('Gau WARNING: incorrect design matrix computing');
          end
          ComVarStr.Gau.IERR = 10;
      end
    % computation of the full design matrix if needed
    elseif ifDer0
      ComVarStr.Der1=[];
	  if isfield(ComVarStr,'ParField')
        try
          M0 = 0; % index of the variable parameters forming the design matrix
          try
              NP = length(ComVarStr.ParField); % the total number of the modeling blocks
          catch
              NP=0;
          end
          if NP>0
              for n=1:NP % loop over the modeling blocks
                  LP = length(ComVarStr.ParField{n}); % the number of the matrix parameters of the current block
                  if LP>0
                      for l=1:LP % loop over the matrix parameters of the current block
                          if strcmp(ComVarStr.ParField{n}(l),'A') % check if it is A
                              M0 = M0+1;
                              try
                                  if ComVarStr.ParStep(M0)~=0
                                      ComVarStr.Der1=[ComVarStr.Der1 ComVarStr.Gau.y./A]; % derivatives with respect to A
                                  end
                              end
                          elseif strcmp(ComVarStr.ParField{n}(l),'xc') % check if it is xc
                              M0 = M0+1;
                              try
                                  if ComVarStr.ParStep(M0)~=0
                                      ComVarStr.Der1=[ComVarStr.Der1 ComVarStr.Gau.y.*(ComVarStr.Gau.x-xc)./sigma.^2]; % derivatives with respect to xc
                                  end
                              end
                          elseif strcmp(ComVarStr.ParField{n}(l),'sigma') % check if it is sigma
                              M0 = M0+1;
                              try
                                  if ComVarStr.ParStep(M0)~=0
                                      ComVarStr.Der1=[ComVarStr.Der1 ComVarStr.Gau.y.*(((ComVarStr.Gau.x-xc)./sigma).^2 - 1)./sigma]; % derivatives with respect to sigma
                                  end
                              end
                          end
                      end
                  end
              end
          end
          ComVarStr.ifDer=1;
        catch
            % ERROR!
            ifDer0 = false;
            ComVarStr.Der1=[];
            ComVarStr.Gau.ifDer=0;
            ComVarStr.ifDer=[];
            if ~isfield(ComVarStr,'ifDisp') || isempty(ComVarStr.ifDisp) || ComVarStr.ifDisp(1)
                beep;
                disp('Gau WARNING: incorrect design matrix computing');
            end
            ComVarStr.Gau.IERR = 10;
        end
      end
    end
    %
return
